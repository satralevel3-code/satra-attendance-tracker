import { useEffect, useState } from 'react';
import { XCircle, ExternalLink, AlertTriangle, X, Key, Copy } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';

interface CriticalErrorBannerProps {
  onViewTroubleshooting?: () => void;
  onView401Troubleshooting?: () => void;
  onViewAPITesting?: () => void;
}

export function CriticalErrorBanner({ onViewTroubleshooting, onView401Troubleshooting, onViewAPITesting }: CriticalErrorBannerProps) {
  const [show, setShow] = useState(false);
  const [errorType, setErrorType] = useState<'403' | '401' | '400' | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Check for error flags
    const has403Error = localStorage.getItem('google_sheets_403_error') === 'true';
    const has401Error = localStorage.getItem('google_sheets_401_error') === 'true';
    const has400Error = localStorage.getItem('google_sheets_400_error') === 'true';
    const wasDismissed = localStorage.getItem('error_banner_dismissed') === 'true';
    
    if (has400Error && !wasDismissed) {
      setErrorType('400');
      setShow(true);
    } else if (has401Error && !wasDismissed) {
      setErrorType('401');
      setShow(true);
    } else if (has403Error && !wasDismissed) {
      setErrorType('403');
      setShow(true);
    } else {
      setShow(false);
    }
  }, []);

  const handleDismiss = () => {
    setDismissed(true);
    setShow(false);
    localStorage.setItem('error_banner_dismissed', 'true');
  };

  const handleEnableAPI = () => {
    window.open('https://console.cloud.google.com/apis/library/sheets.googleapis.com', '_blank');
  };

  const handleViewCredentials = () => {
    window.open('https://console.cloud.google.com/apis/credentials', '_blank');
  };

  if (!show || dismissed) return null;

  if (errorType === '400') {
    return (
      <div className="fixed top-0 left-0 right-0 z-50 bg-purple-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <XCircle className="w-5 h-5 flex-shrink-0" />
              <div>
                <div className="font-semibold">Critical: Bad Request (400 Error)</div>
                <div className="text-sm text-purple-100">
                  API key format or request parameters are invalid. This needs immediate debugging.
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {onViewAPITesting && (
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={onViewAPITesting}
                  className="bg-white text-purple-600 hover:bg-purple-50"
                >
                  <AlertTriangle className="w-4 h-4 mr-1" />
                  Debug API
                </Button>
              )}
              
              <Button
                size="sm"
                variant="outline"
                onClick={handleViewCredentials}
                className="border-purple-400 text-white hover:bg-purple-700"
              >
                <ExternalLink className="w-4 h-4 mr-1" />
                Check API Key
              </Button>
              
              <Button
                size="sm"
                variant="ghost"
                onClick={handleDismiss}
                className="text-white hover:bg-purple-700 p-1"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (errorType === '401') {
    return (
      <div className="fixed top-0 left-0 right-0 z-50 bg-orange-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Key className="w-5 h-5 flex-shrink-0" />
              <div>
                <div className="font-semibold">Critical: API Key Permission Denied</div>
                <div className="text-sm text-orange-100">
                  Your API key needs permission to access the spreadsheet. Remove restrictions and share with service account.
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="secondary"
                onClick={handleViewCredentials}
                className="bg-white text-orange-600 hover:bg-orange-50"
              >
                <ExternalLink className="w-4 h-4 mr-1" />
                Fix Permissions
              </Button>
              
              {onView401Troubleshooting && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={onView401Troubleshooting}
                  className="border-orange-400 text-white hover:bg-orange-700"
                >
                  <AlertTriangle className="w-4 h-4 mr-1" />
                  Fix Guide
                </Button>
              )}
              
              <Button
                size="sm"
                variant="ghost"
                onClick={handleDismiss}
                className="text-white hover:bg-orange-700 p-1"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-red-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <XCircle className="w-5 h-5 flex-shrink-0" />
            <div>
              <div className="font-semibold">Critical: Google Sheets API Not Enabled</div>
              <div className="text-sm text-red-100">
                Your API key is valid but Google Sheets API is disabled for project "satra-attendance-tracker"
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={handleEnableAPI}
              className="bg-white text-red-600 hover:bg-red-50"
            >
              <ExternalLink className="w-4 h-4 mr-1" />
              Enable API Now
            </Button>
            
            {onViewTroubleshooting && (
              <Button
                size="sm"
                variant="outline"
                onClick={onViewTroubleshooting}
                className="border-red-400 text-white hover:bg-red-700"
              >
                <AlertTriangle className="w-4 h-4 mr-1" />
                Fix Guide
              </Button>
            )}
            
            <Button
              size="sm"
              variant="ghost"
              onClick={handleDismiss}
              className="text-white hover:bg-red-700 p-1"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Also create a card version for dashboard display
export function CriticalErrorCard({ onViewTroubleshooting, onView401Troubleshooting, onViewAPITesting }: CriticalErrorBannerProps) {
  const [show, setShow] = useState(false);
  const [errorType, setErrorType] = useState<'403' | '401' | '400' | null>(null);

  useEffect(() => {
    const has403Error = localStorage.getItem('google_sheets_403_error') === 'true';
    const has401Error = localStorage.getItem('google_sheets_401_error') === 'true';
    const has400Error = localStorage.getItem('google_sheets_400_error') === 'true';
    
    if (has400Error) {
      setErrorType('400');
      setShow(true);
    } else if (has401Error) {
      setErrorType('401');
      setShow(true);
    } else if (has403Error) {
      setErrorType('403');
      setShow(true);
    } else {
      setShow(false);
    }
  }, []);

  if (!show) return null;

  if (errorType === '400') {
    return (
      <Card className="border-purple-200 bg-purple-50 shadow-lg">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <XCircle className="w-6 h-6 text-purple-600 flex-shrink-0 mt-1" />
            <div className="flex-1">
              <h3 className="font-semibold text-purple-900 mb-2">
                Bad Request Error (400) - API Configuration Issue
              </h3>
              <p className="text-purple-800 text-sm mb-4">
                Your API key <code className="bg-purple-100 px-1 rounded">AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8</code> format 
                or request parameters are invalid. This suggests a fundamental configuration problem.
              </p>
              
              <div className="space-y-3">
                <div className="bg-purple-100 border border-purple-200 rounded-lg p-3">
                  <h4 className="font-medium text-purple-900 mb-2">Immediate Actions Required:</h4>
                  <ol className="text-sm text-purple-800 space-y-1 list-decimal list-inside">
                    <li>Verify API key format (39 chars, starts with "AIza")</li>
                    <li>Check for extra spaces or special characters</li>
                    <li>Run comprehensive API testing</li>
                    <li>Verify spreadsheet ID is correct</li>
                  </ol>
                </div>
                
                <div className="flex gap-2">
                  {onViewAPITesting && (
                    <Button
                      onClick={onViewAPITesting}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <AlertTriangle className="w-4 h-4 mr-2" />
                      Debug API Now
                    </Button>
                  )}
                  
                  <Button
                    variant="outline"
                    onClick={() => window.open('https://console.cloud.google.com/apis/credentials', '_blank')}
                    className="border-purple-300 text-purple-700 hover:bg-purple-50"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Check API Key
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (errorType === '401') {
    return (
      <Card className="border-orange-200 bg-orange-50 shadow-lg">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <Key className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
            <div className="flex-1">
              <h3 className="font-semibold text-orange-900 mb-2">
                API Key Permission Denied (401 Error)
              </h3>
              <p className="text-orange-800 text-sm mb-4">
                Your API key <code className="bg-orange-100 px-1 rounded">AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8</code> is valid 
                and APIs are enabled, but it lacks permission to access your spreadsheet.
              </p>
              
              <div className="space-y-3">
                <div className="bg-orange-100 border border-orange-200 rounded-lg p-3">
                  <h4 className="font-medium text-orange-900 mb-2">Quick Fix Steps:</h4>
                  <ol className="text-sm text-orange-800 space-y-1 list-decimal list-inside">
                    <li>Remove API key restrictions (set to "None" and "Don't restrict key")</li>
                    <li>Share spreadsheet with service account (see email below)</li>
                    <li>Wait 30 seconds, then test connection</li>
                  </ol>
                </div>

                <div className="bg-orange-100 border border-orange-200 rounded-lg p-3">
                  <h4 className="font-medium text-orange-900 mb-1">Service Account Email:</h4>
                  <div className="flex items-center gap-2">
                    <code className="text-xs bg-white px-2 py-1 rounded border break-all">
                      attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com
                    </code>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => navigator.clipboard.writeText('attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com')}
                      className="border-orange-300"
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    onClick={() => window.open('https://console.cloud.google.com/apis/credentials', '_blank')}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Remove API Restrictions
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => window.open('https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY/edit', '_blank')}
                    className="border-orange-300 text-orange-700 hover:bg-orange-50"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Share Spreadsheet
                  </Button>
                  
                  {onView401Troubleshooting && (
                    <Button
                      variant="outline"
                      onClick={onView401Troubleshooting}
                      className="border-orange-300 text-orange-700 hover:bg-orange-50"
                    >
                      <AlertTriangle className="w-4 h-4 mr-2" />
                      Detailed Guide
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-red-200 bg-red-50 shadow-lg">
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
          <div className="flex-1">
            <h3 className="font-semibold text-red-900 mb-2">
              Google Sheets API Not Enabled
            </h3>
            <p className="text-red-800 text-sm mb-4">
              Your API key <code className="bg-red-100 px-1 rounded">AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8</code> is valid, 
              but the Google Sheets API is not enabled for your project "satra-attendance-tracker".
            </p>
            
            <div className="space-y-3">
              <div className="bg-red-100 border border-red-200 rounded-lg p-3">
                <h4 className="font-medium text-red-900 mb-2">Quick Fix Steps:</h4>
                <ol className="text-sm text-red-800 space-y-1 list-decimal list-inside">
                  <li>Click "Enable Google Sheets API" below</li>
                  <li>Select project "satra-attendance-tracker"</li>
                  <li>Click the blue "ENABLE" button</li>
                  <li>Wait 2-3 minutes, then refresh this page</li>
                </ol>
              </div>
              
              <div className="flex gap-2">
                <Button
                  onClick={() => window.open('https://console.cloud.google.com/apis/library/sheets.googleapis.com', '_blank')}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Enable Google Sheets API
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => window.open('https://console.cloud.google.com/apis/library/drive.googleapis.com', '_blank')}
                  className="border-red-300 text-red-700 hover:bg-red-50"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Enable Google Drive API
                </Button>
                
                {onViewTroubleshooting && (
                  <Button
                    variant="outline"
                    onClick={onViewTroubleshooting}
                    className="border-red-300 text-red-700 hover:bg-red-50"
                  >
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Detailed Guide
                  </Button>
                )}
                
                <Button
                  variant="outline"
                  onClick={() => {
                    localStorage.removeItem('google_sheets_403_error');
                    window.location.reload();
                  }}
                  className="border-green-300 text-green-700 hover:bg-green-50"
                  size="sm"
                >
                  ✓ I Fixed It - Retest
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}