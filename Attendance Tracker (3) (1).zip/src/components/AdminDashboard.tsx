import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "./ui/dialog";
import { Alert, AlertDescription } from "./ui/alert";
import { 
  Users, 
  UserCheck, 
  UserX, 
  Clock, 
  MapPin, 
  Search,
  Filter,
  Bell,
  Download,
  Calendar,
  TrendingUp,
  Building2,
  User,
  FileText,
  Database,
  BarChart3,
  Edit,
  Trash2,
  Key,
  Plus,
  Settings,
  Shield,
  AlertCircle,
  CheckCircle,
  X
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface AdminDashboardProps {
  onViewReports: () => void;
  onViewMap: () => void;
  onProfile: () => void;
  userData: {
    employeeId: string;
    name: string;
    designation: string;
  };
}

interface Employee {
  employeeId: string;
  name: string;
  designation: string;
  department: string;
  reportingManager: string;
  phoneNumber?: string;
  email?: string;
  status: 'active' | 'inactive';
  password?: string;
}

interface AttendanceRecord {
  employeeId: string;
  name: string;
  date: string;
  checkInTime?: string;
  checkOutTime?: string;
  status: string;
  location?: any;
  workLocation?: string;
  notes?: string;
}

export function AdminDashboard({ 
  onViewReports, 
  onViewMap, 
  onProfile, 
  userData 
}: AdminDashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterLocation, setFilterLocation] = useState('all');
  const [filterDate, setFilterDate] = useState('today');
  const [filterStatus, setFilterStatus] = useState('all');
  const [stats, setStats] = useState({
    totalEmployees: 200,
    presentToday: 185,
    absentToday: 12,
    onLeaveToday: 3
  });
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([]);
  const [locations] = useState([
    { name: 'Ahmedabad Region', present: 74, total: 80 },
    { name: 'Surat Region', present: 55, total: 60 },
    { name: 'Vadodara Region', present: 36, total: 40 },
    { name: 'Rajkot Region', present: 20, total: 20 }
  ]);
  const [isLoading, setIsLoading] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isPasswordResetDialogOpen, setIsPasswordResetDialogOpen] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedAttendanceRecord, setSelectedAttendanceRecord] = useState<AttendanceRecord | null>(null);
  const [isAttendanceEditDialogOpen, setIsAttendanceEditDialogOpen] = useState(false);

  const recentAlerts = [
    { id: 1, type: 'missing', worker: 'Rajesh Kumar (MGJ00272)', location: 'Ahmedabad', time: '10:30 AM' },
    { id: 2, type: 'late', worker: 'Priya Patel (MGJ00273)', location: 'Surat', time: '09:45 AM' },
    { id: 3, type: 'location', worker: 'Amit Shah (MGJ00274)', location: 'Vadodara', time: '09:15 AM' }
  ];

  const getAttendancePercentage = () => {
    // Get total number of registered DC/MT executives only (as per requirement)
    const dcMtExecutives = employees.filter(emp => 
      (emp.designation === 'DC' || emp.designation === 'MT') && emp.status === 'active'
    );
    
    if (dcMtExecutives.length === 0) return 0;
    
    // Get today's date
    const today = new Date().toISOString().split('T')[0];
    
    // Count total attendance marked today by DC/MT executives only
    const todayAttendanceCount = attendanceRecords.filter(record => 
      record.date === today && 
      dcMtExecutives.some(emp => emp.employeeId === record.employeeId)
    ).length;
    
    // Formula: (Total Count of Attendance Marked by DC/MT today / Total number of registered DC/MT executives) × 100
    return Math.round((todayAttendanceCount / dcMtExecutives.length) * 100);
  };

  // Load data on component mount
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        
        // Load employees
        const employeeData = JSON.parse(localStorage.getItem('employees') || '[]');
        const attendanceData = JSON.parse(localStorage.getItem('attendanceRecords') || '[]');
        
        // Add demo data if empty
        if (employeeData.length === 0) {
          const demoEmployees = [
            {
              employeeId: 'ADMIN01',
              name: 'Suresh Patel',
              designation: 'State Manager',
              department: 'Gujarat State',
              reportingManager: 'HEAD OFFICE',
              phoneNumber: '+91 98765 43200',
              email: 'suresh.patel@satraservices.com',
              status: 'active',
              password: 'admin123'
            },
            {
              employeeId: 'SAT001',
              name: 'Rajesh Kumar',
              designation: 'DC',
              department: 'Gujarat North',
              reportingManager: 'SURESH PATEL',
              phoneNumber: '+91 98765 43210',
              email: 'rajesh.kumar@satraservices.com',
              status: 'active',
              password: 'test123'
            },
            {
              employeeId: 'SAT002',
              name: 'Priya Patel',
              designation: 'MT',
              department: 'Gujarat South',
              reportingManager: 'SURESH PATEL',
              phoneNumber: '+91 98765 43211',
              email: 'priya.patel@satraservices.com',
              status: 'active',
              password: 'test123'
            }
          ];
          setEmployees(demoEmployees);
          localStorage.setItem('employees', JSON.stringify(demoEmployees));
        } else {
          setEmployees(employeeData);
        }
        
        setAttendanceRecords(attendanceData);
        
        // Calculate stats based on DC/MT executives only (as per updated requirement)
        const today = new Date().toISOString().split('T')[0];
        const dcMtExecutives = employeeData.filter((emp: any) => 
          (emp.designation === 'DC' || emp.designation === 'MT') && emp.status === 'active'
        );
        
        const todayRecords = attendanceData.filter((record: any) => record.date === today);
        const dcMtTodayRecords = todayRecords.filter((record: any) => 
          dcMtExecutives.some((emp: any) => emp.employeeId === record.employeeId)
        );
        
        const presentCount = dcMtTodayRecords.filter((record: any) => 
          record.status === 'present' || record.status === 'Present'
        ).length;
        
        // Total DC/MT registered executives (denominator in the formula)
        const totalDcMt = dcMtExecutives.length > 0 ? dcMtExecutives.length : 200;
        const absentCount = totalDcMt - presentCount; // DC/MT who haven't marked attendance
        
        setStats({
          totalEmployees: totalDcMt,
          presentToday: presentCount,
          absentToday: absentCount,
          onLeaveToday: 0 // No leave tracking for simplified flow
        });
        
        console.log('✅ Admin dashboard data loaded - using DC/MT-only attendance calculation');
      } catch (error) {
        console.error('Error loading data:', error);
        toast.error('Failed to load data');
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  // Filter employees based on search and filters
  useEffect(() => {
    let filtered = employees;
    
    if (searchTerm) {
      filtered = filtered.filter(emp => 
        emp.employeeId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        emp.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (filterStatus !== 'all') {
      filtered = filtered.filter(emp => emp.status === filterStatus);
    }
    
    setFilteredEmployees(filtered);
  }, [employees, searchTerm, filterStatus]);

  // CSV Export Functions
  const exportToCSV = (data: any[], filename: string, headers: string[]) => {
    const csvContent = [
      headers.join(','),
      ...data.map(row => headers.map(header => {
        const value = row[header.toLowerCase().replace(/ /g, '_')] || '';
        return typeof value === 'string' && (value.includes(',') || value.includes('"')) 
          ? `"${value.replace(/"/g, '""')}"` 
          : value;
      }).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportEmployees = async () => {
    setIsExporting(true);
    try {
      const headers = ['Employee ID', 'Name', 'Designation', 'Department', 'Reporting Manager', 'Phone Number', 'Email', 'Status'];
      const formattedData = employees.map((emp: Employee) => ({
        employee_id: emp.employeeId,
        name: emp.name,
        designation: emp.designation,
        department: emp.department,
        reporting_manager: emp.reportingManager,
        phone_number: emp.phoneNumber || 'N/A',
        email: emp.email || 'N/A',
        status: emp.status
      }));
      
      exportToCSV(formattedData, 'employees_data', headers);
      toast.success(`Employee data exported! (${formattedData.length} records)`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export employee data');
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportAttendance = async () => {
    setIsExporting(true);
    try {
      const headers = ['Employee ID', 'Name', 'Date', 'Check In Time', 'Check Out Time', 'Status', 'Location', 'Work Location', 'Notes'];
      const formattedData = attendanceRecords.map((record: AttendanceRecord) => ({
        employee_id: record.employeeId,
        name: record.name,
        date: record.date,
        check_in_time: record.checkInTime || 'N/A',
        check_out_time: record.checkOutTime || '',
        status: record.status,
        location: record.location?.address || 'N/A',
        work_location: record.workLocation || 'N/A',
        notes: record.notes || ''
      }));
      
      exportToCSV(formattedData, 'attendance_records', headers);
      toast.success(`Attendance data exported! (${formattedData.length} records)`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export attendance data');
    } finally {
      setIsExporting(false);
    }
  };

  const handleEditEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsEditDialogOpen(true);
  };

  const handleDeleteEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsDeleteDialogOpen(true);
  };

  const handlePasswordReset = (employee: Employee) => {
    setSelectedEmployee(employee);
    setNewPassword('');
    setIsPasswordResetDialogOpen(true);
  };

  const confirmDeleteEmployee = () => {
    if (!selectedEmployee) return;
    
    const updatedEmployees = employees.filter(emp => emp.employeeId !== selectedEmployee.employeeId);
    setEmployees(updatedEmployees);
    localStorage.setItem('employees', JSON.stringify(updatedEmployees));
    
    toast.success(`Employee ${selectedEmployee.name} deleted successfully`);
    setIsDeleteDialogOpen(false);
    setSelectedEmployee(null);
  };

  const saveEmployeeChanges = () => {
    if (!selectedEmployee) return;
    
    const updatedEmployees = employees.map(emp => 
      emp.employeeId === selectedEmployee.employeeId ? selectedEmployee : emp
    );
    setEmployees(updatedEmployees);
    localStorage.setItem('employees', JSON.stringify(updatedEmployees));
    
    toast.success(`Employee ${selectedEmployee.name} updated successfully`);
    setIsEditDialogOpen(false);
    setSelectedEmployee(null);
  };

  const resetPassword = () => {
    if (!selectedEmployee || !newPassword) {
      toast.error('Please enter a new password');
      return;
    }
    
    const updatedEmployees = employees.map(emp => 
      emp.employeeId === selectedEmployee.employeeId ? { ...emp, password: newPassword } : emp
    );
    setEmployees(updatedEmployees);
    localStorage.setItem('employees', JSON.stringify(updatedEmployees));
    
    toast.success(`Password reset for ${selectedEmployee.name}`);
    setIsPasswordResetDialogOpen(false);
    setSelectedEmployee(null);
    setNewPassword('');
  };

  const handleEditAttendance = (record: AttendanceRecord) => {
    setSelectedAttendanceRecord(record);
    setIsAttendanceEditDialogOpen(true);
  };

  const saveAttendanceChanges = () => {
    if (!selectedAttendanceRecord) return;
    
    const updatedRecords = attendanceRecords.map(record => 
      record.employeeId === selectedAttendanceRecord.employeeId && record.date === selectedAttendanceRecord.date
        ? selectedAttendanceRecord : record
    );
    setAttendanceRecords(updatedRecords);
    localStorage.setItem('attendanceRecords', JSON.stringify(updatedRecords));
    
    toast.success(`Attendance updated for ${selectedAttendanceRecord.name}`);
    setIsAttendanceEditDialogOpen(false);
    setSelectedAttendanceRecord(null);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            {/* Quick Stats */}
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <Card key={i} className="shadow-md">
                    <CardContent className="pt-6">
                      <div className="animate-pulse">
                        <div className="h-8 bg-gray-200 rounded mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="shadow-md">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-blue-600" />
                      <div>
                        <div className="text-2xl font-bold text-blue-600">{stats.totalEmployees}</div>
                        <p className="text-sm text-muted-foreground">Total Employees</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-md">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2">
                      <UserCheck className="w-5 h-5 text-green-600" />
                      <div>
                        <div className="text-2xl font-bold text-green-600">{stats.presentToday}</div>
                        <p className="text-sm text-muted-foreground">Present Today</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-md">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2">
                      <UserX className="w-5 h-5 text-red-600" />
                      <div>
                        <div className="text-2xl font-bold text-red-600">{stats.absentToday}</div>
                        <p className="text-sm text-muted-foreground">Absent Today</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-md">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-orange-600" />
                      <div>
                        <div className="text-2xl font-bold text-orange-600">{stats.onLeaveToday}</div>
                        <p className="text-sm text-muted-foreground">On Leave</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Location Overview and Alerts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Location Overview */}
              <Card className="shadow-md">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5" />
                    Location Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {locations.map((location, index) => {
                      const percentage = Math.round((location.present / location.total) * 100);
                      return (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">{location.name}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-muted-foreground">
                                {location.present}/{location.total}
                              </span>
                              <Badge variant={percentage >= 90 ? "default" : percentage >= 80 ? "secondary" : "destructive"}>
                                {percentage}%
                              </Badge>
                            </div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                percentage >= 90 ? 'bg-green-500' : 
                                percentage >= 80 ? 'bg-orange-500' : 'bg-red-500'
                              }`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <Button onClick={onViewMap} variant="outline" className="w-full mt-4">
                    <MapPin className="w-4 h-4 mr-2" />
                    View Live Map
                  </Button>
                </CardContent>
              </Card>

              {/* Alerts & Notifications */}
              <Card className="shadow-md">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5" />
                    Recent Alerts
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recentAlerts.map((alert) => (
                      <div key={alert.id} className="p-3 bg-gray-50 rounded-lg border-l-4 border-l-accent">
                        <div className="flex items-start gap-3">
                          <div className={`w-2 h-2 rounded-full mt-2 ${
                            alert.type === 'missing' ? 'bg-red-500' :
                            alert.type === 'late' ? 'bg-orange-500' : 'bg-blue-500'
                          }`} />
                          <div className="flex-1">
                            <p className="text-sm font-medium">
                              {alert.type === 'missing' ? 'Missing Check-in' :
                               alert.type === 'late' ? 'Late Arrival' : 'Location Mismatch'}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {alert.worker} • {alert.location}
                            </p>
                            <p className="text-xs text-muted-foreground">{alert.time}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 'employees':
        return (
          <div className="space-y-6">
            {/* Employee Management Header */}
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Employee Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                  <div className="flex flex-col md:flex-row gap-4 items-center">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search employees..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add Employee
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Employee List */}
            <Card className="shadow-md">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="text-left p-4 font-medium">Employee ID</th>
                        <th className="text-left p-4 font-medium">Name</th>
                        <th className="text-left p-4 font-medium">Designation</th>
                        <th className="text-left p-4 font-medium">Department</th>
                        <th className="text-left p-4 font-medium">Status</th>
                        <th className="text-left p-4 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredEmployees.map((employee) => (
                        <tr key={employee.employeeId} className="border-b hover:bg-gray-50">
                          <td className="p-4 font-medium">{employee.employeeId}</td>
                          <td className="p-4">{employee.name}</td>
                          <td className="p-4">
                            <Badge variant={employee.designation === 'DC' || employee.designation === 'MT' ? 'secondary' : 'default'}>
                              {employee.designation}
                            </Badge>
                          </td>
                          <td className="p-4">{employee.department}</td>
                          <td className="p-4">
                            <Badge variant={employee.status === 'active' ? 'default' : 'destructive'}>
                              {employee.status}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleEditEmployee(employee)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handlePasswordReset(employee)}
                              >
                                <Key className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDeleteEmployee(employee)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'attendance':
        return (
          <div className="space-y-6">
            {/* Attendance Management Header */}
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Attendance Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                  <div className="flex flex-col md:flex-row gap-4 items-center">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search by employee ID or name..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                    <Select value={filterDate} onValueChange={setFilterDate}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="today">Today</SelectItem>
                        <SelectItem value="week">This Week</SelectItem>
                        <SelectItem value="month">This Month</SelectItem>
                        <SelectItem value="all">All Records</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Attendance Records List */}
            <Card className="shadow-md">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="text-left p-4 font-medium">Employee</th>
                        <th className="text-left p-4 font-medium">Date</th>
                        <th className="text-left p-4 font-medium">Check In</th>
                        <th className="text-left p-4 font-medium">Status</th>
                        <th className="text-left p-4 font-medium">Location</th>
                        <th className="text-left p-4 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {attendanceRecords
                        .filter(record => {
                          if (searchTerm) {
                            return record.employeeId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                   record.name.toLowerCase().includes(searchTerm.toLowerCase());
                          }
                          return true;
                        })
                        .slice(0, 20) // Limit to 20 records for performance
                        .map((record, index) => (
                        <tr key={`${record.employeeId}-${record.date}-${index}`} className="border-b hover:bg-gray-50">
                          <td className="p-4">
                            <div>
                              <div className="font-medium">{record.name}</div>
                              <div className="text-sm text-muted-foreground">{record.employeeId}</div>
                            </div>
                          </td>
                          <td className="p-4">{new Date(record.date).toLocaleDateString('en-IN')}</td>
                          <td className="p-4">
                            {record.checkInTime ? 
                              new Date(record.checkInTime).toLocaleTimeString('en-IN', { 
                                hour: '2-digit', 
                                minute: '2-digit',
                                hour12: true 
                              }) : 'Not recorded'}
                          </td>
                          <td className="p-4">
                            <Badge variant={
                              record.status === 'present' ? 'default' : 
                              record.status === 'absent' ? 'destructive' : 'secondary'
                            }>
                              {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <div className="text-sm">
                              {record.location?.address ? 
                                record.location.address.substring(0, 30) + (record.location.address.length > 30 ? '...' : '') : 
                                'No location'
                              }
                            </div>
                          </td>
                          <td className="p-4">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditAttendance(record)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {attendanceRecords.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    No attendance records found
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        );

      case 'exports':
        return (
          <div className="space-y-6">
            {/* Data Export Section */}
            <Card className="shadow-md border-accent/20 bg-gradient-to-r from-accent/5 to-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <Download className="w-5 h-5" />
                  Data Export Center
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button
                    onClick={handleExportEmployees}
                    disabled={isExporting}
                    className="h-20 flex flex-col items-center justify-center gap-2 bg-primary hover:bg-primary/90"
                  >
                    <Users className="w-6 h-6" />
                    <span>Export Employees</span>
                    {isExporting && <span className="text-xs">Exporting...</span>}
                  </Button>

                  <Button
                    onClick={handleExportAttendance}
                    disabled={isExporting}
                    className="h-20 flex flex-col items-center justify-center gap-2 bg-accent hover:bg-accent/90"
                  >
                    <FileText className="w-6 h-6" />
                    <span>Export Attendance</span>
                    {isExporting && <span className="text-xs">Exporting...</span>}
                  </Button>

                  <Button
                    onClick={() => {}}
                    disabled={isExporting}
                    className="h-20 flex flex-col items-center justify-center gap-2 bg-primary hover:bg-primary/90"
                  >
                    <BarChart3 className="w-6 h-6" />
                    <span>Export Reports</span>
                    {isExporting && <span className="text-xs">Exporting...</span>}
                  </Button>
                </div>
                <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-start gap-2">
                    <Database className="w-4 h-4 text-blue-600 mt-0.5" />
                    <div className="text-sm text-blue-800">
                      <p className="font-medium">Export Information:</p>
                      <ul className="mt-1 text-xs space-y-1 text-blue-700">
                        <li>• CSV files include all employee and attendance data</li>
                        <li>• Files are timestamped for easy organization</li>
                        <li>• Data includes complete audit trail and location information</li>
                        <li>• Compatible with Excel and other spreadsheet applications</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-primary">Satra Services Admin</h1>
                <p className="text-sm text-muted-foreground">Administrative Management Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="p-2 relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full text-xs"></span>
              </Button>
              <Button variant="ghost" size="sm" onClick={onProfile} className="p-2">
                <User className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Welcome Section */}
        <Card className="bg-primary text-white shadow-lg">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold">Welcome, {userData.name}</h2>
                <p className="text-white/80">{userData.employeeId} • {userData.designation}</p>
                <p className="text-sm text-white/70 mt-1">
                  Administrative access to manage all executive operations
                </p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold">{getAttendancePercentage()}%</div>
                <p className="text-sm text-white/80">Overall Attendance (DC/MT)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation Tabs */}
        <Card className="shadow-md">
          <CardContent className="p-0">
            <div className="flex border-b">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`px-6 py-4 font-medium ${
                  activeTab === 'dashboard' 
                    ? 'text-primary border-b-2 border-primary bg-primary/5' 
                    : 'text-muted-foreground hover:text-primary'
                }`}
              >
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Dashboard
                </div>
              </button>
              <button
                onClick={() => setActiveTab('employees')}
                className={`px-6 py-4 font-medium ${
                  activeTab === 'employees' 
                    ? 'text-primary border-b-2 border-primary bg-primary/5' 
                    : 'text-muted-foreground hover:text-primary'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Employee Management
                </div>
              </button>
              <button
                onClick={() => setActiveTab('attendance')}
                className={`px-6 py-4 font-medium ${
                  activeTab === 'attendance' 
                    ? 'text-primary border-b-2 border-primary bg-primary/5' 
                    : 'text-muted-foreground hover:text-primary'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Attendance
                </div>
              </button>
              <button
                onClick={() => setActiveTab('exports')}
                className={`px-6 py-4 font-medium ${
                  activeTab === 'exports' 
                    ? 'text-primary border-b-2 border-primary bg-primary/5' 
                    : 'text-muted-foreground hover:text-primary'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Download className="w-4 h-4" />
                  Data Export
                </div>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Tab Content */}
        {renderTabContent()}

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Button 
            onClick={onViewReports}
            className="h-16 flex items-center justify-center gap-3 bg-accent hover:bg-accent/90"
          >
            <TrendingUp className="w-6 h-6" />
            <span className="text-lg">View Reports</span>
          </Button>

          <Button 
            onClick={onViewMap}
            className="h-16 flex items-center justify-center gap-3 bg-primary hover:bg-primary/90"
          >
            <MapPin className="w-6 h-6" />
            <span className="text-lg">Live Location Map</span>
          </Button>

          <Button 
            variant="outline"
            className="h-16 flex items-center justify-center gap-3 border-primary/20 hover:bg-primary/5"
          >
            <Settings className="w-6 h-6 text-primary" />
            <span className="text-lg">System Settings</span>
          </Button>
        </div>
      </div>

      {/* Edit Employee Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Employee</DialogTitle>
            <DialogDescription>
              Update employee information and settings.
            </DialogDescription>
          </DialogHeader>
          {selectedEmployee && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Name</label>
                <Input
                  value={selectedEmployee.name}
                  onChange={(e) => setSelectedEmployee({...selectedEmployee, name: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Designation</label>
                <Select
                  value={selectedEmployee.designation}
                  onValueChange={(value) => setSelectedEmployee({...selectedEmployee, designation: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DC">DC</SelectItem>
                    <SelectItem value="MT">MT</SelectItem>
                    <SelectItem value="HR">HR</SelectItem>
                    <SelectItem value="Manager">Manager</SelectItem>
                    <SelectItem value="SPMU">SPMU</SelectItem>
                    <SelectItem value="Delivery Head">Delivery Head</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Department</label>
                <Input
                  value={selectedEmployee.department}
                  onChange={(e) => setSelectedEmployee({...selectedEmployee, department: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Phone Number</label>
                <Input
                  value={selectedEmployee.phoneNumber || ''}
                  onChange={(e) => setSelectedEmployee({...selectedEmployee, phoneNumber: e.target.value})}
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={saveEmployeeChanges} className="flex-1">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
                <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Employee Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Employee</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete the employee from the system.
            </DialogDescription>
          </DialogHeader>
          {selectedEmployee && (
            <div className="space-y-4">
              <Alert className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  Are you sure you want to delete <strong>{selectedEmployee.name}</strong>? This action cannot be undone.
                </AlertDescription>
              </Alert>
              <div className="flex gap-2">
                <Button variant="destructive" onClick={confirmDeleteEmployee} className="flex-1">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Employee
                </Button>
                <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Password Reset Dialog */}
      <Dialog open={isPasswordResetDialogOpen} onOpenChange={setIsPasswordResetDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
            <DialogDescription>
              Enter a new password for this employee. They will need to use this password to log in.
            </DialogDescription>
          </DialogHeader>
          {selectedEmployee && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Reset password for <strong>{selectedEmployee.name}</strong> ({selectedEmployee.employeeId})
              </p>
              <div>
                <label className="text-sm font-medium">New Password</label>
                <Input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={resetPassword} className="flex-1" disabled={!newPassword}>
                  <Key className="w-4 h-4 mr-2" />
                  Reset Password
                </Button>
                <Button variant="outline" onClick={() => setIsPasswordResetDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Attendance Edit Dialog */}
      <Dialog open={isAttendanceEditDialogOpen} onOpenChange={setIsAttendanceEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Attendance Record</DialogTitle>
            <DialogDescription>
              Modify attendance details for {selectedAttendanceRecord?.name}
            </DialogDescription>
          </DialogHeader>
          {selectedAttendanceRecord && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <span className="text-muted-foreground">Employee:</span>
                <span>{selectedAttendanceRecord.name}</span>
                <span className="text-muted-foreground">Date:</span>
                <span>{new Date(selectedAttendanceRecord.date).toLocaleDateString('en-IN')}</span>
              </div>
              
              <div>
                <label className="text-sm font-medium">Status</label>
                <Select 
                  value={selectedAttendanceRecord.status} 
                  onValueChange={(value: 'present' | 'absent' | 'half-day') => 
                    setSelectedAttendanceRecord({...selectedAttendanceRecord, status: value})
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="present">Present</SelectItem>
                    <SelectItem value="absent">Absent</SelectItem>
                    <SelectItem value="half-day">Half Day</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium">Check In Time</label>
                <Input
                  type="time"
                  value={selectedAttendanceRecord.checkInTime ? 
                    new Date(selectedAttendanceRecord.checkInTime).toLocaleTimeString('en-GB', {hour: '2-digit', minute: '2-digit'}) : 
                    ''
                  }
                  onChange={(e) => {
                    if (e.target.value) {
                      const [hours, minutes] = e.target.value.split(':');
                      const date = new Date(selectedAttendanceRecord.date);
                      date.setHours(parseInt(hours), parseInt(minutes));
                      setSelectedAttendanceRecord({
                        ...selectedAttendanceRecord, 
                        checkInTime: date.toISOString()
                      });
                    }
                  }}
                />
              </div>

              <div>
                <label className="text-sm font-medium">Notes</label>
                <Textarea
                  value={selectedAttendanceRecord.notes || ''}
                  onChange={(e) => 
                    setSelectedAttendanceRecord({...selectedAttendanceRecord, notes: e.target.value})
                  }
                  placeholder="Additional notes..."
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={saveAttendanceChanges} className="flex-1">
                  <Clock className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
                <Button variant="outline" onClick={() => setIsAttendanceEditDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}