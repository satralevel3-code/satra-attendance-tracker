import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { Eye, EyeOff, Building2, Users, UserCheck, AlertCircle } from "lucide-react";
// Removed attendanceAPI import - using local auth only
import { toast } from "sonner@2.0.3";

// Local storage fallback for authentication
const localAuthService = {
  async validateCredentials(employeeId: string, password: string) {
    try {
      // Check local storage first
      const employees = JSON.parse(localStorage.getItem('employees') || '[]');
      const user = employees.find((emp: any) => 
        emp.employeeId === employeeId && emp.password === password
      );
      
      if (user) {
        return user;
      }
      
      // Check default demo users if not found in local storage
      const demoUsers = [
        {
          employeeId: 'ADMIN01',
          name: 'Suresh Patel',
          designation: 'State Manager',
          department: 'Gujarat State',
          reportingManager: 'HEAD OFFICE',
          password: 'admin123'
        },
        {
          employeeId: 'HR001',
          name: 'Neha Sharma',
          designation: 'HR',
          department: 'Human Resources',
          reportingManager: 'SURESH PATEL',
          password: 'hr123'
        },
        {
          employeeId: 'MGR001',
          name: 'Amit Desai',
          designation: 'Manager',
          department: 'Operations',
          reportingManager: 'SURESH PATEL',
          password: 'mgr123'
        },
        {
          employeeId: 'DC001',
          name: 'Rajesh Kumar',
          designation: 'DC',
          department: 'Gujarat North',
          reportingManager: 'SURESH PATEL',
          password: 'dc123'
        },
        {
          employeeId: 'MT001',
          name: 'Priya Patel',
          designation: 'MT',
          department: 'Gujarat South',
          reportingManager: 'SURESH PATEL',
          password: 'mt123'
        }
      ];
      
      return demoUsers.find(user => 
        user.employeeId === employeeId && user.password === password
      ) || null;
    } catch (error) {
      console.error('Local auth error:', error);
      return null;
    }
  }
};
import { Alert, AlertDescription } from "./ui/alert";

interface LoginScreenProps {
  onLogin: (userType: 'executive' | 'admin', userData: any) => void;
  onCreateProfile: () => void;
}

export function LoginScreen({ onLogin, onCreateProfile }: LoginScreenProps) {
  const [loginType, setLoginType] = useState<'executive' | 'admin'>('executive');
  const [employeeId, setEmployeeId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    setIsLoading(true);
    setError('');
    
    try {
      let user = null;
      
      // Use local authentication only
      user = await localAuthService.validateCredentials(employeeId.toUpperCase(), password);
      if (user) {
        console.log('✅ Logged in via local storage');
        toast.success('Login successful!');
        
        // Determine user type based on designation
        // Executives: DC and MT only
        // Admins: HR, Manager, SPMU, Delivery Head, State Manager
        const executiveDesignations = ['DC', 'MT'];
        const adminDesignations = ['HR', 'Manager', 'SPMU', 'Delivery Head', 'State Manager'];
        
        let userType: 'executive' | 'admin';
        if (executiveDesignations.includes(user.designation)) {
          userType = 'executive';
        } else if (adminDesignations.includes(user.designation) || loginType === 'admin') {
          userType = 'admin';
        } else {
          // Default based on login type selection
          userType = loginType;
        }
        
        const userData = {
          employeeId: user.employeeId,
          userType,
          name: user.name || user.fullName,
          designation: user.designation,
          department: user.department || user.dccb,
          reportingManager: user.reportingManager || user.reportingTo
        };
        
        onLogin(userType, userData);
      } else {
        setError('Invalid credentials. Please check your Employee ID and password.');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('Login failed. Please check your connection and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const isFormValid = employeeId.length >= 8 && password.length >= 6;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex flex-col">
      {/* Header with Logo */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-sm mx-auto px-6 py-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <div className="text-center">
              <h1 className="text-xl font-semibold text-primary">Satra Services</h1>
              <p className="text-sm text-muted-foreground">Attendance Tracker</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-6">


          {/* Login Form */}
          <Card className="shadow-lg">
            <CardHeader className="pb-4">
              <CardTitle className="text-center">
                {loginType === 'executive' ? 'Executive Login' : 'Admin Login'}
              </CardTitle>
              <div className="flex justify-center">
                <Badge variant="outline" className="text-xs">
                  {loginType === 'executive' ? 'MT & DC Only' : 'HR, Manager, SPMU, Delivery Head'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="employeeId">Employee ID</Label>
                <Input
                  id="employeeId"
                  placeholder="e.g., MGJ00272"
                  value={employeeId}
                  onChange={(e) => setEmployeeId(e.target.value.toUpperCase())}
                  className="bg-input-background"
                />
                <p className="text-xs text-muted-foreground">
                  Format: 3 letters + 5 digits (e.g., MGJ00272)
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-input-background pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
              </div>

              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              <Button
                onClick={handleLogin}
                disabled={!isFormValid || isLoading}
                className="w-full h-12 bg-primary hover:bg-primary/90"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Signing In...
                  </div>
                ) : (
                  'Sign In'
                )}
              </Button>

              <div className="space-y-3 pt-2">
                <Button
                  variant="link"
                  className="w-full text-sm text-muted-foreground p-0 h-auto"
                >
                  Forgot Password?
                </Button>
                
                {loginType === 'executive' && (
                  <Button
                    variant="outline"
                    onClick={onCreateProfile}
                    className="w-full h-10 border-accent text-accent hover:bg-accent hover:text-white"
                  >
                    Create Profile
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>




        </div>
      </div>

      {/* Footer */}
      <div className="bg-white border-t">
        <div className="max-w-sm mx-auto px-6 py-4 text-center">
          <p className="text-xs text-muted-foreground">
            © 2024 Satra Services. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Gujarat State Executive Management System
          </p>
        </div>
      </div>
    </div>
  );
}