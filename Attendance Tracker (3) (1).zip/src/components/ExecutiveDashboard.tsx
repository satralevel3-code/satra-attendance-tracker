import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { 
  Camera, 
  MapPin, 
  Clock, 
  CheckCircle, 
  XCircle,
  Calendar,
  HelpCircle,
  Bell,
  User,
  Building2
} from "lucide-react";
import { OfflineModeIndicator } from "./OfflineModeIndicator";
// Removed attendanceAPI import - using local storage only

interface ExecutiveDashboardProps {
  onMarkAttendance: () => void;
  onViewHistory: () => void;
  onProfile: () => void;
  userData: {
    employeeId: string;
    name: string;
    designation: string;
    dccb?: string;
    reportingTo?: string;
    department?: string;
    reportingManager?: string;
  };
}

export function ExecutiveDashboard({ 
  onMarkAttendance, 
  onViewHistory, 
  onProfile, 
  userData 
}: ExecutiveDashboardProps) {
  const [todayStatus, setTodayStatus] = useState<'present' | 'absent' | 'half-day' | null>(null);
  const [hasMarkedToday, setHasMarkedToday] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isActive, setIsActive] = useState(true);
  const [missedDays, setMissedDays] = useState(0);

  const currentTime = new Date().toLocaleTimeString('en-IN', { 
    timeZone: 'Asia/Kolkata',
    hour12: true,
    hour: '2-digit',
    minute: '2-digit'
  });

  const currentDate = new Date().toLocaleDateString('en-IN', { 
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const assignedLocation = userData.dccb ? `${userData.dccb} DCCB` : "Not Assigned";
  const reportingManager = userData.reportingTo || "Not Assigned";

  // Check today's attendance from local storage
  useEffect(() => {
    const checkTodayAttendance = () => {
      try {
        const attendanceRecords = JSON.parse(localStorage.getItem('attendanceRecords') || '[]');
        const today = new Date().toISOString().split('T')[0];
        const todayRecord = attendanceRecords.find((record: any) => 
          record.employeeId === userData.employeeId && record.date === today
        );
        
        if (todayRecord) {
          setTodayStatus(todayRecord.status.toLowerCase());
          setHasMarkedToday(true);
        }
      } catch (error) {
        console.error('Error checking today attendance:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkTodayAttendance();
  }, [userData.employeeId]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Building2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-primary">Satra Services</h1>
                <p className="text-sm text-muted-foreground">Executive Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="p-2">
                <Bell className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm" onClick={onProfile} className="p-2">
                <User className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* User Info Card */}
      <div className="max-w-md mx-auto p-6">
        <Card className="bg-primary text-white shadow-lg">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16 border-2 border-white/20">
                <AvatarImage src="" />
                <AvatarFallback className="bg-white/20 text-white text-lg">
                  {userData.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h2 className="text-xl font-semibold">{userData.name}</h2>
                <p className="text-white/80">{userData.employeeId}</p>
                <Badge variant="secondary" className="mt-1 bg-white/20 text-white border-white/30">
                  {userData.designation}
                </Badge>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-white/20">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-white/60">DCCB</p>
                  <p className="font-medium">{userData.dccb || 'Not Assigned'}</p>
                </div>
                <div>
                  <p className="text-white/60">Status</p>
                  <p className="font-medium">
                    <Badge 
                      variant="secondary" 
                      className={hasMarkedToday ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                    >
                      {hasMarkedToday ? 'Active' : 'Inactive'}
                    </Badge>
                  </p>
                </div>
                <div className="col-span-2">
                  <p className="text-white/60">Reporting To</p>
                  <p className="font-medium">{reportingManager}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Time & Date */}
        <Card className="mt-4 shadow-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{currentTime}</div>
              <div className="text-sm text-muted-foreground mt-1">{currentDate}</div>
            </div>
          </CardContent>
        </Card>

        {/* Today's Status */}
        <Card className="mt-4 shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Calendar className="w-5 h-5" />
              Today's Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-4">
                <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-3" />
                <p className="text-muted-foreground">Checking attendance...</p>
              </div>
            ) : !hasMarkedToday ? (
              <div className="text-center py-4">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Clock className="w-8 h-8 text-gray-400" />
                </div>
                <p className="text-gray-600 mb-4">Attendance not marked yet</p>
                <Badge variant="outline" className="text-orange-600 border-orange-200 bg-orange-50">
                  Pending
                </Badge>
              </div>
            ) : (
              <div className="text-center py-4">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 ${
                  todayStatus === 'present' ? 'bg-green-100' :
                  todayStatus === 'half-day' ? 'bg-orange-100' : 'bg-red-100'
                }`}>
                  {todayStatus === 'present' ? (
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  ) : todayStatus === 'half-day' ? (
                    <Clock className="w-8 h-8 text-orange-600" />
                  ) : (
                    <XCircle className="w-8 h-8 text-red-600" />
                  )}
                </div>
                <p className="font-medium mb-2 capitalize">
                  {todayStatus === 'present' ? 'Present' : 
                   todayStatus === 'half day' ? 'Half Day' : 
                   todayStatus === 'absent' ? 'Absent' : todayStatus}
                </p>
                <Badge variant={
                  todayStatus === 'present' ? 'default' : 
                  todayStatus === 'half day' ? 'secondary' : 'destructive'
                } className={
                  todayStatus === 'present' ? 'bg-green-100 text-green-800' : 
                  todayStatus === 'half day' ? 'bg-orange-100 text-orange-800' : ''
                }>
                  Marked Today
                </Badge>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Mark Attendance Button */}
        <div className="mt-6">
          <Button
            onClick={onMarkAttendance}
            disabled={hasMarkedToday}
            className="w-full h-16 text-lg bg-accent hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Camera className="w-6 h-6 mr-3" />
            {hasMarkedToday ? 'Attendance Marked' : 'Mark Attendance'}
          </Button>
          {hasMarkedToday && (
            <p className="text-xs text-center text-muted-foreground mt-2">
              You can only mark attendance once per day
            </p>
          )}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4 mt-6">
          <Button
            variant="outline"
            onClick={onViewHistory}
            className="h-16 flex flex-col gap-2 border-primary/20 hover:bg-primary/5"
          >
            <Calendar className="w-6 h-6 text-primary" />
            <span className="text-sm">View History</span>
          </Button>
          
          <Button
            variant="outline"
            className="h-16 flex flex-col gap-2 border-primary/20 hover:bg-primary/5"
          >
            <HelpCircle className="w-6 h-6 text-primary" />
            <span className="text-sm">Help & Support</span>
          </Button>
        </div>

        {/* Location Info */}
        <Card className="mt-6 shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <MapPin className="w-5 h-5" />
              Assigned Location
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">DCCB</span>
                <span className="font-medium">{assignedLocation}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Status</span>
                <Badge className="bg-green-100 text-green-800">Active</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card className="mt-6 bg-blue-50 border-blue-200 shadow-md">
          <CardContent className="pt-6">
            <h4 className="font-medium text-blue-900 mb-2">Daily Reminder</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Mark attendance with workplace photo</li>
              <li>• Ensure GPS location is enabled</li>
              <li>• Fill task and workplace details</li>
              <li>• Contact support for any issues</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}