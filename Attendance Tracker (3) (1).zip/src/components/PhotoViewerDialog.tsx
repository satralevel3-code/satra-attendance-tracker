import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { 
  X, 
  MapPin, 
  Clock, 
  User, 
  Building, 
  FileText,
  Download,
  ExternalLink 
} from "lucide-react";
import { formatDateTimeIST } from "../utils/timezone";

interface AttendanceRecord {
  employeeId: string;
  name?: string;
  fullName?: string;
  date: string;
  status: string;
  task?: string;
  workLocation?: string;
  timestamp?: string;
  checkInTime?: string;
  photoUrl?: string;
  location?: {
    latitude: number;
    longitude: number;
    accuracy: number;
    address: string;
  };
  reportingManager?: string;
  reportingTo?: string;
}

interface PhotoViewerDialogProps {
  record: AttendanceRecord | null;
  isOpen: boolean;
  onClose: () => void;
}

export function PhotoViewerDialog({ record, isOpen, onClose }: PhotoViewerDialogProps) {
  if (!record) return null;

  const handleDownloadPhoto = () => {
    if (!record.photoUrl) return;
    
    const link = document.createElement('a');
    link.href = record.photoUrl;
    link.download = `attendance_photo_${record.employeeId}_${record.date}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleOpenMap = () => {
    if (!record.location) return;
    
    const { latitude, longitude } = record.location;
    const mapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
    window.open(mapsUrl, '_blank');
  };

  const getStatusBadge = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'present':
        return <Badge className="bg-green-100 text-green-800">Present</Badge>;
      case 'half-day':
      case 'half day':
        return <Badge className="bg-orange-100 text-orange-800">Half Day</Badge>;
      case 'absent':
        return <Badge className="bg-red-100 text-red-800">Absent</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <User className="w-5 h-5" />
              <span>Attendance Details</span>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Employee Info */}
          <div className="bg-gray-50 rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">{record.name || record.fullName || 'N/A'}</h3>
                <p className="text-sm text-muted-foreground font-mono">{record.employeeId}</p>
              </div>
              {getStatusBadge(record.status)}
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm pt-2">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Date & Time</p>
                  <p className="font-medium">
                    {record.timestamp || record.checkInTime 
                      ? formatDateTimeIST(record.timestamp || record.checkInTime!)
                      : record.date
                    }
                  </p>
                </div>
              </div>
              
              {record.task && (
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Task</p>
                    <p className="font-medium">{record.task}</p>
                  </div>
                </div>
              )}
              
              {record.workLocation && (
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Workplace</p>
                    <p className="font-medium">{record.workLocation}</p>
                  </div>
                </div>
              )}
              
              {(record.reportingManager || record.reportingTo) && (
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Reporting To</p>
                    <p className="font-medium">{record.reportingManager || record.reportingTo}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Photo */}
          {record.photoUrl ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Captured Photo</h4>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDownloadPhoto}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
              <div className="rounded-lg overflow-hidden border bg-gray-50">
                <img 
                  src={record.photoUrl} 
                  alt="Attendance Photo" 
                  className="w-full h-auto object-contain max-h-96"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgZmlsbD0iI2YzZjRmNiIvPjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9IiM5Y2EzYWYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj5QaG90byBOb3QgQXZhaWxhYmxlPC90ZXh0Pjwvc3ZnPg==';
                  }}
                />
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 rounded-lg p-8 text-center">
              <Camera className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">No photo captured for this record</p>
            </div>
          )}

          {/* Location */}
          {record.location && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-medium flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Location Details
                </h4>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleOpenMap}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open in Maps
                </Button>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 space-y-2 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground">Address</p>
                  <p className="font-medium">{record.location.address}</p>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Latitude</p>
                    <p className="font-mono text-sm">{record.location.latitude.toFixed(6)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Longitude</p>
                    <p className="font-mono text-sm">{record.location.longitude.toFixed(6)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Accuracy</p>
                    <p className="font-mono text-sm">±{Math.round(record.location.accuracy)}m</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}