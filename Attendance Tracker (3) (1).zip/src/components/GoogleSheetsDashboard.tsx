import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Input } from "./ui/input";
import { 
  Users, 
  CheckCircle, 
  XCircle, 
  Clock, 
  MapPin, 
  Calendar,
  BarChart3,
  Download,
  RefreshCw,
  Search,
  Filter,
  ExternalLink,
  AlertCircle
} from "lucide-react";
import { googleSheetsService, type AttendanceRecord, type Employee } from "../services/GoogleSheetsService";
import { toast } from "sonner";

interface DashboardStats {
  totalEmployees: number;
  presentToday: number;
  absentToday: number;
  halfDayToday: number;
  attendanceRate: number;
  monthlyAttendance: {
    present: number;
    absent: number;
    halfDay: number;
  };
}

export function GoogleSheetsDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalEmployees: 0,
    presentToday: 0,
    absentToday: 0,
    halfDayToday: 0,
    attendanceRate: 0,
    monthlyAttendance: { present: 0, absent: 0, halfDay: 0 }
  });
  
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [filteredRecords, setFilteredRecords] = useState<AttendanceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState<{ connected: boolean; lastSync?: string; error?: string }>({ connected: false });
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("today");
  const [selectedEmployee, setSelectedEmployee] = useState<string>("all");

  const today = new Date().toISOString().split('T')[0];
  const thisMonth = today.substring(0, 7);

  useEffect(() => {
    loadDashboardData();
  }, []);

  useEffect(() => {
    filterRecords();
  }, [attendanceRecords, searchTerm, statusFilter, dateFilter, selectedEmployee]);

  const loadDashboardData = async () => {
    setIsLoading(true);
    setIsRefreshing(true);
    
    try {
      // Check connection status first
      const status = await googleSheetsService.getConnectionStatus();
      setConnectionStatus(status);

      if (!status.connected) {
        toast.error(`Unable to connect to Google Sheets: ${status.error}`);
        return;
      }

      // Use the new syncAllData method for better performance
      const { employees: employeeData, attendanceRecords: allRecords, attendanceSummary } = await googleSheetsService.syncAllData();
      
      setEmployees(employeeData);
      setAttendanceRecords(allRecords);

      // Filter today's records
      const todayRecords = allRecords.filter(record => record.date === today);
      
      // Calculate stats
      const presentToday = todayRecords.filter(r => r.status === 'present').length;
      const absentToday = employeeData.length - todayRecords.length;
      const halfDayToday = todayRecords.filter(r => r.status === 'half-day').length;
      const attendanceRate = employeeData.length > 0 ? ((presentToday + halfDayToday * 0.5) / employeeData.length) * 100 : 0;

      // Filter monthly records
      const monthlyRecords = allRecords.filter(record => record.date.startsWith(thisMonth));
      const monthlyPresent = monthlyRecords.filter(r => r.status === 'present').length;
      const monthlyAbsent = monthlyRecords.filter(r => r.status === 'absent').length;
      const monthlyHalfDay = monthlyRecords.filter(r => r.status === 'half-day').length;

      setStats({
        totalEmployees: employeeData.length,
        presentToday,
        absentToday,
        halfDayToday,
        attendanceRate,
        monthlyAttendance: {
          present: monthlyPresent,
          absent: monthlyAbsent,
          halfDay: monthlyHalfDay
        }
      });

      toast.success('Dashboard data synchronized successfully');
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast.error('Failed to load dashboard data from Google Sheets');
      setConnectionStatus({ connected: false, error: error instanceof Error ? error.message : 'Unknown error' });
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const filterRecords = () => {
    let filtered = [...attendanceRecords];

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(record => 
        record.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.employeeId.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter(record => record.status === statusFilter);
    }

    // Employee filter
    if (selectedEmployee !== "all") {
      filtered = filtered.filter(record => record.employeeId === selectedEmployee);
    }

    // Date filter
    if (dateFilter === "today") {
      filtered = filtered.filter(record => record.date === today);
    } else if (dateFilter === "week") {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const weekAgoStr = weekAgo.toISOString().split('T')[0];
      filtered = filtered.filter(record => record.date >= weekAgoStr);
    }

    setFilteredRecords(filtered);
  };

  const exportToGoogleSheets = () => {
    // Open Google Sheets in new tab - using the correct spreadsheet ID
    window.open('https://docs.google.com/spreadsheets/d/1OaWnlOIRyWFN3Qrelxmxr9PE4IkB7KEa1Q4Ll_fQqi8/edit', '_blank');
  };

  const testConnection = async () => {
    setIsTestingConnection(true);
    try {
      const status = await googleSheetsService.getConnectionStatus();
      setConnectionStatus(status);
      
      if (status.connected) {
        toast.success('Successfully connected to Google Sheets!');
      } else {
        toast.error(`Connection failed: ${status.error}`);
      }
    } catch (error) {
      toast.error('Failed to test connection');
      setConnectionStatus({ 
        connected: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'present':
        return <Badge className="bg-green-100 text-green-800">Present</Badge>;
      case 'half-day':
        return <Badge className="bg-orange-100 text-orange-800">Half Day</Badge>;
      case 'absent':
        return <Badge className="bg-red-100 text-red-800">Absent</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4" />
              <p className="text-muted-foreground">Loading dashboard data...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-primary flex items-center gap-3">
              Attendance Dashboard
              <div className={`w-2 h-2 rounded-full ${connectionStatus.connected ? 'bg-green-500' : 'bg-red-500'}`} />
            </h1>
            <p className="text-muted-foreground">
              Real-time attendance tracking via Google Sheets
              {connectionStatus.lastSync && (
                <span className="ml-2 text-xs">
                  • Last synced: {new Date(connectionStatus.lastSync).toLocaleTimeString('en-IN')}
                </span>
              )}
            </p>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={loadDashboardData} 
              variant="outline" 
              size="sm"
              disabled={isRefreshing}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? 'Syncing...' : 'Refresh'}
            </Button>
            <Button onClick={exportToGoogleSheets} variant="outline" size="sm">
              <ExternalLink className="w-4 h-4 mr-2" />
              Open Sheets
            </Button>
            <Button onClick={testConnection} variant="outline" size="sm" disabled={isTestingConnection}>
              {isTestingConnection ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <CheckCircle className="w-4 h-4 mr-2" />
              )}
              Test Connection
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Executives</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalEmployees}</div>
              <p className="text-xs text-muted-foreground">Active executives</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Present Today</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.presentToday}</div>
              <p className="text-xs text-muted-foreground">
                +{stats.halfDayToday} half day
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Absent Today</CardTitle>
              <XCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.absentToday}</div>
              <p className="text-xs text-muted-foreground">Not marked</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Attendance Rate</CardTitle>
              <BarChart3 className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {stats.attendanceRate.toFixed(1)}%
              </div>
              <p className="text-xs text-muted-foreground">Today's rate</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filters & Search
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search by name or ID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Status</label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="present">Present</SelectItem>
                    <SelectItem value="absent">Absent</SelectItem>
                    <SelectItem value="half-day">Half Day</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Period</label>
                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Executive</label>
                <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Executives</SelectItem>
                    {employees.map(emp => (
                      <SelectItem key={emp.employeeId} value={emp.employeeId}>
                        {emp.name} ({emp.employeeId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Attendance Records */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Attendance Records ({filteredRecords.length})
              </span>
              <Button variant="outline" size="sm" onClick={exportToGoogleSheets}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredRecords.length === 0 ? (
              <div className="text-center py-8">
                <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No attendance records found</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredRecords.map((record, index) => (
                  <div
                    key={`${record.employeeId}-${record.date}-${index}`}
                    className="border rounded-lg p-4 space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div>
                          <h3 className="font-medium">{record.name}</h3>
                          <p className="text-sm text-muted-foreground">{record.employeeId}</p>
                        </div>
                        {getStatusBadge(record.status)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {record.date} • {record.checkInTime ? new Date(record.checkInTime).toLocaleTimeString('en-IN', { hour12: true }) : 'N/A'}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                      {record.workLocation && (
                        <div>
                          <span className="font-medium">Workplace:</span> {record.workLocation}
                        </div>
                      )}
                      
                      {record.notes && (
                        <div>
                          <span className="font-medium">Task:</span> {record.notes.replace('Task: ', '')}
                        </div>
                      )}
                      
                      {record.location && (
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          <span className="font-medium">Location:</span>
                          <span className="text-xs">
                            {record.location.latitude.toFixed(4)}, {record.location.longitude.toFixed(4)}
                          </span>
                        </div>
                      )}
                    </div>

                    {record.location?.address && (
                      <div className="text-sm text-muted-foreground">
                        <strong>Address:</strong> {record.location.address}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Integration Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ExternalLink className="w-5 h-5" />
              Google Sheets Integration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Connection Status */}
              <div className="flex items-center justify-between p-4 border rounded-lg bg-gradient-to-r from-blue-50 to-purple-50">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${connectionStatus.connected ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
                  <div>
                    <h4 className="font-medium flex items-center gap-2">
                      Connection Status
                      {connectionStatus.connected ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-600" />
                      )}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {connectionStatus.connected 
                        ? `Connected • Last sync: ${connectionStatus.lastSync ? new Date(connectionStatus.lastSync).toLocaleString('en-IN') : 'N/A'}`
                        : `Disconnected • ${connectionStatus.error || 'No connection'}`
                      }
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button 
                    onClick={testConnection} 
                    variant="outline" 
                    size="sm"
                    disabled={isTestingConnection}
                  >
                    {isTestingConnection ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4" />
                    )}
                    Test
                  </Button>
                  {connectionStatus.connected && (
                    <Badge className="bg-green-100 text-green-800">
                      Connected
                    </Badge>
                  )}
                  {!connectionStatus.connected && (
                    <Badge className="bg-red-100 text-red-800">
                      Disconnected
                    </Badge>
                  )}
                </div>
              </div>

              {/* Google Sheets Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Live Data Sync</h4>
                    <p className="text-sm text-muted-foreground">
                      Real-time attendance tracking
                    </p>
                  </div>
                  <Badge className={connectionStatus.connected ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                    {connectionStatus.connected ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <h4 className="font-medium">MIS Reports</h4>
                    <p className="text-sm text-muted-foreground">
                      Comprehensive analytics
                    </p>
                  </div>
                  <Button variant="outline" size="sm" onClick={exportToGoogleSheets}>
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Open
                  </Button>
                </div>
              </div>

              {/* Sheet Details */}
              <div className="p-4 bg-muted/50 rounded-lg">
                <h4 className="font-medium mb-3 flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Connected Sheets
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Register Employee Sheet</span>
                    <Badge variant="outline" className="text-xs">
                      Profiles: {employees.length}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">EMPID and Password</span>
                    <Badge variant="outline" className="text-xs">
                      Credentials
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Daily Attendance</span>
                    <Badge variant="outline" className="text-xs">
                      Records: {attendanceRecords.length}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Attendance Summary</span>
                    <Badge variant="outline" className="text-xs">
                      Analytics
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Connection Error Details */}
              {!connectionStatus.connected && connectionStatus.error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <h4 className="font-medium text-red-800 mb-2 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    Connection Error
                  </h4>
                  <p className="text-sm text-red-700">{connectionStatus.error}</p>
                  <p className="text-xs text-red-600 mt-2">
                    Please check your Google Sheets API configuration and ensure the spreadsheet is accessible.
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}