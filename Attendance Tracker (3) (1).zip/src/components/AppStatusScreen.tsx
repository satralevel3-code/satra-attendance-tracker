import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  CheckCircle, 
  AlertTriangle, 
  Info, 
  WifiOff, 
  Camera, 
  MapPin,
  Download,
  Users,
  Building2
} from 'lucide-react';

interface AppStatusScreenProps {
  onContinue: () => void;
}

export function AppStatusScreen({ onContinue }: AppStatusScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-semibold text-primary mb-2">Satra Services</h1>
          <p className="text-muted-foreground">Attendance Tracker - System Status</p>
        </div>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              System Ready
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">Local Storage</p>
                  <p className="text-sm text-muted-foreground">Working perfectly</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">CSV Export</p>
                  <p className="text-sm text-muted-foreground">Enabled</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <WifiOff className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium">Offline Mode</p>
                  <p className="text-sm text-muted-foreground">No internet required</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="font-medium">Demo Data</p>
                  <p className="text-sm text-muted-foreground">Pre-loaded for testing</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Features Status */}
        <Card>
          <CardHeader>
            <CardTitle>Feature Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Camera className="w-5 h-5 text-blue-600" />
                <span>Camera Access</span>
              </div>
              <Badge variant="secondary" className="bg-amber-100 text-amber-800">
                Permission Required
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-green-600" />
                <span>Location Access</span>
              </div>
              <Badge variant="secondary" className="bg-amber-100 text-amber-800">
                Permission Required
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Download className="w-5 h-5 text-purple-600" />
                <span>CSV Export</span>
              </div>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Ready
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Important Notes */}
        <div className="space-y-3">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>No Internet Required:</strong> This app works completely offline. All data is stored locally on your device and can be exported as CSV files.
            </AlertDescription>
          </Alert>
          
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Camera & Location:</strong> If browser permissions are denied, you can still mark attendance - it will be flagged for manual verification by your manager.
            </AlertDescription>
          </Alert>
        </div>

        {/* Login Credentials */}
        <Card>
          <CardHeader>
            <CardTitle>Test Login Credentials</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="font-medium text-blue-900">Admin Login</p>
                <p className="text-sm text-blue-700">ID: ADMIN01</p>
                <p className="text-sm text-blue-700">Password: admin123</p>
              </div>
              
              <div className="p-3 bg-green-50 rounded-lg">
                <p className="font-medium text-green-900">Executive Login</p>
                <p className="text-sm text-green-700">ID: SAT001</p>
                <p className="text-sm text-green-700">Password: test123</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Continue Button */}
        <div className="space-y-3">
          <Button 
            onClick={onContinue}
            className="w-full h-12 bg-primary hover:bg-primary/90"
          >
            Continue to Login
          </Button>
          
          <p className="text-center text-sm text-muted-foreground">
            System is ready for offline attendance tracking
          </p>
        </div>
      </div>
    </div>
  );
}