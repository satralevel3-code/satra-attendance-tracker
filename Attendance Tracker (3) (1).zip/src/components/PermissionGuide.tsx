import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  MapPin, 
  Camera, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Smartphone,
  Monitor,
  Settings,
  Lock,
  RefreshCw,
  Info
} from 'lucide-react';

interface PermissionGuideProps {
  onClose: () => void;
}

export function PermissionGuide({ onClose }: PermissionGuideProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-lg mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Permission Setup Guide
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* What Permissions Are Needed */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Required Permissions</h3>
              
              <div className="grid gap-4">
                <div className="flex items-start gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <MapPin className="w-6 h-6 text-blue-600 mt-1" />
                  <div className="flex-1">
                    <h4 className="font-medium text-blue-800">Location Access (GPS)</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      Captures accurate longitude and latitude coordinates to verify your workplace location.
                    </p>
                    <div className="text-xs text-blue-600 mt-2">
                      <strong>What we collect:</strong> GPS coordinates, accuracy level, timestamp
                    </div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <Camera className="w-6 h-6 text-green-600 mt-1" />
                  <div className="flex-1">
                    <h4 className="font-medium text-green-800">Camera Access</h4>
                    <p className="text-sm text-green-700 mt-1">
                      Takes a workplace photo with location and timestamp overlay for attendance verification.
                    </p>
                    <div className="text-xs text-green-600 mt-2">
                      <strong>What we capture:</strong> Photo with GPS coordinates, timestamp, employee name
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Browser-Specific Instructions */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">How to Grant Permissions</h3>
              
              {/* Chrome/Edge */}
              <div className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Monitor className="w-5 h-5" />
                  <h4 className="font-medium">Chrome / Edge / Brave</h4>
                </div>
                <ol className="text-sm space-y-2 list-decimal list-inside text-gray-700">
                  <li>Look for the <Lock className="w-4 h-4 inline mx-1" /> lock icon in the address bar</li>
                  <li>Click on the lock icon</li>
                  <li>Set "Location" to <Badge className="bg-green-100 text-green-800 text-xs">Allow</Badge></li>
                  <li>Set "Camera" to <Badge className="bg-green-100 text-green-800 text-xs">Allow</Badge></li>
                  <li>Refresh the page</li>
                </ol>
              </div>

              {/* Firefox */}
              <div className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Monitor className="w-5 h-5" />
                  <h4 className="font-medium">Firefox</h4>
                </div>
                <ol className="text-sm space-y-2 list-decimal list-inside text-gray-700">
                  <li>Look for the shield icon or notification in the address bar</li>
                  <li>Click "Allow" when prompted for location and camera</li>
                  <li>Or go to Settings → Privacy & Security → Permissions</li>
                  <li>Add this site to allowed locations and camera access</li>
                </ol>
              </div>

              {/* Mobile Safari */}
              <div className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Smartphone className="w-5 h-5" />
                  <h4 className="font-medium">Mobile Safari (iOS)</h4>
                </div>
                <ol className="text-sm space-y-2 list-decimal list-inside text-gray-700">
                  <li>Go to iPhone Settings → Safari → Location Services</li>
                  <li>Enable "Location Services" for Safari</li>
                  <li>For camera: Allow when prompted in the browser</li>
                  <li>Return to the app and refresh</li>
                </ol>
              </div>

              {/* Mobile Chrome */}
              <div className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Smartphone className="w-5 h-5" />
                  <h4 className="font-medium">Mobile Chrome/Android</h4>
                </div>
                <ol className="text-sm space-y-2 list-decimal list-inside text-gray-700">
                  <li>Tap the three dots menu → Settings → Site Settings</li>
                  <li>Find this website in the list</li>
                  <li>Enable "Location" and "Camera" permissions</li>
                  <li>Or allow when prompted in the browser</li>
                </ol>
              </div>
            </div>

            {/* Troubleshooting */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Troubleshooting</h3>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div className="flex-1 text-sm">
                    <p className="font-medium text-amber-800">Permission Previously Denied?</p>
                    <p className="text-amber-700">
                      If you previously denied permissions, you'll need to manually enable them in your browser settings or clear site data and try again.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <Info className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="flex-1 text-sm">
                    <p className="font-medium text-blue-800">Location Not Working?</p>
                    <p className="text-blue-700">
                      Make sure location services are enabled on your device and you're not using a VPN that might interfere with location detection.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div className="flex-1 text-sm">
                    <p className="font-medium text-green-800">Manual Mode Available</p>
                    <p className="text-green-700">
                      If you cannot grant permissions, you can still mark attendance using manual mode where you'll describe your location in text.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Privacy Notice */}
            <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
              <h4 className="font-medium mb-2">Privacy & Security</h4>
              <div className="text-sm text-gray-700 space-y-1">
                <p>• Your location and photos are only used for attendance verification</p>
                <p>• Data is securely stored in Google Sheets with proper access controls</p>
                <p>• Location coordinates are accurate to within 3-50 meters typically</p>
                <p>• Photos include overlay information but are not shared externally</p>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                onClick={() => window.location.reload()}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh & Try Again
              </Button>
              <Button
                variant="outline"
                onClick={onClose}
                className="flex-1"
              >
                Close Guide
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}