import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { locationService } from "../services/LocationService";
import { toast } from "sonner";
import { Analytics } from "../utils/monitoring";
import { getCurrentDateIST } from "../utils/timezone";
import {
  Camera,
  MapPin,
  Clock,
  ArrowLeft,
  User,
  Building,
  FileText,
  CheckCircle,
  Loader2,
  XCircle,
  CalendarCheck,
  CalendarX
} from "lucide-react";

interface AttendanceMarkingScreenProps {
  onBack: () => void;
  onAttendanceMarked: (status: 'present' | 'absent' | 'half-day') => void;
  userData: {
    employeeId: string;
    name: string;
    reportingManager: string;
  };
}

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  address: string;
}

const taskOptions = [
  'Training',
  'MIS Preparation',
  'Meeting',
  'Data Entry',
  'Data Collection',
  'Data Verification',
  'Handholding'
];

const workplaceOptions = [
  'PACS',
  'DCCB',
  'DR Office',
  'Cluster',
  'WFH'
];

export function AttendanceMarkingScreen({ onBack, onAttendanceMarked, userData }: AttendanceMarkingScreenProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedStatus, setSelectedStatus] = useState<'present' | 'absent' | 'half-day' | null>(null);
  const [selectedTask, setSelectedTask] = useState('');
  const [selectedWorkplace, setSelectedWorkplace] = useState('');
  const [absentType, setAbsentType] = useState<'planned' | 'unplanned' | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [location, setLocation] = useState<LocationData | null>(null);
  const [isCapturingPhoto, setIsCapturingPhoto] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState<{
    camera: string;
    location: string;
  }>({ camera: 'prompt', location: 'prompt' });

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Check and request permissions automatically when component mounts
  useEffect(() => {
    checkInitialPermissions();
  }, []);

  const checkInitialPermissions = async () => {
    try {
      // Check camera permission
      const cameraPermission = await navigator.permissions.query({ name: 'camera' as PermissionName });
      
      // Check location permission  
      const locationPermission = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
      
      setPermissionStatus({
        camera: cameraPermission.state,
        location: locationPermission.state
      });

      console.log('✅ Initial permissions checked:', {
        camera: cameraPermission.state,
        location: locationPermission.state
      });
    } catch (error) {
      console.log('Permission check not supported, will request during capture:', error);
    }
  };

  // Automatically request and start camera when reaching photo step
  const startCameraCapture = async () => {
    try {
      setIsCapturingPhoto(true);
      
      // Request location permission and get location first
      try {
        await captureLocation();
      } catch (locationError) {
        console.error('Location capture failed:', locationError);
        // Location error - don't proceed with camera
        setIsCapturingPhoto(false);
        throw locationError; // Re-throw to be caught by outer catch
      }
      
      // Request camera permission and start stream
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      
      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      // Update camera permission status  
      setPermissionStatus(prev => ({ ...prev, camera: 'granted' }));
      
      console.log('✅ Camera started successfully with automatic permissions');
      toast.success('Camera ready! Position yourself and capture your photo.');
      
    } catch (error) {
      console.error('Capture process error:', error);
      
      // Only update camera permission status if it's actually a camera error
      if (error instanceof Error) {
        if (error.name === 'NotAllowedError') {
          setPermissionStatus(prev => ({ ...prev, camera: 'denied' }));
          toast.error('Camera permission denied. Please allow camera access and try again.');
        } else if (error.name === 'NotFoundError') {
          setPermissionStatus(prev => ({ ...prev, camera: 'denied' }));
          toast.error('No camera found on this device.');
        } else if (error.message.includes('Location')) {
          // This is a location error, already handled
          console.log('Location error already shown to user');
        } else {
          setPermissionStatus(prev => ({ ...prev, camera: 'denied' }));
          toast.error('Failed to access camera. Please check your device settings.');
        }
      }
      
      setIsCapturingPhoto(false);
    }
  };

  const captureLocation = async (): Promise<LocationData> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        const error = new Error('Geolocation not supported by this browser');
        toast.error('Geolocation not supported by this browser');
        reject(error);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            const { latitude, longitude, accuracy } = position.coords;
            
            // Get address from coordinates
            const address = await locationService.getAddressFromCoordinates(latitude, longitude);
            
            const locationData: LocationData = {
              latitude,
              longitude,
              accuracy: accuracy || 0,
              address
            };
            
            setLocation(locationData);
            setPermissionStatus(prev => ({ ...prev, location: 'granted' }));
            console.log('✅ Location captured:', locationData);
            resolve(locationData);
            
          } catch (error) {
            console.error('Address lookup failed:', error);
            // Still resolve with basic location data if address lookup fails
            const basicLocationData: LocationData = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              accuracy: position.coords.accuracy || 0,
              address: `${position.coords.latitude.toFixed(6)}, ${position.coords.longitude.toFixed(6)}`
            };
            
            setLocation(basicLocationData);
            setPermissionStatus(prev => ({ ...prev, location: 'granted' }));
            resolve(basicLocationData);
          }
        },
        (error) => {
          console.error('Location access error:', {
            code: error.code,
            message: error.message,
            PERMISSION_DENIED: error.PERMISSION_DENIED,
            POSITION_UNAVAILABLE: error.POSITION_UNAVAILABLE,
            TIMEOUT: error.TIMEOUT
          });
          setPermissionStatus(prev => ({ ...prev, location: 'denied' }));
          
          let errorMessage = 'Location access failed.';
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = 'Location permission denied. Please allow location access.';
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = 'Location information unavailable.';
              break;
            case error.TIMEOUT:
              errorMessage = 'Location request timed out.';
              break;
          }
          
          toast.error(errorMessage);
          reject(new Error(errorMessage));
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 60000
        }
      );
    });
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) {
      toast.error('Camera not ready');
      return;
    }

    try {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext('2d');

      if (!context) {
        toast.error('Failed to get canvas context');
        return;
      }

      // Set canvas dimensions to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      // Draw the video frame to canvas
      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      // Convert to blob and create URL
      canvas.toBlob((blob) => {
        if (blob) {
          const photoUrl = URL.createObjectURL(blob);
          setCapturedPhoto(photoUrl);
          stopCamera();
          toast.success('Photo captured successfully!');
          console.log('✅ Photo captured');
        }
      }, 'image/jpeg', 0.8);

    } catch (error) {
      console.error('Photo capture error:', error);
      toast.error('Failed to capture photo');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCapturingPhoto(false);
  };

  const retakePhoto = () => {
    if (capturedPhoto) {
      URL.revokeObjectURL(capturedPhoto);
      setCapturedPhoto(null);
    }
    startCameraCapture();
  };

  const confirmAttendance = async () => {
    setIsProcessing(true);

    try {
      // Get current date in IST (Indian Standard Time)
      const currentDateIST = getCurrentDateIST();
      const currentTimestamp = new Date().toISOString();
      
      let attendanceRecord: any = {
        employeeId: userData.employeeId,
        name: userData.name,
        date: currentDateIST, // Use IST date instead of UTC
        checkInTime: currentTimestamp,
        status: selectedStatus,
        reportingManager: userData.reportingManager,
        timestamp: currentTimestamp
      };

      // For Present or Half-Day, include task, workplace, photo, and location
      if (selectedStatus === 'present' || selectedStatus === 'half-day') {
        if (!capturedPhoto || !location) {
          toast.error('Photo and location are required');
          setIsProcessing(false);
          return;
        }

        attendanceRecord = {
          ...attendanceRecord,
          location: location,
          photoUrl: capturedPhoto,
          notes: `Task: ${selectedTask}`,
          workLocation: selectedWorkplace,
          task: selectedTask
        };
      } else if (selectedStatus === 'absent') {
        // For Absent, include the absent type
        attendanceRecord = {
          ...attendanceRecord,
          notes: `Absent - ${absentType === 'planned' ? 'Planned' : 'Unplanned'}`,
          absentType: absentType
        };
      }

      // Save to local storage
      const existingRecords = JSON.parse(localStorage.getItem('attendanceRecords') || '[]');
      
      // Check if attendance already marked today
      const todayRecord = existingRecords.find(
        (record: any) => 
          record.employeeId === userData.employeeId && 
          record.date === attendanceRecord.date
      );

      if (todayRecord) {
        // Update existing record
        const updatedRecords = existingRecords.map((record: any) =>
          record.employeeId === userData.employeeId && record.date === attendanceRecord.date
            ? attendanceRecord
            : record
        );
        localStorage.setItem('attendanceRecords', JSON.stringify(updatedRecords));
      } else {
        // Add new record
        existingRecords.push(attendanceRecord);
        localStorage.setItem('attendanceRecords', JSON.stringify(existingRecords));
      }

      console.log('✅ Attendance successfully recorded:', attendanceRecord);
      
      // Track analytics
      Analytics.trackAttendanceMarked(
        userData.employeeId, 
        selectedStatus || 'unknown',
        location || undefined
      );

      // Show appropriate success message
      if (selectedStatus === 'absent') {
        toast.success(`Absent attendance marked as ${absentType === 'planned' ? 'Planned' : 'Unplanned'}!`);
      } else {
        toast.success('Attendance marked successfully with geo-location!');
      }
      
      // Clean up photo URL if it was created locally
      if (capturedPhoto && capturedPhoto.startsWith('blob:')) {
        URL.revokeObjectURL(capturedPhoto);
      }

      onAttendanceMarked(selectedStatus!);

    } catch (error) {
      console.error('Failed to record attendance:', error);
      toast.error('Failed to record attendance. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const nextStep = () => {
    if (currentStep === 1) {
      // From status selection
      if (!selectedStatus) {
        toast.error('Please select attendance status');
        return;
      }
      
      if (selectedStatus === 'absent') {
        // Go to absent type selection (step 2)
        setCurrentStep(2);
      } else {
        // Go to task selection (step 2)
        setCurrentStep(2);
      }
    } else if (currentStep === 2) {
      if (selectedStatus === 'absent') {
        // Confirm absent directly
        return;
      } else {
        // Validate task selection
        if (!selectedTask) {
          toast.error('Please select a task');
          return;
        }
        // Go to workplace selection (step 3)
        setCurrentStep(3);
      }
    } else if (currentStep === 3) {
      // Validate workplace selection
      if (!selectedWorkplace) {
        toast.error('Please select workplace');
        return;
      }
      // Go to photo capture (step 4)
      setCurrentStep(4);
      startCameraCapture();
    }
  };

  const prevStep = () => {
    if (currentStep === 4) {
      stopCamera();
    }
    setCurrentStep(prev => prev - 1);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
      if (capturedPhoto && capturedPhoto.startsWith('blob:')) {
        URL.revokeObjectURL(capturedPhoto);
      }
    };
  }, [capturedPhoto]);

  const getTotalSteps = () => {
    if (selectedStatus === 'absent') {
      return 2; // Status -> Absent Type
    } else {
      return 4; // Status -> Task -> Workplace -> Photo
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        // Attendance Status Selection
        return (
          <div className="space-y-6">
            <div className="text-center">
              <CalendarCheck className="w-16 h-16 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold">Select Attendance Status</h3>
              <p className="text-muted-foreground">Choose your attendance status for today</p>
            </div>
            
            <RadioGroup value={selectedStatus || ''} onValueChange={(value) => setSelectedStatus(value as any)}>
              <div className="space-y-3">
                <label 
                  className={`flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedStatus === 'present' 
                      ? 'border-green-500 bg-green-50' 
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <RadioGroupItem value="present" id="present" />
                  <div className="flex-1 flex items-center gap-3">
                    <CheckCircle className={`w-5 h-5 ${selectedStatus === 'present' ? 'text-green-600' : 'text-gray-400'}`} />
                    <span className="font-medium">Present</span>
                  </div>
                </label>

                <label 
                  className={`flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedStatus === 'half-day' 
                      ? 'border-yellow-500 bg-yellow-50' 
                      : 'border-gray-200 hover:border-yellow-300'
                  }`}
                >
                  <RadioGroupItem value="half-day" id="half-day" />
                  <div className="flex-1 flex items-center gap-3">
                    <Clock className={`w-5 h-5 ${selectedStatus === 'half-day' ? 'text-yellow-600' : 'text-gray-400'}`} />
                    <span className="font-medium">Half Day</span>
                  </div>
                </label>

                <label 
                  className={`flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedStatus === 'absent' 
                      ? 'border-red-500 bg-red-50' 
                      : 'border-gray-200 hover:border-red-300'
                  }`}
                >
                  <RadioGroupItem value="absent" id="absent" />
                  <div className="flex-1 flex items-center gap-3">
                    <XCircle className={`w-5 h-5 ${selectedStatus === 'absent' ? 'text-red-600' : 'text-gray-400'}`} />
                    <span className="font-medium">Absent</span>
                  </div>
                </label>
              </div>
            </RadioGroup>

            <Button 
              onClick={nextStep} 
              className="w-full"
              disabled={!selectedStatus}
            >
              Continue
            </Button>
          </div>
        );

      case 2:
        // Task Selection (for Present/Half-Day) OR Absent Type (for Absent)
        if (selectedStatus === 'absent') {
          return (
            <div className="space-y-6">
              <div className="text-center">
                <CalendarX className="w-16 h-16 text-red-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold">Absent Type</h3>
                <p className="text-muted-foreground">Specify if this absence was planned or unplanned</p>
              </div>

              <RadioGroup value={absentType || ''} onValueChange={(value) => setAbsentType(value as any)}>
                <div className="space-y-3">
                  <label 
                    className={`flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      absentType === 'planned' 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <RadioGroupItem value="planned" id="planned" />
                    <div className="flex-1 flex items-center gap-3">
                      <CalendarCheck className={`w-5 h-5 ${absentType === 'planned' ? 'text-blue-600' : 'text-gray-400'}`} />
                      <div>
                        <span className="font-medium block">Planned</span>
                        <span className="text-xs text-muted-foreground">Pre-approved leave or planned absence</span>
                      </div>
                    </div>
                  </label>

                  <label 
                    className={`flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      absentType === 'unplanned' 
                        ? 'border-orange-500 bg-orange-50' 
                        : 'border-gray-200 hover:border-orange-300'
                    }`}
                  >
                    <RadioGroupItem value="unplanned" id="unplanned" />
                    <div className="flex-1 flex items-center gap-3">
                      <CalendarX className={`w-5 h-5 ${absentType === 'unplanned' ? 'text-orange-600' : 'text-gray-400'}`} />
                      <div>
                        <span className="font-medium block">Unplanned</span>
                        <span className="text-xs text-muted-foreground">Emergency or sudden absence</span>
                      </div>
                    </div>
                  </label>
                </div>
              </RadioGroup>

              <div className="flex gap-3">
                <Button variant="outline" onClick={prevStep} className="flex-1">
                  Back
                </Button>
                <Button 
                  onClick={confirmAttendance} 
                  className="flex-1"
                  disabled={!absentType || isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Confirm Absence'
                  )}
                </Button>
              </div>
            </div>
          );
        } else {
          // Task Selection
          return (
            <div className="space-y-6">
              <div className="text-center">
                <FileText className="w-16 h-16 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold">Select Task</h3>
                <p className="text-muted-foreground">Choose your primary task for today</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="task">Task *</Label>
                <Select value={selectedTask} onValueChange={setSelectedTask}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your task" />
                  </SelectTrigger>
                  <SelectContent>
                    {taskOptions.map((task) => (
                      <SelectItem key={task} value={task}>
                        {task}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={prevStep} className="flex-1">
                  Back
                </Button>
                <Button 
                  onClick={nextStep} 
                  className="flex-1"
                  disabled={!selectedTask}
                >
                  Continue
                </Button>
              </div>
            </div>
          );
        }

      case 3:
        // Workplace Selection (only for Present/Half-Day)
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Building className="w-16 h-16 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold">Select Workplace</h3>
              <p className="text-muted-foreground">Choose where you'll be working today</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="workplace">Workplace *</Label>
              <Select value={selectedWorkplace} onValueChange={setSelectedWorkplace}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your workplace" />
                </SelectTrigger>
                <SelectContent>
                  {workplaceOptions.map((workplace) => (
                    <SelectItem key={workplace} value={workplace}>
                      {workplace}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={prevStep} className="flex-1">
                Back
              </Button>
              <Button 
                onClick={nextStep} 
                className="flex-1"
                disabled={!selectedWorkplace}
              >
                Capture Photo
              </Button>
            </div>
          </div>
        );

      case 4:
        // Photo Capture with Auto Location (only for Present/Half-Day)
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Camera className="w-16 h-16 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold">Capture Photo & Location</h3>
              <p className="text-muted-foreground">
                {capturedPhoto ? 'Photo captured! Review and confirm.' : 'Position yourself and capture your photo'}
              </p>
            </div>

            {/* Location Status */}
            <Card className={`border ${location ? 'border-green-200 bg-green-50' : 'border-orange-200 bg-orange-50'}`}>
              <CardContent className="pt-4">
                <div className="flex items-center gap-2">
                  <MapPin className={`w-4 h-4 ${location ? 'text-green-600' : 'text-orange-600'}`} />
                  <span className={`text-sm font-medium ${location ? 'text-green-800' : 'text-orange-800'}`}>
                    {location ? 'Location captured' : 'Capturing location...'}
                  </span>
                </div>
                {location && (
                  <p className="text-xs text-green-700 mt-1">
                    {location.address} (±{Math.round(location.accuracy)}m)
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Camera Interface */}
            <div className="relative">
              {!capturedPhoto ? (
                <div className="space-y-4">
                  {isCapturingPhoto && (
                    <div className="relative bg-black rounded-lg overflow-hidden">
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-64 object-cover"
                      />
                      <div className="absolute inset-0 border-4 border-white/20 rounded-lg pointer-events-none">
                        <div className="absolute top-4 left-4 right-4 text-center">
                          <span className="bg-black/50 text-white px-2 py-1 rounded text-sm">
                            Position yourself in the frame
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <canvas ref={canvasRef} className="hidden" />
                  
                  {isCapturingPhoto && location ? (
                    <Button onClick={capturePhoto} className="w-full">
                      <Camera className="w-4 h-4 mr-2" />
                      Capture Photo
                    </Button>
                  ) : (
                    <div className="flex items-center justify-center p-8 border-2 border-dashed border-gray-300 rounded-lg">
                      <div className="text-center">
                        <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground">
                          {!location ? 'Getting your location...' : 'Starting camera...'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative">
                    <img
                      src={capturedPhoto}
                      alt="Captured attendance photo"
                      className="w-full h-64 object-cover rounded-lg"
                    />
                    <div className="absolute top-2 right-2">
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        Photo Captured
                      </Badge>
                    </div>
                  </div>
                  
                  <Button variant="outline" onClick={retakePhoto} className="w-full">
                    <Camera className="w-4 h-4 mr-2" />
                    Retake Photo
                  </Button>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={prevStep} className="flex-1">
                Back
              </Button>
              <Button
                onClick={confirmAttendance}
                className="flex-1"
                disabled={!capturedPhoto || !location || isProcessing}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Confirm Attendance'
                )}
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-md mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="text-primary hover:text-primary/80"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="text-center flex-1">
              <h1 className="font-semibold text-primary">Mark Attendance</h1>
              <p className="text-sm text-muted-foreground">Step {currentStep} of {getTotalSteps()}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto p-6">
        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            {Array.from({ length: getTotalSteps() }, (_, i) => i + 1).map((step) => (
              <div
                key={step}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step <= currentStep
                    ? 'bg-primary text-white'
                    : 'bg-gray-200 text-gray-500'
                }`}
              >
                {step}
              </div>
            ))}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / getTotalSteps()) * 100}%` }}
            />
          </div>
        </div>

        {/* Employee Info */}
        <Card className="mb-6">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-medium">{userData.name}</h3>
                <p className="text-sm text-muted-foreground">{userData.employeeId}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Clock className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">
                    {new Date().toLocaleString('en-IN', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Step Content */}
        <Card>
          <CardContent className="pt-6">
            {renderStepContent()}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}