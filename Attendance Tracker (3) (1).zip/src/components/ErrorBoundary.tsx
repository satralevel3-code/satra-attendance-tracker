import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Copy, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ErrorLogger, ErrorSeverity, ErrorCategory } from '../utils/errorHandling';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
  errorId?: string;
  retryCount: number;
  copied: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    retryCount: 0,
    copied: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, retryCount: 0, copied: false };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Error boundary caught an error:', error, errorInfo);
    
    // Log error with error handling utility
    const appError = ErrorLogger.log(error, {
      componentStack: errorInfo.componentStack,
      type: 'error_boundary',
      retryCount: this.state.retryCount
    });

    // Store error info in state
    this.setState({
      errorInfo,
      errorId: appError.id
    });

    // Call optional error handler
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }
  }

  private handleRetry = () => {
    this.setState(prev => ({ 
      hasError: false, 
      error: undefined,
      errorInfo: undefined,
      retryCount: prev.retryCount + 1,
      copied: false
    }));
  };

  private handleReload = () => {
    window.location.reload();
  };

  private copyErrorDetails = () => {
    const errorDetails = {
      errorId: this.state.errorId,
      message: this.state.error?.message,
      stack: this.state.error?.stack,
      componentStack: this.state.errorInfo?.componentStack,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      url: window.location.href
    };

    const text = JSON.stringify(errorDetails, null, 2);
    
    navigator.clipboard.writeText(text).then(() => {
      this.setState({ copied: true });
      setTimeout(() => this.setState({ copied: false }), 2000);
    });
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center p-4">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <AlertTriangle className="w-5 h-5" />
                Something went wrong
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                The app encountered an unexpected error. This might be due to:
              </p>
              <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                <li>Network connectivity issues</li>
                <li>Browser compatibility problems</li>
                <li>Temporary system glitch</li>
                <li>Insufficient device resources</li>
              </ul>

              {this.state.errorId && (
                <div className="text-xs bg-blue-50 border border-blue-200 rounded p-2">
                  <span className="font-medium text-blue-900">Error ID: </span>
                  <code className="text-blue-700">{this.state.errorId}</code>
                </div>
              )}

              {this.state.retryCount > 0 && (
                <div className="text-xs bg-yellow-50 border border-yellow-200 rounded p-2">
                  <span className="font-medium text-yellow-900">Retry attempts: {this.state.retryCount}</span>
                </div>
              )}
              
              {this.state.error && (
                <details className="text-xs bg-gray-50 p-2 rounded border">
                  <summary className="cursor-pointer font-medium text-gray-700">
                    Technical Details
                  </summary>
                  <div className="mt-2 space-y-2">
                    <div>
                      <span className="font-medium">Error:</span>
                      <pre className="mt-1 whitespace-pre-wrap text-red-600 bg-white p-2 rounded border">
                        {this.state.error.message}
                      </pre>
                    </div>
                    {this.state.error.stack && (
                      <div>
                        <span className="font-medium">Stack Trace:</span>
                        <pre className="mt-1 whitespace-pre-wrap text-gray-600 bg-white p-2 rounded border text-[10px] max-h-32 overflow-auto">
                          {this.state.error.stack}
                        </pre>
                      </div>
                    )}
                  </div>
                </details>
              )}

              <div className="flex gap-2">
                <Button
                  onClick={this.handleRetry}
                  className="flex-1"
                  variant="outline"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Button
                  onClick={this.handleReload}
                  className="flex-1"
                >
                  Reload App
                </Button>
              </div>

              <Button
                onClick={this.copyErrorDetails}
                variant="ghost"
                className="w-full"
                size="sm"
              >
                {this.state.copied ? (
                  <>
                    <CheckCircle className="w-3 h-3 mr-2 text-green-600" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 mr-2" />
                    Copy Error Details for Support
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}