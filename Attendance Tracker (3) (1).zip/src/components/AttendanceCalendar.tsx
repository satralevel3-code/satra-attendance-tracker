import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Calendar } from "./ui/calendar";
import { 
  Calendar as CalendarIcon,
  CheckCircle, 
  XCircle, 
  Clock,
  ArrowLeft,
  User,
  MapPin,
  Camera,
  FileText,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { formatTimeIST } from "../utils/timezone";

interface AttendanceRecord {
  employeeId: string;
  name: string;
  date: string;
  checkInTime?: string;
  checkOutTime?: string;
  status: 'present' | 'absent' | 'half-day';
  location?: {
    latitude: number;
    longitude: number;
    accuracy: number;
    address: string;
  };
  photoUrl?: string;
  notes?: string;
  workLocation?: string;
  reportingManager: string;
}

interface AttendanceCalendarProps {
  onBack: () => void;
  userData: {
    employeeId: string;
    name: string;
    designation: string;
  };
}

export function AttendanceCalendar({ onBack, userData }: AttendanceCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedRecord, setSelectedRecord] = useState<AttendanceRecord | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load attendance records on component mount
  useEffect(() => {
    loadAttendanceData();
  }, [userData.employeeId]);

  const loadAttendanceData = () => {
    try {
      setIsLoading(true);
      const allRecords = JSON.parse(localStorage.getItem('attendanceRecords') || '[]');
      
      // Filter records for current user
      const userRecords = allRecords.filter((record: AttendanceRecord) => 
        record.employeeId === userData.employeeId
      );
      
      setAttendanceRecords(userRecords);
      console.log(`✅ Loaded ${userRecords.length} attendance records for ${userData.employeeId}`);
    } catch (error) {
      console.error('Error loading attendance data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Get attendance for a specific date
  const getAttendanceForDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0];
    return attendanceRecords.find(record => record.date === dateString);
  };

  // Get all dates with attendance in current month
  const getAttendanceDatesInMonth = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    return attendanceRecords.filter(record => {
      const recordDate = new Date(record.date);
      return recordDate.getFullYear() === year && recordDate.getMonth() === month;
    }).map(record => new Date(record.date));
  };

  // Custom day renderer for calendar
  const renderDay = (date: Date) => {
    const attendance = getAttendanceForDate(date);
    const isToday = date.toDateString() === new Date().toDateString();
    const isSelected = selectedDate && date.toDateString() === selectedDate.toDateString();
    
    return (
      <div
        className={`
          relative w-full h-full flex items-center justify-center cursor-pointer rounded-lg transition-all
          ${isSelected ? 'bg-primary text-white' : ''}
          ${isToday && !isSelected ? 'bg-accent/10 text-accent font-medium' : ''}
          hover:bg-gray-100
        `}
        onClick={() => {
          setSelectedDate(date);
          setSelectedRecord(attendance || null);
        }}
      >
        <span className="text-sm">{date.getDate()}</span>
        {attendance && (
          <div className={`absolute bottom-1 right-1 w-2 h-2 rounded-full ${
            attendance.status === 'present' ? 'bg-green-500' : 
            attendance.status === 'absent' ? 'bg-red-500' : 'bg-orange-500'
          }`} />
        )}
      </div>
    );
  };

  // Calculate monthly statistics
  const getMonthlyStats = () => {
    const monthRecords = getAttendanceDatesInMonth().map(date => getAttendanceForDate(date));
    const present = monthRecords.filter(r => r?.status === 'present').length;
    const absent = monthRecords.filter(r => r?.status === 'absent').length;
    const halfDay = monthRecords.filter(r => r?.status === 'half-day').length;
    const total = monthRecords.length;
    
    return { present, absent, halfDay, total };
  };

  const monthlyStats = getMonthlyStats();
  const attendancePercentage = monthlyStats.total > 0 ? 
    Math.round((monthlyStats.present + (monthlyStats.halfDay * 0.5)) / monthlyStats.total * 100) : 0;

  const formatTime = (timeString?: string) => {
    if (!timeString) return 'Not recorded';
    try {
      // Use IST timezone formatting
      return formatTimeIST(timeString);
    } catch (error) {
      return timeString;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'present':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'absent':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'half-day':
        return <Clock className="w-5 h-5 text-orange-600" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-green-100 text-green-800';
      case 'absent':
        return 'bg-red-100 text-red-800';
      case 'half-day':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-6xl mx-auto px-6 py-4">
            <button 
              onClick={onBack}
              className="text-primary hover:text-primary/80 font-medium"
            >
              ← Back to Dashboard
            </button>
          </div>
        </div>
        <div className="max-w-6xl mx-auto p-6">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin w-8 h-8 border-2 border-primary/20 border-t-primary rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <button 
              onClick={onBack}
              className="text-primary hover:text-primary/80 font-medium"
            >
              ← Back to Dashboard
            </button>
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-primary" />
              <h1 className="text-lg font-semibold text-primary">Attendance History</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Employee Info */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-semibold">{userData.name}</h2>
                <p className="text-muted-foreground">{userData.employeeId} • {userData.designation}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar Section */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <CalendarIcon className="w-5 h-5" />
                    {currentMonth.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                    <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
                      {day}
                    </div>
                  ))}
                </div>
                
                <div className="grid grid-cols-7 gap-1">
                  {Array.from({ length: 42 }, (_, i) => {
                    const startOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
                    const startOfWeek = new Date(startOfMonth);
                    startOfWeek.setDate(startOfMonth.getDate() - startOfMonth.getDay());
                    
                    const currentDate = new Date(startOfWeek);
                    currentDate.setDate(startOfWeek.getDate() + i);
                    
                    const isCurrentMonth = currentDate.getMonth() === currentMonth.getMonth();
                    
                    return (
                      <div
                        key={i}
                        className={`
                          h-12 border border-gray-100 
                          ${!isCurrentMonth ? 'text-gray-300 bg-gray-50' : ''}
                        `}
                      >
                        {isCurrentMonth && renderDay(currentDate)}
                      </div>
                    );
                  })}
                </div>

                {/* Legend */}
                <div className="flex items-center gap-4 mt-4 pt-4 border-t">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-sm text-muted-foreground">Present</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <span className="text-sm text-muted-foreground">Absent</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                    <span className="text-sm text-muted-foreground">Half Day</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Details Section */}
          <div className="space-y-6">
            {/* Monthly Statistics */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">{attendancePercentage}%</div>
                  <p className="text-sm text-muted-foreground">Attendance Rate</p>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm">Present</span>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      {monthlyStats.present}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-red-600" />
                      <span className="text-sm">Absent</span>
                    </div>
                    <Badge variant="secondary" className="bg-red-100 text-red-800">
                      {monthlyStats.absent}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-orange-600" />
                      <span className="text-sm">Half Day</span>
                    </div>
                    <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                      {monthlyStats.halfDay}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Selected Date Details */}
            {selectedDate && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">
                    {selectedDate.toLocaleDateString('en-IN', { 
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedRecord ? (
                    <div className="space-y-4">
                      {/* Status */}
                      <div className="flex items-center gap-2">
                        {getStatusIcon(selectedRecord.status)}
                        <Badge variant="secondary" className={getStatusColor(selectedRecord.status)}>
                          {selectedRecord.status.charAt(0).toUpperCase() + selectedRecord.status.slice(1)}
                        </Badge>
                      </div>

                      {/* Timing */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="font-medium">Check In:</span>
                          <span>{formatTime(selectedRecord.checkInTime)}</span>
                        </div>
                        {selectedRecord.checkOutTime && (
                          <div className="flex items-center gap-2 text-sm">
                            <Clock className="w-4 h-4 text-muted-foreground" />
                            <span className="font-medium">Check Out:</span>
                            <span>{formatTime(selectedRecord.checkOutTime)}</span>
                          </div>
                        )}
                      </div>

                      {/* Location */}
                      {selectedRecord.location && (
                        <div className="flex items-start gap-2 text-sm">
                          <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                          <div>
                            <p className="font-medium">Location:</p>
                            <p className="text-muted-foreground">{selectedRecord.location.address}</p>
                            <p className="text-xs text-muted-foreground">
                              Accuracy: {selectedRecord.location.accuracy}m
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Work Location */}
                      {selectedRecord.workLocation && (
                        <div className="flex items-center gap-2 text-sm">
                          <FileText className="w-4 h-4 text-muted-foreground" />
                          <span className="font-medium">Work Location:</span>
                          <span>{selectedRecord.workLocation}</span>
                        </div>
                      )}

                      {/* Photo Status */}
                      <div className="flex items-center gap-2 text-sm">
                        <Camera className="w-4 h-4 text-muted-foreground" />
                        <span className="font-medium">Photo:</span>
                        <span className={selectedRecord.photoUrl ? 'text-green-600' : 'text-muted-foreground'}>
                          {selectedRecord.photoUrl ? 'Captured' : 'Not Available'}
                        </span>
                      </div>

                      {/* Notes */}
                      {selectedRecord.notes && (
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Notes:</p>
                          <p className="text-sm text-muted-foreground bg-gray-50 p-2 rounded">
                            {selectedRecord.notes}
                          </p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground">No attendance record for this date</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}