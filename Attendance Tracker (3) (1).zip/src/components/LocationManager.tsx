import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { Textarea } from "./ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  MapPin, 
  Plus, 
  Users, 
  Navigation as NavigationIcon,
  Phone,
  Clock,
  Building,
  Edit,
  Trash2,
  MapPinned
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { LiveAttendanceMap } from "./LiveAttendanceMap";

interface Location {
  id: string;
  name: string;
  address: string;
  city: string;
  coordinates: {
    latitude: number;
    longitude: number;
  };
  workersCount: number;
  manager: string;
  managerPhone: string;
  workingHours: string;
  status: 'active' | 'inactive';
  description: string;
  image?: string;
}

const mockLocations: Location[] = [
  {
    id: '1',
    name: 'Ahmedabad Site A',
    address: 'GIDC, Vatva Industrial Area',
    city: 'Ahmedabad',
    coordinates: { latitude: 23.0225, longitude: 72.5714 },
    workersCount: 45,
    manager: 'Suresh Patel',
    managerPhone: '+91 98765 43210',
    workingHours: '8:00 AM - 6:00 PM',
    status: 'active',
    description: 'Main construction site for residential complex',
    image: 'https://images.unsplash.com/photo-1632398461186-37c76a70062f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhzaXRlJTIwZ3VqYXJhdHxlbnwxfHx8fDE3NTg3MDA1MzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '2',
    name: 'Surat Site B',
    address: 'Hazira Industrial Area',
    city: 'Surat',
    coordinates: { latitude: 21.0000, longitude: 72.8000 },
    workersCount: 38,
    manager: 'Ravi Kumar',
    managerPhone: '+91 98765 43211',
    workingHours: '7:30 AM - 5:30 PM',
    status: 'active',
    description: 'Commercial building construction project'
  },
  {
    id: '3',
    name: 'Vadodara Site C',
    address: 'GIDC, Vadodara',
    city: 'Vadodara',
    coordinates: { latitude: 22.3072, longitude: 73.1812 },
    workersCount: 32,
    manager: 'Anjali Sharma',
    managerPhone: '+91 98765 43212',
    workingHours: '8:00 AM - 6:00 PM',
    status: 'active',
    description: 'Infrastructure development project'
  },
  {
    id: '4',
    name: 'Rajkot Site D',
    address: 'Metoda GIDC',
    city: 'Rajkot',
    coordinates: { latitude: 22.3039, longitude: 70.8022 },
    workersCount: 28,
    manager: 'Kiran Modi',
    managerPhone: '+91 98765 43213',
    workingHours: '8:00 AM - 5:00 PM',
    status: 'active',
    description: 'Industrial facility construction'
  },
  {
    id: '5',
    name: 'Bhavnagar Site E',
    address: 'Industrial Estate',
    city: 'Bhavnagar',
    coordinates: { latitude: 21.7645, longitude: 72.1519 },
    workersCount: 22,
    manager: 'Dipak Joshi',
    managerPhone: '+91 98765 43214',
    workingHours: '8:00 AM - 6:00 PM',
    status: 'inactive',
    description: 'Port infrastructure project (on hold)'
  }
];

export function LocationManager() {
  const [locations] = useState<Location[]>(mockLocations);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);

  const activeLocations = locations.filter(l => l.status === 'active');
  const totalWorkers = locations.reduce((sum, loc) => sum + loc.workersCount, 0);

  const getStatusBadge = (status: Location['status']) => {
    return status === 'active' ? (
      <Badge className="bg-green-100 text-green-800 border-green-200">Active</Badge>
    ) : (
      <Badge className="bg-gray-100 text-gray-800 border-gray-200">Inactive</Badge>
    );
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Location Management</h1>
          <p className="text-muted-foreground">
            Manage work sites and live attendance locations across Gujarat
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add New Location
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Location</DialogTitle>
              <DialogDescription>
                Add a new work site location to track attendance and manage workers.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="locationName">Location Name</Label>
                <Input id="locationName" placeholder="Enter location name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea id="address" placeholder="Enter full address" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="latitude">Latitude</Label>
                  <Input id="latitude" type="number" step="any" placeholder="23.0225" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="longitude">Longitude</Label>
                  <Input id="longitude" type="number" step="any" placeholder="72.5714" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="manager">Site Manager</Label>
                <Input id="manager" placeholder="Manager name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="managerPhone">Manager Phone</Label>
                <Input id="managerPhone" placeholder="+91 98765 43210" />
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={() => setIsAddDialogOpen(false)} variant="outline" className="flex-1">
                  Cancel
                </Button>
                <Button className="flex-1">Add Location</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-600" />
              <div>
                <div className="text-2xl font-bold">{locations.length}</div>
                <p className="text-sm text-muted-foreground">Total Locations</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Building className="w-5 h-5 text-green-600" />
              <div>
                <div className="text-2xl font-bold text-green-600">{activeLocations.length}</div>
                <p className="text-sm text-muted-foreground">Active Sites</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-600" />
              <div>
                <div className="text-2xl font-bold text-purple-600">{totalWorkers}</div>
                <p className="text-sm text-muted-foreground">Total Workers</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <NavigationIcon className="w-5 h-5 text-orange-600" />
              <div>
                <div className="text-2xl font-bold text-orange-600">
                  {Math.round(totalWorkers / activeLocations.length)}
                </div>
                <p className="text-sm text-muted-foreground">Avg per Site</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for Map Views */}
      <Tabs defaultValue="live" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="live" className="flex items-center gap-2">
            <MapPinned className="w-4 h-4" />
            Live Attendance Map
          </TabsTrigger>
          <TabsTrigger value="sites" className="flex items-center gap-2">
            <Building className="w-4 h-4" />
            Work Sites
          </TabsTrigger>
        </TabsList>

        <TabsContent value="live">
          <LiveAttendanceMap />
        </TabsContent>

        <TabsContent value="sites" className="space-y-6">
          {/* Map View */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Gujarat Work Sites Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="aspect-[16/9] bg-gray-100 rounded-lg flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <MapPin className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Work sites map view</p>
                  <p className="text-sm">Showing {activeLocations.length} active locations</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Locations Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {locations.map((location) => (
          <Card key={location.id} className="overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{location.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{location.city}</p>
                </div>
                {getStatusBadge(location.status)}
              </div>
            </CardHeader>
            
            {location.image && (
              <div className="px-6 pb-3">
                <div className="aspect-video rounded-lg overflow-hidden">
                  <ImageWithFallback 
                    src={location.image}
                    alt={location.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}
            
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div className="text-sm">
                    <div>{location.address}</div>
                    <div className="text-muted-foreground">
                      {location.coordinates.latitude.toFixed(4)}, {location.coordinates.longitude.toFixed(4)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{location.workersCount} workers assigned</span>
                </div>

                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{location.workingHours}</span>
                </div>
              </div>

              <div className="border-t pt-3">
                <div className="text-sm">
                  <div className="font-medium">Site Manager</div>
                  <div className="text-muted-foreground">{location.manager}</div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Phone className="w-3 h-3" />
                    {location.managerPhone}
                  </div>
                </div>
              </div>

              <div className="text-sm text-muted-foreground">
                {location.description}
              </div>

              <div className="flex gap-2 pt-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => setSelectedLocation(location)}
                >
                  <Edit className="w-4 h-4 mr-1" />
                  Edit
                </Button>
                <Button size="sm" variant="outline">
                  <NavigationIcon className="w-4 h-4 mr-1" />
                  Navigate
                </Button>
              </div>
              </CardContent>
            </Card>
          ))}
          </div>

          {/* Quick Stats by City */}
          <Card>
            <CardHeader>
              <CardTitle>Sites by City</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {Array.from(new Set(locations.map(l => l.city))).map((city) => {
                  const cityLocations = locations.filter(l => l.city === city);
                  const cityWorkers = cityLocations.reduce((sum, loc) => sum + loc.workersCount, 0);
                  
                  return (
                    <div key={city} className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="font-medium">{city}</div>
                      <div className="text-sm text-muted-foreground">
                        {cityLocations.length} sites • {cityWorkers} workers
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}