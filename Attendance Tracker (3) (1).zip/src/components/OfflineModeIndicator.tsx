import { useState, useEffect } from 'react';
import { Badge } from './ui/badge';
import { WifiOff, Wifi } from 'lucide-react';

export function OfflineModeIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) {
    return (
      <Badge variant="secondary" className="bg-green-100 text-green-800">
        <Wifi className="w-3 h-3 mr-1" />
        Online Mode
      </Badge>
    );
  }

  return (
    <Badge variant="secondary" className="bg-orange-100 text-orange-800">
      <WifiOff className="w-3 h-3 mr-1" />
      Offline Mode
    </Badge>
  );
}