import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  MapPin, 
  Users, 
  Navigation as NavigationIcon,
  Phone,
  Clock,
  Building,
  Camera,
  RefreshCw,
  MapPinned,
  CheckCircle,
  XCircle,
  Calendar
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface AttendanceRecord {
  employeeId: string;
  name: string;
  date: string;
  checkInTime: string;
  status: 'present' | 'absent' | 'half-day';
  location?: {
    latitude: number;
    longitude: number;
    accuracy: number;
    address: string;
  };
  photoUrl?: string;
  notes?: string;
  workLocation?: string;
  task?: string;
  reportingManager: string;
}

interface LiveAttendanceMapProps {
  onBack?: () => void;
}

export function LiveAttendanceMap({ onBack }: LiveAttendanceMapProps) {
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [filteredRecords, setFilteredRecords] = useState<AttendanceRecord[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedRecord, setSelectedRecord] = useState<AttendanceRecord | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: 23.0225, lng: 72.5714 }); // Gujarat center

  useEffect(() => {
    loadAttendanceRecords();
  }, [selectedDate]);

  useEffect(() => {
    applyFilters();
  }, [attendanceRecords, filterStatus]);

  const loadAttendanceRecords = () => {
    try {
      const records = JSON.parse(localStorage.getItem('attendanceRecords') || '[]');
      const todayRecords = records.filter((record: AttendanceRecord) => 
        record.date === selectedDate && record.location
      );
      setAttendanceRecords(todayRecords);
    } catch (error) {
      console.error('Error loading attendance records:', error);
    }
  };

  const applyFilters = () => {
    let filtered = [...attendanceRecords];
    
    if (filterStatus !== 'all') {
      filtered = filtered.filter(record => record.status === filterStatus);
    }
    
    setFilteredRecords(filtered);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-green-500';
      case 'half-day':
        return 'bg-yellow-500';
      case 'absent':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'present':
        return <Badge className="bg-green-100 text-green-800">Present</Badge>;
      case 'half-day':
        return <Badge className="bg-yellow-100 text-yellow-800">Half Day</Badge>;
      case 'absent':
        return <Badge className="bg-red-100 text-red-800">Absent</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const openGoogleMaps = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps?q=${lat},${lng}`, '_blank');
  };

  const presentCount = attendanceRecords.filter(r => r.status === 'present').length;
  const halfDayCount = attendanceRecords.filter(r => r.status === 'half-day').length;
  const absentWithLocationCount = attendanceRecords.filter(r => r.status === 'absent' && r.location).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      {/* Header */}
      {onBack && (
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={onBack} className="p-2">
                <NavigationIcon className="w-4 h-4" />
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-lg font-semibold text-primary">Live Attendance Map</h1>
                  <p className="text-sm text-muted-foreground">Real-time geo-located attendance tracking</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <div className="text-2xl font-bold text-green-600">{presentCount}</div>
                  <p className="text-sm text-muted-foreground">Present</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-yellow-600" />
                <div>
                  <div className="text-2xl font-bold text-yellow-600">{halfDayCount}</div>
                  <p className="text-sm text-muted-foreground">Half Day</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <MapPinned className="w-5 h-5 text-blue-600" />
                <div>
                  <div className="text-2xl font-bold text-blue-600">{filteredRecords.length}</div>
                  <p className="text-sm text-muted-foreground">Locations Tracked</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                <div>
                  <div className="text-2xl font-bold text-purple-600">{attendanceRecords.length}</div>
                  <p className="text-sm text-muted-foreground">Total Checked In</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-3 py-2 border rounded-lg bg-input-background"
                />
              </div>

              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Filter:</span>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="present">Present Only</SelectItem>
                    <SelectItem value="half-day">Half Day Only</SelectItem>
                    <SelectItem value="absent">Absent Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                variant="outline" 
                size="sm" 
                onClick={loadAttendanceRecords}
                className="ml-auto"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Interactive Map Placeholder */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Gujarat State - Live Attendance Locations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="aspect-[16/9] bg-gradient-to-br from-blue-50 to-green-50 rounded-lg relative overflow-hidden border-2 border-blue-200">
              {/* Map Grid Background */}
              <div className="absolute inset-0 opacity-10">
                <div className="grid grid-cols-8 grid-rows-8 h-full">
                  {Array.from({ length: 64 }).map((_, i) => (
                    <div key={i} className="border border-blue-300" />
                  ))}
                </div>
              </div>

              {/* Map Markers */}
              <div className="absolute inset-0 p-8">
                {filteredRecords.map((record, index) => {
                  if (!record.location) return null;
                  
                  // Normalize coordinates to fit the map area
                  // Gujarat: lat ~20-24, lng ~68-74
                  const normalizedLat = ((record.location.latitude - 20) / 4) * 100;
                  const normalizedLng = ((record.location.longitude - 68) / 6) * 100;
                  
                  return (
                    <div
                      key={record.employeeId + index}
                      className="absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 transition-all hover:scale-125"
                      style={{
                        left: `${Math.max(5, Math.min(95, normalizedLng))}%`,
                        top: `${Math.max(5, Math.min(95, 100 - normalizedLat))}%`
                      }}
                      onClick={() => setSelectedRecord(record)}
                    >
                      <div className={`w-4 h-4 rounded-full ${getStatusColor(record.status)} border-2 border-white shadow-lg animate-pulse`} />
                    </div>
                  );
                })}
              </div>

              {/* Map Legend */}
              <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm p-4 rounded-lg shadow-lg border">
                <div className="text-xs font-semibold mb-2">Legend</div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 rounded-full bg-green-500 border border-white" />
                    <span>Present ({presentCount})</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 rounded-full bg-yellow-500 border border-white" />
                    <span>Half Day ({halfDayCount})</span>
                  </div>
                  {absentWithLocationCount > 0 && (
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-3 h-3 rounded-full bg-red-500 border border-white" />
                      <span>Absent ({absentWithLocationCount})</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Map Info */}
              <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm px-3 py-2 rounded-lg shadow-lg border">
                <div className="text-xs font-semibold text-primary">Gujarat State Map</div>
                <div className="text-xs text-muted-foreground">{filteredRecords.length} locations tracked</div>
              </div>
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-muted-foreground">
                Click on any marker to view attendance details and location
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Selected Record Details */}
        {selectedRecord && (
          <Card className="border-2 border-primary shadow-lg">
            <CardHeader className="bg-primary/5">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Attendance Details
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedRecord(null)}
                >
                  ✕
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Employee Info */}
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{selectedRecord.name}</h3>
                        <p className="text-sm text-muted-foreground">{selectedRecord.employeeId}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">Status:</span>
                      {getStatusBadge(selectedRecord.status)}
                    </div>

                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">Check-in:</span>
                      <span className="text-sm font-medium">
                        {new Date(selectedRecord.checkInTime).toLocaleString('en-IN')}
                      </span>
                    </div>

                    {selectedRecord.task && (
                      <div className="flex items-center gap-2">
                        <Building className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">Task:</span>
                        <span className="text-sm font-medium">{selectedRecord.task}</span>
                      </div>
                    )}

                    {selectedRecord.workLocation && (
                      <div className="flex items-center gap-2">
                        <Building className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">Workplace:</span>
                        <span className="text-sm font-medium">{selectedRecord.workLocation}</span>
                      </div>
                    )}
                  </div>

                  {/* Location Details */}
                  {selectedRecord.location && (
                    <div className="border-t pt-4 space-y-3">
                      <h4 className="font-semibold text-sm flex items-center gap-2">
                        <MapPinned className="w-4 h-4" />
                        Location Details
                      </h4>
                      
                      <div className="space-y-2 text-sm bg-gray-50 p-3 rounded-lg">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-muted-foreground">Latitude:</span>
                            <div className="font-mono font-medium">{selectedRecord.location.latitude.toFixed(6)}</div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Longitude:</span>
                            <div className="font-mono font-medium">{selectedRecord.location.longitude.toFixed(6)}</div>
                          </div>
                        </div>
                        
                        <div>
                          <span className="text-muted-foreground">Accuracy:</span>
                          <div className="font-medium">±{Math.round(selectedRecord.location.accuracy)}m</div>
                        </div>
                        
                        <div>
                          <span className="text-muted-foreground">Address:</span>
                          <div className="font-medium">{selectedRecord.location.address}</div>
                        </div>
                      </div>

                      <Button
                        onClick={() => openGoogleMaps(
                          selectedRecord.location!.latitude,
                          selectedRecord.location!.longitude
                        )}
                        className="w-full"
                        variant="outline"
                      >
                        <NavigationIcon className="w-4 h-4 mr-2" />
                        Open in Google Maps
                      </Button>
                    </div>
                  )}
                </div>

                {/* Photo */}
                <div>
                  {selectedRecord.photoUrl ? (
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm flex items-center gap-2">
                        <Camera className="w-4 h-4" />
                        Attendance Photo
                      </h4>
                      <div className="relative aspect-[3/4] rounded-lg overflow-hidden border">
                        <ImageWithFallback
                          src={selectedRecord.photoUrl}
                          alt={`${selectedRecord.name} attendance photo`}
                          className="w-full h-full object-cover"
                        />
                        {selectedRecord.location && (
                          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                            <div className="flex items-center gap-2 text-white text-xs">
                              <MapPin className="w-3 h-3" />
                              <span>Geo-verified location</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="aspect-[3/4] rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center">
                      <div className="text-center text-muted-foreground">
                        <Camera className="w-8 h-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No photo available</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Attendance List */}
        <Card>
          <CardHeader>
            <CardTitle>Today's Attendance ({filteredRecords.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredRecords.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <MapPin className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>No attendance records with location data for this date</p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredRecords.map((record) => (
                  <div
                    key={record.employeeId + record.checkInTime}
                    className={`flex items-center justify-between p-4 rounded-lg border hover:shadow-md transition-all cursor-pointer ${
                      selectedRecord?.employeeId === record.employeeId ? 'bg-primary/5 border-primary' : 'bg-white'
                    }`}
                    onClick={() => setSelectedRecord(record)}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(record.status)}`} />
                      <div>
                        <div className="font-medium">{record.name}</div>
                        <div className="text-sm text-muted-foreground">{record.employeeId}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {new Date(record.checkInTime).toLocaleTimeString('en-IN', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {record.workLocation || 'N/A'}
                        </div>
                      </div>
                      
                      {getStatusBadge(record.status)}
                      
                      {record.location && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation();
                            openGoogleMaps(record.location!.latitude, record.location!.longitude);
                          }}
                        >
                          <MapPin className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}