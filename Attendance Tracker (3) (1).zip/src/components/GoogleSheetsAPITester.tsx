import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  RefreshCw, 
  ExternalLink,
  Settings,
  Key,
  FileText,
  Database,
  Clock
} from 'lucide-react';
import { googleSheetsService } from '../services/GoogleSheetsService';

interface TestResult {
  name: string;
  status: 'running' | 'success' | 'error' | 'warning';
  message: string;
  details?: string;
  actionUrl?: string;
  actionText?: string;
}

export function GoogleSheetsAPITester() {
  const [tests, setTests] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [showDetails, setShowDetails] = useState<Record<string, boolean>>({});

  const updateTest = (name: string, update: Partial<TestResult>) => {
    setTests(prev => prev.map(test => 
      test.name === name ? { ...test, ...update } : test
    ));
  };

  const addTest = (test: TestResult) => {
    setTests(prev => [...prev, test]);
  };

  const runDiagnostics = async () => {
    setIsRunning(true);
    setTests([]);

    // Test 1: API Key Format
    addTest({
      name: 'API Key Format',
      status: 'running',
      message: 'Validating API key format...'
    });

    const apiKey = 'AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8';
    const isValidFormat = apiKey.startsWith('AIza') && apiKey.length === 39;
    
    updateTest('API Key Format', {
      status: isValidFormat ? 'success' : 'error',
      message: isValidFormat 
        ? 'API key format is valid'
        : 'API key format is invalid',
      details: isValidFormat 
        ? `Key: ${apiKey.substring(0, 4)}***${apiKey.slice(-4)}`
        : `Expected: Start with "AIza" and be 39 chars. Current: ${apiKey.length} chars, starts with "${apiKey.substring(0, 4)}"`,
      actionUrl: 'https://console.cloud.google.com/apis/credentials',
      actionText: 'Check API Keys'
    });

    // Test 2: Google Sheets API Status
    addTest({
      name: 'Google Sheets API',
      status: 'running',
      message: 'Checking if Google Sheets API is enabled...'
    });

    try {
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY?key=${apiKey}`, {
        method: 'GET'
      });

      if (response.status === 403) {
        const errorText = await response.text();
        if (errorText.includes('Google Sheets API has not been used')) {
          updateTest('Google Sheets API', {
            status: 'error',
            message: 'Google Sheets API is not enabled',
            details: 'The Google Sheets API needs to be enabled for your project',
            actionUrl: 'https://console.cloud.google.com/apis/library/sheets.googleapis.com',
            actionText: 'Enable Google Sheets API'
          });
        } else {
          updateTest('Google Sheets API', {
            status: 'error',
            message: 'Google Sheets API access denied',
            details: errorText,
            actionUrl: 'https://console.cloud.google.com/apis/credentials',
            actionText: 'Check API Key Settings'
          });
        }
      } else if (response.status === 401) {
        updateTest('Google Sheets API', {
          status: 'error',
          message: 'API key authentication failed',
          details: 'The API key is rejected by Google. Check if it has the right permissions and no restrictions.',
          actionUrl: 'https://console.cloud.google.com/apis/credentials',
          actionText: 'Fix API Key'
        });
      } else if (response.status === 400) {
        updateTest('Google Sheets API', {
          status: 'error',
          message: 'Bad request - Invalid parameters',
          details: 'The request format is invalid. This might be due to an incorrect spreadsheet ID or API key.',
          actionUrl: 'https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY',
          actionText: 'Check Spreadsheet'
        });
      } else if (response.ok) {
        updateTest('Google Sheets API', {
          status: 'success',
          message: 'Google Sheets API is working',
          details: 'Successfully connected to Google Sheets API'
        });
      } else {
        updateTest('Google Sheets API', {
          status: 'error',
          message: `HTTP ${response.status}: ${response.statusText}`,
          details: await response.text().catch(() => 'Unknown error')
        });
      }
    } catch (error) {
      updateTest('Google Sheets API', {
        status: 'error',
        message: 'Network error',
        details: error instanceof Error ? error.message : 'Failed to reach Google Sheets API',
        actionUrl: 'https://console.cloud.google.com/apis/dashboard',
        actionText: 'Check API Dashboard'
      });
    }

    // Test 3: Spreadsheet Access
    addTest({
      name: 'Spreadsheet Access',
      status: 'running',
      message: 'Testing spreadsheet access...'
    });

    try {
      const spreadsheetId = '1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY';
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?key=${apiKey}&fields=properties.title,sheets.properties.title`);
      
      if (response.ok) {
        const data = await response.json();
        const sheetNames = data.sheets?.map((sheet: any) => sheet.properties.title) || [];
        
        updateTest('Spreadsheet Access', {
          status: 'success',
          message: 'Spreadsheet accessible',
          details: `Title: "${data.properties?.title}"\nSheets: ${sheetNames.join(', ')}`,
          actionUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}`,
          actionText: 'Open Spreadsheet'
        });
      } else if (response.status === 404) {
        updateTest('Spreadsheet Access', {
          status: 'error',
          message: 'Spreadsheet not found',
          details: 'The spreadsheet ID is invalid or the spreadsheet has been deleted',
          actionUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}`,
          actionText: 'Check Spreadsheet'
        });
      } else if (response.status === 403) {
        updateTest('Spreadsheet Access', {
          status: 'error',
          message: 'Access denied to spreadsheet',
          details: 'The spreadsheet is not shared with the service account or API key lacks permissions',
          actionUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}`,
          actionText: 'Share Spreadsheet'
        });
      } else {
        updateTest('Spreadsheet Access', {
          status: 'error',
          message: `Failed to access spreadsheet (${response.status})`,
          details: await response.text().catch(() => 'Unknown error')
        });
      }
    } catch (error) {
      updateTest('Spreadsheet Access', {
        status: 'error',
        message: 'Network error accessing spreadsheet',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    // Test 4: Service Account
    addTest({
      name: 'Service Account',
      status: 'running',
      message: 'Checking service account configuration...'
    });

    const serviceAccountEmail = 'attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com';
    updateTest('Service Account', {
      status: 'warning',
      message: 'Service account configured',
      details: `Email: ${serviceAccountEmail}\nNote: Make sure the spreadsheet is shared with this email address`,
      actionUrl: 'https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY',
      actionText: 'Share with Service Account'
    });

    // Test 5: Authentication Status
    addTest({
      name: 'Authentication Status',
      status: 'running',
      message: 'Checking authentication status...'
    });

    const authStatus = googleSheetsService.getAuthStatus();
    updateTest('Authentication Status', {
      status: authStatus.authenticated ? 'success' : 'warning',
      message: authStatus.authenticated ? 'Authenticated' : 'Not authenticated',
      details: `Method: ${authStatus.method}\nHas tokens: ${authStatus.hasTokens}\n${authStatus.tokenExpiry ? `Token expires: ${authStatus.tokenExpiry.toLocaleString()}` : ''}`
    });

    setIsRunning(false);
  };

  useEffect(() => {
    runDiagnostics();
  }, []);

  const getStatusIcon = (status: TestResult['status']) => {
    switch (status) {
      case 'running':
        return <RefreshCw className="w-4 h-4 animate-spin text-blue-500" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: TestResult['status']) => {
    switch (status) {
      case 'running':
        return <Badge className="bg-blue-100 text-blue-800">Running</Badge>;
      case 'success':
        return <Badge className="bg-green-100 text-green-800">Pass</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800">Fail</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-800">Warning</Badge>;
    }
  };

  const toggleDetails = (testName: string) => {
    setShowDetails(prev => ({
      ...prev,
      [testName]: !prev[testName]
    }));
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Google Sheets API Diagnostics
            </CardTitle>
            <Button 
              onClick={runDiagnostics} 
              disabled={isRunning}
              size="sm"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Testing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Run Tests
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {tests.map((test) => (
              <div key={test.name} className="border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(test.status)}
                    <div>
                      <h3 className="font-medium">{test.name}</h3>
                      <p className="text-sm text-muted-foreground">{test.message}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(test.status)}
                    {test.details && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleDetails(test.name)}
                      >
                        {showDetails[test.name] ? 'Hide' : 'Details'}
                      </Button>
                    )}
                  </div>
                </div>
                
                {showDetails[test.name] && test.details && (
                  <div className="mt-3 p-3 bg-gray-50 rounded text-sm">
                    <pre className="whitespace-pre-wrap text-xs">{test.details}</pre>
                    {test.actionUrl && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={() => window.open(test.actionUrl, '_blank')}
                      >
                        <ExternalLink className="w-3 h-3 mr-1" />
                        {test.actionText}
                      </Button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Fix Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="w-5 h-5" />
            Quick Fix Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              variant="outline"
              className="h-auto p-4 flex flex-col items-start"
              onClick={() => window.open('https://console.cloud.google.com/apis/library/sheets.googleapis.com', '_blank')}
            >
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-4 h-4" />
                <span className="font-medium">Enable Google Sheets API</span>
              </div>
              <span className="text-xs text-muted-foreground text-left">
                Enable the Google Sheets API for your project if it's not already enabled
              </span>
            </Button>

            <Button
              variant="outline"
              className="h-auto p-4 flex flex-col items-start"
              onClick={() => window.open('https://console.cloud.google.com/apis/credentials', '_blank')}
            >
              <div className="flex items-center gap-2 mb-2">
                <Key className="w-4 h-4" />
                <span className="font-medium">Check API Key Settings</span>
              </div>
              <span className="text-xs text-muted-foreground text-left">
                Verify API key restrictions and permissions
              </span>
            </Button>

            <Button
              variant="outline"
              className="h-auto p-4 flex flex-col items-start"
              onClick={() => window.open('https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY', '_blank')}
            >
              <div className="flex items-center gap-2 mb-2">
                <FileText className="w-4 h-4" />
                <span className="font-medium">Open Spreadsheet</span>
              </div>
              <span className="text-xs text-muted-foreground text-left">
                Share with: attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com
              </span>
            </Button>

            <Button
              variant="outline"
              className="h-auto p-4 flex flex-col items-start"
              onClick={() => window.open('https://console.cloud.google.com/apis/dashboard', '_blank')}
            >
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4" />
                <span className="font-medium">API Dashboard</span>
              </div>
              <span className="text-xs text-muted-foreground text-left">
                Check API usage, quotas, and error logs
              </span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}