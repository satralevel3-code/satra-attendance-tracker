import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { 
  Users, 
  MapPin, 
  Clock, 
  Camera, 
  TrendingUp,
  CheckCircle,
  XCircle,
  AlertTriangle
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface DashboardStats {
  totalWorkers: number;
  presentToday: number;
  absentToday: number;
  lateArrivals: number;
  activeLocations: number;
}

interface RecentActivity {
  id: string;
  workerName: string;
  action: 'check-in' | 'check-out';
  time: string;
  location: string;
  photo?: string;
}

const mockStats: DashboardStats = {
  totalWorkers: 200,
  presentToday: 178,
  absentToday: 22,
  lateArrivals: 12,
  activeLocations: 8
};

const mockRecentActivity: RecentActivity[] = [
  {
    id: '1',
    workerName: 'Rajesh Kumar',
    action: 'check-in',
    time: '09:15 AM',
    location: 'Ahmedabad Site A',
    photo: 'https://images.unsplash.com/photo-1615892968147-cafd51492031?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjB3b3JrZXIlMjBpbmRpYXxlbnwxfHx8fDE3NTg3MDA1Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '2',
    workerName: 'Priya Patel',
    action: 'check-out',
    time: '06:00 PM',
    location: 'Surat Site B',
  },
  {
    id: '3',
    workerName: 'Amit Shah',
    action: 'check-in',
    time: '08:45 AM',
    location: 'Vadodara Site C',
  }
];

export function AttendanceDashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Attendance Dashboard</h1>
          <p className="text-muted-foreground">
            Field Worker Management - Gujarat State
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Live Tracking Active
          </Badge>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Camera className="w-4 h-4 mr-2" />
            Quick Check-in
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Workers</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalWorkers}</div>
            <p className="text-xs text-muted-foreground">Across all sites</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Present Today</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{mockStats.presentToday}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((mockStats.presentToday / mockStats.totalWorkers) * 100)}% attendance rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Absent Today</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{mockStats.absentToday}</div>
            <p className="text-xs text-muted-foreground">Requires follow-up</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Late Arrivals</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{mockStats.lateArrivals}</div>
            <p className="text-xs text-muted-foreground">After 9:00 AM</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Locations</CardTitle>
            <MapPin className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{mockStats.activeLocations}</div>
            <p className="text-xs text-muted-foreground">Across Gujarat</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockRecentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={activity.photo} />
                    <AvatarFallback>
                      {activity.workerName.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{activity.workerName}</span>
                      <Badge 
                        variant={activity.action === 'check-in' ? 'default' : 'secondary'}
                        className={activity.action === 'check-in' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}
                      >
                        {activity.action}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {activity.location} • {activity.time}
                    </div>
                  </div>
                  {activity.photo && (
                    <Camera className="w-4 h-4 text-green-600" />
                  )}
                </div>
              ))}
              <Button variant="outline" className="w-full">
                View All Activity
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Work Sites Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center mb-4">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1632398461186-37c76a70062f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhzaXRlJTIwZ3VqYXJhdHxlbnwxfHx8fDE3NTg3MDA1MzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Gujarat construction sites"
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Ahmedabad Sites</span>
                <Badge>45 workers</Badge>
              </div>
              <div className="flex justify-between">
                <span>Surat Sites</span>
                <Badge>38 workers</Badge>
              </div>
              <div className="flex justify-between">
                <span>Vadodara Sites</span>
                <Badge>32 workers</Badge>
              </div>
              <div className="flex justify-between">
                <span>Other Locations</span>
                <Badge>63 workers</Badge>
              </div>
            </div>
            <Button variant="outline" className="w-full mt-4">
              <MapPin className="w-4 h-4 mr-2" />
              View Map
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Button className="h-20 flex flex-col gap-2">
              <Camera className="w-6 h-6" />
              Mark Attendance
            </Button>
            <Button variant="outline" className="h-20 flex flex-col gap-2">
              <Users className="w-6 h-6" />
              Manage Workers
            </Button>
            <Button variant="outline" className="h-20 flex flex-col gap-2">
              <TrendingUp className="w-6 h-6" />
              View Reports
            </Button>
            <Button variant="outline" className="h-20 flex flex-col gap-2">
              <MapPin className="w-6 h-6" />
              Site Locations
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}