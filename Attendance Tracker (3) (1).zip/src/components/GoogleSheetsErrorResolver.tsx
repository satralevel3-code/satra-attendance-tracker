import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  ExternalLink, 
  RefreshCw,
  Copy,
  FileText,
  Key,
  Database,
  Shield
} from 'lucide-react';
import { toast } from 'sonner';

interface ErrorDetail {
  error: string;
  message: string;
  timestamp: string;
  suggestions: string[];
}

export function GoogleSheetsErrorResolver() {
  const [errors, setErrors] = useState<{
    error401?: ErrorDetail;
    error403?: ErrorDetail;
    error400?: ErrorDetail;
  }>({});
  const [isRetesting, setIsRetesting] = useState(false);

  useEffect(() => {
    // Load stored error details
    const loadErrors = () => {
      try {
        const error401 = localStorage.getItem('google_sheets_401_detailed');
        const error403 = localStorage.getItem('google_sheets_403_detailed');
        const error400 = localStorage.getItem('google_sheets_400_detailed');

        setErrors({
          error401: error401 ? JSON.parse(error401) : undefined,
          error403: error403 ? JSON.parse(error403) : undefined,
          error400: error400 ? JSON.parse(error400) : undefined,
        });
      } catch (error) {
        console.log('Error loading stored error details:', error);
      }
    };

    loadErrors();
    
    // Set up interval to check for new errors
    const interval = setInterval(loadErrors, 5000);
    return () => clearInterval(interval);
  }, []);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  const retestConnection = async () => {
    setIsRetesting(true);
    try {
      // Clear existing errors
      localStorage.removeItem('google_sheets_401_detailed');
      localStorage.removeItem('google_sheets_403_detailed');
      localStorage.removeItem('google_sheets_400_detailed');
      localStorage.removeItem('google_sheets_401_error');
      localStorage.removeItem('google_sheets_403_error');
      localStorage.removeItem('google_sheets_400_error');
      
      setErrors({});
      
      // Refresh the page to retest the connection
      window.location.reload();
    } catch (error) {
      toast.error('Failed to retest connection');
    } finally {
      setIsRetesting(false);
    }
  };

  const hasErrors = Object.values(errors).some(error => error !== undefined);

  if (!hasErrors) {
    return (
      <Card className="border-green-200 bg-green-50/50">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <div>
              <h3 className="font-medium text-green-900">No API Errors Detected</h3>
              <p className="text-sm text-green-700">Your Google Sheets API connection appears to be working properly</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* 401 Unauthorized Error */}
      {errors.error401 && (
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-800">
              <XCircle className="w-5 h-5" />
              401 Unauthorized - API Key Issue
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="font-medium">
                {errors.error401.message}
              </AlertDescription>
            </Alert>

            <div className="bg-red-50 rounded-lg p-4">
              <h4 className="font-medium text-red-900 mb-3">How to fix this:</h4>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-red-800 text-sm font-medium">1</div>
                  <div className="flex-1">
                    <p className="text-sm text-red-800 font-medium">Enable Google Sheets API</p>
                    <p className="text-xs text-red-700 mt-1">The API must be enabled for your Google Cloud project</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-2 text-red-700 border-red-300"
                      onClick={() => window.open('https://console.cloud.google.com/apis/library/sheets.googleapis.com', '_blank')}
                    >
                      <Database className="w-3 h-3 mr-1" />
                      Enable API
                    </Button>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-red-800 text-sm font-medium">2</div>
                  <div className="flex-1">
                    <p className="text-sm text-red-800 font-medium">Check API Key Restrictions</p>
                    <p className="text-xs text-red-700 mt-1">Remove IP/website restrictions that might block requests</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-2 text-red-700 border-red-300"
                      onClick={() => window.open('https://console.cloud.google.com/apis/credentials', '_blank')}
                    >
                      <Key className="w-3 h-3 mr-1" />
                      Check API Key
                    </Button>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-red-800 text-sm font-medium">3</div>
                  <div className="flex-1">
                    <p className="text-sm text-red-800 font-medium">Share Spreadsheet</p>
                    <p className="text-xs text-red-700 mt-1">Share with service account email</p>
                    <div className="flex items-center gap-2 mt-2">
                      <code className="text-xs bg-white px-2 py-1 rounded border">
                        attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com
                      </code>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard('attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com')}
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-2 text-red-700 border-red-300"
                      onClick={() => window.open('https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY', '_blank')}
                    >
                      <FileText className="w-3 h-3 mr-1" />
                      Open Spreadsheet
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 403 Forbidden Error */}
      {errors.error403 && (
        <Card className="border-orange-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <Shield className="w-5 h-5" />
              403 Forbidden - Permission Denied
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="font-medium">
                {errors.error403.message}
              </AlertDescription>
            </Alert>

            <div className="bg-orange-50 rounded-lg p-4">
              <h4 className="font-medium text-orange-900 mb-3">Most likely cause: Google Sheets API not enabled</h4>
              <Button 
                className="bg-orange-600 hover:bg-orange-700 text-white"
                onClick={() => window.open('https://console.cloud.google.com/apis/library/sheets.googleapis.com', '_blank')}
              >
                <Database className="w-4 h-4 mr-2" />
                Enable Google Sheets API Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 400 Bad Request Error */}
      {errors.error400 && (
        <Card className="border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-800">
              <AlertTriangle className="w-5 h-5" />
              400 Bad Request - Invalid Parameters
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="font-medium">
                {errors.error400.message}
              </AlertDescription>
            </Alert>

            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-3">Check these common issues:</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Spreadsheet ID is correct</li>
                <li>• Sheet names match exactly (case-sensitive)</li>
                <li>• API key format is valid (39 characters, starts with "AIza")</li>
                <li>• Required sheets exist in the spreadsheet</li>
              </ul>
              <Button 
                variant="outline" 
                className="mt-3 text-blue-700 border-blue-300"
                onClick={() => window.open('https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY', '_blank')}
              >
                <FileText className="w-4 h-4 mr-2" />
                Verify Spreadsheet
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <Card className="border-gray-200">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium">After Making Changes</h3>
              <p className="text-sm text-muted-foreground">Test the connection again to see if the issues are resolved</p>
            </div>
            <Button 
              onClick={retestConnection}
              disabled={isRetesting}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {isRetesting ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Testing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Retest Connection
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Debug Information */}
      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-sm">Debug Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-xs space-y-2">
            {Object.entries(errors).map(([key, error]) => error && (
              <div key={key}>
                <Badge variant="outline">{error.error}</Badge>
                <span className="ml-2 text-muted-foreground">
                  Last seen: {new Date(error.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}