import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  MapPin, 
  Camera, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  RefreshCw,
  Settings,
  Smartphone
} from 'lucide-react';

interface PermissionStatus {
  location: 'checking' | 'granted' | 'denied' | 'prompt' | 'unsupported';
  camera: 'checking' | 'granted' | 'denied' | 'prompt' | 'unsupported';
}

interface PermissionManagerProps {
  onPermissionsReady?: (hasPermissions: boolean) => void;
  onManualModeEnabled?: () => void;
  onShowGuide?: () => void;
  showManualOption?: boolean;
}

export function PermissionManager({ 
  onPermissionsReady, 
  onManualModeEnabled,
  onShowGuide,
  showManualOption = true 
}: PermissionManagerProps) {
  const [permissionStatus, setPermissionStatus] = useState<PermissionStatus>({
    location: 'checking',
    camera: 'checking'
  });
  const [isRequesting, setIsRequesting] = useState(false);

  useEffect(() => {
    checkPermissions();
  }, []);

  useEffect(() => {
    const hasPermissions = permissionStatus.location === 'granted' && permissionStatus.camera === 'granted';
    const allChecked = permissionStatus.location !== 'checking' && permissionStatus.camera !== 'checking';
    
    if (allChecked && onPermissionsReady) {
      onPermissionsReady(hasPermissions);
    }
  }, [permissionStatus, onPermissionsReady]);

  const checkPermissions = async () => {
    // Check location permission
    try {
      if ('permissions' in navigator) {
        const locationPermission = await navigator.permissions.query({ name: 'geolocation' });
        setPermissionStatus(prev => ({ ...prev, location: locationPermission.state }));
      } else if (navigator.geolocation) {
        setPermissionStatus(prev => ({ ...prev, location: 'prompt' }));
      } else {
        setPermissionStatus(prev => ({ ...prev, location: 'unsupported' }));
      }
    } catch (error) {
      setPermissionStatus(prev => ({ ...prev, location: 'prompt' }));
    }

    // Check camera permission
    try {
      if ('permissions' in navigator) {
        const cameraPermission = await navigator.permissions.query({ name: 'camera' as PermissionName });
        setPermissionStatus(prev => ({ ...prev, camera: cameraPermission.state }));
      } else if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        setPermissionStatus(prev => ({ ...prev, camera: 'prompt' }));
      } else {
        setPermissionStatus(prev => ({ ...prev, camera: 'unsupported' }));
      }
    } catch (error) {
      setPermissionStatus(prev => ({ ...prev, camera: 'prompt' }));
    }
  };

  const requestPermissions = async () => {
    setIsRequesting(true);
    
    try {
      // Request location
      if (permissionStatus.location !== 'granted') {
        try {
          await new Promise<void>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(
              () => {
                setPermissionStatus(prev => ({ ...prev, location: 'granted' }));
                resolve();
              },
              (error) => {
                setPermissionStatus(prev => ({ ...prev, location: 'denied' }));
                reject(error);
              },
              { timeout: 10000 }
            );
          });
        } catch (error) {
          console.log('Location permission request failed');
        }
      }

      // Request camera
      if (permissionStatus.camera !== 'granted') {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          setPermissionStatus(prev => ({ ...prev, camera: 'granted' }));
          // Stop the stream immediately
          stream.getTracks().forEach(track => track.stop());
        } catch (error) {
          setPermissionStatus(prev => ({ ...prev, camera: 'denied' }));
          console.log('Camera permission request failed');
        }
      }
    } finally {
      setIsRequesting(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'granted':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Granted</Badge>;
      case 'denied':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="w-3 h-3 mr-1" />Denied</Badge>;
      case 'prompt':
        return <Badge className="bg-blue-100 text-blue-800"><AlertTriangle className="w-3 h-3 mr-1" />Click to Allow</Badge>;
      case 'unsupported':
        return <Badge className="bg-gray-100 text-gray-800">Not Supported</Badge>;
      case 'checking':
        return <Badge className="bg-gray-100 text-gray-800">Checking...</Badge>;
      default:
        return null;
    }
  };

  const hasPermissions = permissionStatus.location === 'granted' && permissionStatus.camera === 'granted';
  const hasAnyDenied = permissionStatus.location === 'denied' || permissionStatus.camera === 'denied';
  const needsPermissions = permissionStatus.location === 'prompt' || permissionStatus.camera === 'prompt';

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" />
          App Permissions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Permission Status */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium">Location Access</span>
            </div>
            {getStatusBadge(permissionStatus.location)}
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4 text-green-600" />
              <span className="text-sm font-medium">Camera Access</span>
            </div>
            {getStatusBadge(permissionStatus.camera)}
          </div>
        </div>

        {/* Success State */}
        {hasPermissions && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <div className="flex items-center gap-2 text-green-800">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm font-medium">All permissions granted!</span>
            </div>
            <p className="text-xs text-green-700 mt-1">
              You can now capture attendance with location and photo verification.
            </p>
          </div>
        )}

        {/* Permission Needed */}
        {needsPermissions && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <div className="flex items-center gap-2 text-blue-800">
              <AlertTriangle className="w-4 h-4" />
              <span className="text-sm font-medium">Permissions Required</span>
            </div>
            <p className="text-xs text-blue-700 mt-1 mb-2">
              {isRequesting 
                ? 'Requesting permissions automatically...' 
                : 'Location and camera access are needed for attendance verification.'
              }
            </p>
            {isRequesting && (
              <div className="bg-white/50 rounded p-2 mb-2">
                <div className="flex items-center gap-2 text-blue-700 text-xs">
                  <RefreshCw className="w-3 h-3 animate-spin" />
                  <span>Please allow access when prompted by your browser</span>
                </div>
              </div>
            )}
            <Button
              onClick={requestPermissions}
              disabled={isRequesting}
              className="mt-2 bg-blue-600 hover:bg-blue-700 text-white"
              size="sm"
            >
              {isRequesting ? (
                <>
                  <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
                  Requesting...
                </>
              ) : (
                'Grant Permissions'
              )}
            </Button>
          </div>
        )}

        {/* Permission Denied */}
        {hasAnyDenied && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <div className="flex items-center gap-2 text-red-800">
              <XCircle className="w-4 h-4" />
              <span className="text-sm font-medium">Permissions Denied</span>
            </div>
            <p className="text-xs text-red-700 mt-1 mb-2">
              Some permissions were denied. To enable them:
            </p>
            <div className="text-xs text-red-700 space-y-1 mb-3">
              <p>1. Click the lock icon 🔒 in your browser's address bar</p>
              <p>2. Set Location and Camera to "Allow"</p>
              <p>3. Refresh this page</p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => window.location.reload()}
                variant="outline"
                size="sm"
                className="text-red-700 border-red-300"
              >
                <RefreshCw className="w-3 h-3 mr-1" />
                Refresh Page
              </Button>
              {showManualOption && onManualModeEnabled && (
                <Button
                  onClick={onManualModeEnabled}
                  size="sm"
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                >
                  <Smartphone className="w-3 h-3 mr-1" />
                  Manual Mode
                </Button>
              )}
            </div>
          </div>
        )}

        {/* Browser Instructions */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
          <div className="flex items-center gap-2 text-gray-700 mb-2">
            <Settings className="w-4 h-4" />
            <span className="text-sm font-medium">Why these permissions?</span>
          </div>
          <div className="text-xs text-gray-600 space-y-1 mb-3">
            <p><strong>Location:</strong> Captures GPS coordinates (longitude/latitude) to verify your workplace location</p>
            <p><strong>Camera:</strong> Takes a photo with location overlay for attendance proof</p>
          </div>
          {onShowGuide && (
            <Button
              onClick={onShowGuide}
              variant="outline"
              size="sm"
              className="w-full text-xs"
            >
              📖 View Detailed Setup Guide
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}