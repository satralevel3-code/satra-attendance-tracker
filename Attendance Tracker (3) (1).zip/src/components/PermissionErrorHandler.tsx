import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Alert, AlertDescription } from "./ui/alert";
import { 
  AlertTriangle, 
  Camera, 
  MapPin, 
  RefreshCw, 
  Settings,
  CheckCircle,
  XCircle
} from "lucide-react";
import { toast } from "sonner";

interface PermissionErrorHandlerProps {
  onRetry: () => void;
  onContinueWithoutPermissions: () => void;
  errorType: 'location' | 'camera' | 'both';
  errorMessage: string;
}

export function PermissionErrorHandler({ 
  onRetry, 
  onContinueWithoutPermissions, 
  errorType, 
  errorMessage 
}: PermissionErrorHandlerProps) {
  const [permissionStatus, setPermissionStatus] = useState({
    location: 'unknown',
    camera: 'unknown'
  });

  useEffect(() => {
    checkCurrentPermissions();
  }, []);

  const checkCurrentPermissions = async () => {
    try {
      if ('permissions' in navigator) {
        // Check location permission
        try {
          const locationPerm = await navigator.permissions.query({ name: 'geolocation' });
          setPermissionStatus(prev => ({ ...prev, location: locationPerm.state }));
        } catch (error) {
          console.log('Location permission check failed:', error);
        }

        // Check camera permission
        try {
          const cameraPerm = await navigator.permissions.query({ name: 'camera' as PermissionName });
          setPermissionStatus(prev => ({ ...prev, camera: cameraPerm.state }));
        } catch (error) {
          console.log('Camera permission check failed:', error);
        }
      }
    } catch (error) {
      console.log('Permission check failed:', error);
    }
  };

  const getErrorIcon = () => {
    switch (errorType) {
      case 'location':
        return <MapPin className="w-8 h-8 text-blue-600" />;
      case 'camera':
        return <Camera className="w-8 h-8 text-green-600" />;
      case 'both':
        return <AlertTriangle className="w-8 h-8 text-amber-600" />;
      default:
        return <AlertTriangle className="w-8 h-8 text-red-600" />;
    }
  };

  const getErrorTitle = () => {
    switch (errorType) {
      case 'location':
        return 'Location Access Issue';
      case 'camera':
        return 'Camera Access Issue';
      case 'both':
        return 'Permission Access Issues';
      default:
        return 'Permission Error';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'granted':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'denied':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-amber-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            {getErrorIcon()}
          </div>
          <h1 className="text-2xl font-semibold text-primary mb-2">{getErrorTitle()}</h1>
          <p className="text-muted-foreground">
            We need to resolve permission issues to continue
          </p>
        </div>

        {/* Error Details */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">What Happened?</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="border-amber-200 bg-amber-50">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800">
                {errorMessage}
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Current Permission Status */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Current Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {(errorType === 'location' || errorType === 'both') && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  <span>Location Access</span>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(permissionStatus.location)}
                  <span className="text-sm capitalize">{permissionStatus.location}</span>
                </div>
              </div>
            )}

            {(errorType === 'camera' || errorType === 'both') && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Camera className="w-5 h-5 text-green-600" />
                  <span>Camera Access</span>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(permissionStatus.camera)}
                  <span className="text-sm capitalize">{permissionStatus.camera}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Solutions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">How to Fix This</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="border rounded-lg p-3">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Browser Settings
                </h4>
                <ol className="text-sm space-y-1 ml-4 list-decimal">
                  <li>Click the 🔒 lock icon in your address bar</li>
                  <li>Set permissions to "Allow" for this site</li>
                  <li>Reload the page if needed</li>
                </ol>
              </div>

              {errorType === 'location' && (
                <div className="border rounded-lg p-3">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Location Settings
                  </h4>
                  <ul className="text-sm space-y-1 ml-4 list-disc">
                    <li>Make sure GPS is enabled on your device</li>
                    <li>Check if location services are running</li>
                    <li>Try moving to a location with better GPS signal</li>
                  </ul>
                </div>
              )}

              {errorType === 'camera' && (
                <div className="border rounded-lg p-3">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <Camera className="w-4 h-4" />
                    Camera Settings
                  </h4>
                  <ul className="text-sm space-y-1 ml-4 list-disc">
                    <li>Close other apps using the camera</li>
                    <li>Check if camera is working in other apps</li>
                    <li>Restart your browser if needed</li>
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button 
            onClick={() => {
              checkCurrentPermissions();
              onRetry();
            }}
            className="w-full"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>

          <Button 
            onClick={onContinueWithoutPermissions}
            variant="outline"
            className="w-full"
          >
            Continue Without {errorType === 'location' ? 'Location' : errorType === 'camera' ? 'Camera' : 'Permissions'}
          </Button>
        </div>

        {/* Warning */}
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Note:</strong> You can still mark attendance without these permissions, but the record will be flagged for manual verification.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}