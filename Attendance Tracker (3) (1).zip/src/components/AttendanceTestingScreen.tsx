import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Camera, MapPin, Download, CheckCircle, XCircle } from 'lucide-react';
import { locationService, type LocationResult } from '../services/LocationService';
import { toast } from 'sonner';

export function AttendanceTestingScreen() {
  const [locationData, setLocationData] = useState<LocationResult | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [testResults, setTestResults] = useState<{
    location: boolean | null;
    camera: boolean | null;
    csvExport: boolean | null;
  }>({ location: null, camera: null, csvExport: null });

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const testLocation = async () => {
    setIsGettingLocation(true);
    try {
      const result = await locationService.getCurrentLocation();
      setLocationData(result);
      setTestResults(prev => ({ ...prev, location: true }));
      toast.success('Location test passed!');
    } catch (error) {
      setTestResults(prev => ({ ...prev, location: false }));
      toast.error('Location test failed: ' + (error as Error).message);
    } finally {
      setIsGettingLocation(false);
    }
  };

  const testCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
        };
      }
      setTestResults(prev => ({ ...prev, camera: true }));
      toast.success('Camera test passed!');
    } catch (error) {
      setTestResults(prev => ({ ...prev, camera: false }));
      toast.error('Camera test failed: ' + (error as Error).message);
    }
  };

  const captureTestPhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    if (!context) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);

    canvas.toBlob((blob) => {
      if (blob) {
        const photoUrl = URL.createObjectURL(blob);
        setCapturedPhoto(photoUrl);
        toast.success('Photo captured!');
      }
    }, 'image/jpeg', 0.9);
  };

  const testCSVExport = () => {
    try {
      const testData = {
        employeeId: 'TEST001',
        name: 'Test User',
        date: new Date().toISOString().split('T')[0],
        checkInTime: new Date().toISOString(),
        status: 'present' as const,
        location: locationData ? {
          latitude: locationData.location.latitude,
          longitude: locationData.location.longitude,
          accuracy: locationData.location.accuracy,
          address: locationData.address
        } : undefined,
        photoUrl: capturedPhoto || undefined,
        notes: 'Test attendance',
        workLocation: 'Test Office',
        reportingManager: 'Test Manager'
      };

      const csvHeaders = [
        'Employee ID', 'Name', 'Date', 'Check In Time', 'Status', 'Task',
        'Workplace', 'Latitude', 'Longitude', 'Accuracy', 'Address', 'Photo Status'
      ];

      const csvRow = [
        testData.employeeId,
        testData.name,
        testData.date,
        testData.checkInTime,
        testData.status,
        testData.notes || 'N/A',
        testData.workLocation || 'N/A',
        testData.location?.latitude || 'N/A',
        testData.location?.longitude || 'N/A',
        testData.location?.accuracy || 'N/A',
        testData.location?.address || 'N/A',
        testData.photoUrl ? 'Photo Captured' : 'No Photo'
      ];

      const csvContent = [
        csvHeaders.join(','),
        csvRow.map(field => `"${String(field).replace(/"/g, '""')}"`).join(',')
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', 'test_attendance_export.csv');
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setTestResults(prev => ({ ...prev, csvExport: true }));
      toast.success('CSV export test passed!');
    } catch (error) {
      setTestResults(prev => ({ ...prev, csvExport: false }));
      toast.error('CSV export test failed!');
    }
  };

  const getTestIcon = (result: boolean | null) => {
    if (result === true) return <CheckCircle className="w-5 h-5 text-green-600" />;
    if (result === false) return <XCircle className="w-5 h-5 text-red-600" />;
    return <div className="w-5 h-5 border-2 border-gray-300 rounded-full" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Attendance System Testing</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Test Results Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                {getTestIcon(testResults.location)}
                <p className="text-sm mt-1">Location</p>
              </div>
              <div className="text-center">
                {getTestIcon(testResults.camera)}
                <p className="text-sm mt-1">Camera</p>
              </div>
              <div className="text-center">
                {getTestIcon(testResults.csvExport)}
                <p className="text-sm mt-1">CSV Export</p>
              </div>
            </div>

            {/* Location Test */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium">1. Location Test</h3>
              <Button 
                onClick={testLocation} 
                disabled={isGettingLocation}
                className="w-full"
              >
                <MapPin className="w-4 h-4 mr-2" />
                {isGettingLocation ? 'Getting Location...' : 'Test Location'}
              </Button>
              {locationData && (
                <div className="bg-green-50 border border-green-200 rounded p-3">
                  <p className="text-sm text-green-800">
                    <strong>Location:</strong> {locationData.location.latitude.toFixed(6)}, {locationData.location.longitude.toFixed(6)}
                  </p>
                  <p className="text-sm text-green-800">
                    <strong>Accuracy:</strong> ±{locationData.location.accuracy.toFixed(0)}m ({locationData.accuracy})
                  </p>
                  <p className="text-sm text-green-800">
                    <strong>Address:</strong> {locationData.address}
                  </p>
                </div>
              )}
            </div>

            {/* Camera Test */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium">2. Camera Test</h3>
              <Button onClick={testCamera} className="w-full">
                <Camera className="w-4 h-4 mr-2" />
                Test Camera
              </Button>
              
              {cameraStream && (
                <div className="space-y-3">
                  <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <Button onClick={captureTestPhoto} className="w-full">
                    Capture Test Photo
                  </Button>
                </div>
              )}

              {capturedPhoto && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Captured Photo:</p>
                  <img 
                    src={capturedPhoto} 
                    alt="Test capture" 
                    className="w-full max-w-sm rounded-lg"
                  />
                </div>
              )}
            </div>

            {/* CSV Export Test */}
            <div className="space-y-3">
              <h3 className="text-lg font-medium">3. CSV Export Test</h3>
              <Button onClick={testCSVExport} className="w-full">
                <Download className="w-4 h-4 mr-2" />
                Test CSV Export
              </Button>
            </div>

            {/* Overall Status */}
            <div className="pt-4 border-t">
              <Badge 
                variant={
                  Object.values(testResults).every(r => r === true) ? 'default' :
                  Object.values(testResults).some(r => r === false) ? 'destructive' : 'secondary'
                }
                className="w-full justify-center py-2"
              >
                {Object.values(testResults).every(r => r === true) ? 'All Tests Passed' :
                 Object.values(testResults).some(r => r === false) ? 'Some Tests Failed' : 'Tests Pending'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Hidden canvas for photo processing */}
        <canvas ref={canvasRef} style={{ display: 'none' }} />
      </div>
    </div>
  );
}