import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Camera, 
  MapPin, 
  Clock, 
  CheckCircle, 
  LogOut,
  Smartphone,
  Wifi,
  WifiOff
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  address: string;
}

const mockLocations = [
  { id: '1', name: 'Ahmedabad Site A', address: 'GIDC, Vatva, Ahmedabad' },
  { id: '2', name: 'Surat Site B', address: 'Hazira Industrial Area, Surat' },
  { id: '3', name: 'Vadodara Site C', address: 'GIDC, Vadodara' },
  { id: '4', name: 'Rajkot Site D', address: 'Metoda GIDC, Rajkot' }
];

export function CheckInOut() {
  const [currentStep, setCurrentStep] = useState<'select' | 'capture' | 'confirm'>('select');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [workerName, setWorkerName] = useState('');
  const [workerId, setWorkerId] = useState('');
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const [isOnline, setIsOnline] = useState(true);

  // Mock current location
  const getCurrentLocation = () => {
    // Simulate getting GPS location
    setCurrentLocation({
      latitude: 23.0225,
      longitude: 72.5714,
      accuracy: 5,
      address: "GIDC, Vatva, Ahmedabad, Gujarat 382445"
    });
  };

  const capturePhoto = () => {
    // Simulate photo capture
    setCapturedPhoto('https://images.unsplash.com/photo-1615892968147-cafd51492031?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjB3b3JrZXIlMjBpbmRpYXxlbnwxfHx8fDE3NTg3MDA1Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral');
    setCurrentStep('confirm');
  };

  const submitAttendance = () => {
    // Here you would submit to backend
    alert('Attendance marked successfully!');
    // Reset form
    setCurrentStep('select');
    setSelectedLocation('');
    setWorkerName('');
    setWorkerId('');
    setCapturedPhoto(null);
    setCurrentLocation(null);
  };

  if (currentStep === 'select') {
    return (
      <div className="max-w-md mx-auto p-6 space-y-6">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Clock className="w-6 h-6" />
              Mark Attendance
            </CardTitle>
            <div className="flex items-center justify-center gap-4 mt-2">
              <div className="flex items-center gap-1">
                {isOnline ? (
                  <Wifi className="w-4 h-4 text-green-600" />
                ) : (
                  <WifiOff className="w-4 h-4 text-red-600" />
                )}
                <span className="text-sm">{isOnline ? 'Online' : 'Offline'}</span>
              </div>
              <div className="flex items-center gap-1">
                <Smartphone className="w-4 h-4 text-blue-600" />
                <span className="text-sm">GPS Ready</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="workerId">Worker ID</Label>
              <Input
                id="workerId"
                placeholder="Enter your worker ID"
                value={workerId}
                onChange={(e) => setWorkerId(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="workerName">Worker Name</Label>
              <Input
                id="workerName"
                placeholder="Enter your name"
                value={workerName}
                onChange={(e) => setWorkerName(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Work Site</Label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your work site" />
                </SelectTrigger>
                <SelectContent>
                  {mockLocations.map((location) => (
                    <SelectItem key={location.id} value={location.id}>
                      <div>
                        <div className="font-medium">{location.name}</div>
                        <div className="text-sm text-muted-foreground">{location.address}</div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="pt-4">
              <Button 
                className="w-full h-12" 
                onClick={() => {
                  getCurrentLocation();
                  setCurrentStep('capture');
                }}
                disabled={!workerId || !workerName || !selectedLocation}
              >
                <Camera className="w-5 h-5 mr-2" />
                Continue to Photo Capture
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" className="h-10">
                <CheckCircle className="w-4 h-4 mr-2" />
                Check In
              </Button>
              <Button variant="outline" className="h-10">
                <LogOut className="w-4 h-4 mr-2" />
                Check Out
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Current Time */}
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-3xl font-bold">
                {new Date().toLocaleTimeString('en-IN', { 
                  timeZone: 'Asia/Kolkata',
                  hour12: true 
                })}
              </div>
              <div className="text-sm text-muted-foreground">
                {new Date().toLocaleDateString('en-IN', { 
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (currentStep === 'capture') {
    return (
      <div className="max-w-md mx-auto p-6 space-y-6">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Camera className="w-6 h-6" />
              Capture Photo
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Take a photo at your workplace for verification
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Camera Preview */}
            <div className="aspect-[4/3] bg-gray-900 rounded-lg flex items-center justify-center">
              <div className="text-white text-center">
                <Camera className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm opacity-75">Camera Preview</p>
              </div>
            </div>

            <Button onClick={capturePhoto} className="w-full h-12">
              <Camera className="w-5 h-5 mr-2" />
              Capture Photo
            </Button>

            <Button 
              variant="outline" 
              onClick={() => setCurrentStep('select')}
              className="w-full"
            >
              Back to Details
            </Button>
          </CardContent>
        </Card>

        {/* Location Info */}
        {currentLocation && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4" />
                Current Location
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-sm">
                  <span className="font-medium">Coordinates:</span> {currentLocation.latitude.toFixed(6)}, {currentLocation.longitude.toFixed(6)}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Accuracy:</span> ±{currentLocation.accuracy}m
                </div>
                <div className="text-sm">
                  <span className="font-medium">Address:</span> {currentLocation.address}
                </div>
                <Badge variant="outline" className="bg-green-50 text-green-700">
                  Location Verified
                </Badge>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  if (currentStep === 'confirm') {
    return (
      <div className="max-w-md mx-auto p-6 space-y-6">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <CheckCircle className="w-6 h-6 text-green-600" />
              Confirm Attendance
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Please review and confirm your details
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Captured Photo */}
            {capturedPhoto && (
              <div className="space-y-2">
                <Label>Captured Photo</Label>
                <div className="aspect-[4/3] rounded-lg overflow-hidden">
                  <ImageWithFallback 
                    src={capturedPhoto}
                    alt="Captured attendance photo"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}

            {/* Details Summary */}
            <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
              <div className="flex justify-between">
                <span className="font-medium">Worker ID:</span>
                <span>{workerId}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Name:</span>
                <span>{workerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Location:</span>
                <span>{mockLocations.find(l => l.id === selectedLocation)?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Time:</span>
                <span>
                  {new Date().toLocaleTimeString('en-IN', { 
                    timeZone: 'Asia/Kolkata',
                    hour12: true 
                  })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Date:</span>
                <span>
                  {new Date().toLocaleDateString('en-IN')}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                onClick={() => setCurrentStep('capture')}
              >
                Retake Photo
              </Button>
              <Button onClick={submitAttendance} className="bg-green-600 hover:bg-green-700">
                <CheckCircle className="w-4 h-4 mr-2" />
                Confirm
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}