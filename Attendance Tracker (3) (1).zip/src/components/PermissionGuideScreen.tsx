import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Camera, 
  MapPin, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Smartphone,
  Settings,
  Chrome,
  Globe
} from 'lucide-react';
import { toast } from 'sonner';

interface PermissionGuideProps {
  onPermissionsGranted: () => void;
  onSkip: () => void;
}

export function PermissionGuideScreen({ onPermissionsGranted, onSkip }: PermissionGuideProps) {
  const [locationPermission, setLocationPermission] = useState<'granted' | 'denied' | 'prompt' | 'unknown'>('unknown');
  const [cameraPermission, setCameraPermission] = useState<'granted' | 'denied' | 'prompt' | 'unknown'>('unknown');
  const [isChecking, setIsChecking] = useState(false);

  useEffect(() => {
    checkPermissions();
  }, []);

  const checkPermissions = async () => {
    try {
      // Check location permission
      if ('permissions' in navigator) {
        try {
          const locationPerm = await navigator.permissions.query({ name: 'geolocation' });
          setLocationPermission(locationPerm.state);
          console.log('Location permission:', locationPerm.state);
        } catch (error) {
          console.log('Location permission check error:', error);
          setLocationPermission('unknown');
        }
      }

      // Check camera permission
      if ('permissions' in navigator) {
        try {
          const cameraPerm = await navigator.permissions.query({ name: 'camera' as PermissionName });
          setCameraPermission(cameraPerm.state);
          console.log('Camera permission:', cameraPerm.state);
        } catch (error) {
          console.log('Camera permission check error:', error);
          setCameraPermission('unknown');
        }
      }
    } catch (error) {
      console.log('Permission check failed:', error);
    }
  };

  const requestLocationPermission = async () => {
    setIsChecking(true);
    try {
      await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          () => {
            setLocationPermission('granted');
            toast.success('Location permission granted!');
            resolve(true);
          },
          (error) => {
            setLocationPermission('denied');
            if (error.code === error.PERMISSION_DENIED) {
              toast.error('Location permission denied. Please enable location access in your browser settings.');
            } else if (error.code === error.POSITION_UNAVAILABLE) {
              toast.error('Location unavailable. Please check your device GPS settings.');
            } else {
              toast.error('Location request timed out. Please try again.');
            }
            reject(error);
          },
          { 
            enableHighAccuracy: true,
            timeout: 15000,
            maximumAge: 60000
          }
        );
      });
    } catch (error) {
      console.error('Location permission error:', error);
    } finally {
      setIsChecking(false);
    }
  };

  const requestCameraPermission = async () => {
    setIsChecking(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      stream.getTracks().forEach(track => track.stop());
      setCameraPermission('granted');
      toast.success('Camera permission granted!');
    } catch (error) {
      setCameraPermission('denied');
      const errorName = (error as any)?.name || '';
      
      if (errorName === 'NotAllowedError' || errorName === 'PermissionDeniedError') {
        toast.error('Camera permission denied. Please allow camera access in your browser settings.');
      } else if (errorName === 'NotFoundError' || errorName === 'DevicesNotFoundError') {
        toast.error('No camera found. Please check your device camera.');
      } else if (errorName === 'NotReadableError' || errorName === 'TrackStartError') {
        toast.error('Camera is being used by another app. Please close other camera apps and try again.');
      } else {
        toast.error('Camera access failed. Please check your camera permissions.');
      }
      console.error('Camera permission error:', error);
    } finally {
      setIsChecking(false);
    }
  };

  const allPermissionsGranted = locationPermission === 'granted' && cameraPermission === 'granted';
  const somePermissionsGranted = locationPermission === 'granted' || cameraPermission === 'granted';

  const getPermissionIcon = (status: string) => {
    switch (status) {
      case 'granted':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'denied':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-amber-600" />;
    }
  };

  const getPermissionColor = (status: string) => {
    switch (status) {
      case 'granted':
        return 'bg-green-100 text-green-800';
      case 'denied':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-amber-100 text-amber-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <Settings className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-semibold text-primary mb-2">Enable Permissions</h1>
          <p className="text-muted-foreground">
            Allow camera and location access for attendance marking
          </p>
        </div>

        {/* Permission Status */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Permission Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Location Permission */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium">Location Access</p>
                  <p className="text-sm text-muted-foreground">Required for GPS tracking</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getPermissionIcon(locationPermission)}
                <Badge variant="secondary" className={getPermissionColor(locationPermission)}>
                  {locationPermission}
                </Badge>
              </div>
            </div>

            {/* Camera Permission */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Camera className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">Camera Access</p>
                  <p className="text-sm text-muted-foreground">Required for workplace photos</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getPermissionIcon(cameraPermission)}
                <Badge variant="secondary" className={getPermissionColor(cameraPermission)}>
                  {cameraPermission}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Permission Request Buttons */}
        {!allPermissionsGranted && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Grant Permissions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {locationPermission !== 'granted' && (
                <Button 
                  onClick={requestLocationPermission}
                  disabled={isChecking}
                  className="w-full"
                  variant="outline"
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  {isChecking ? 'Requesting...' : 'Enable Location'}
                </Button>
              )}

              {cameraPermission !== 'granted' && (
                <Button 
                  onClick={requestCameraPermission}
                  disabled={isChecking}
                  className="w-full"
                  variant="outline"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  {isChecking ? 'Requesting...' : 'Enable Camera'}
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* Manual Instructions */}
        {(locationPermission === 'denied' || cameraPermission === 'denied') && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                Manual Setup Instructions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  If permissions were denied, you'll need to enable them manually in your browser settings.
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <div className="border rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Chrome className="w-4 h-4" />
                    <p className="font-medium">Chrome/Edge</p>
                  </div>
                  <ol className="text-sm space-y-1 ml-4 list-decimal">
                    <li>Click the 🔒 lock icon in the address bar</li>
                    <li>Set Location and Camera to "Allow"</li>
                    <li>Reload the page</li>
                  </ol>
                </div>

                <div className="border rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Globe className="w-4 h-4" />
                    <p className="font-medium">Safari/Firefox</p>
                  </div>
                  <ol className="text-sm space-y-1 ml-4 list-decimal">
                    <li>Go to browser Settings</li>
                    <li>Find Privacy & Security</li>
                    <li>Allow Camera and Location for this site</li>
                  </ol>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="space-y-3">
          {allPermissionsGranted && (
            <Button 
              onClick={onPermissionsGranted}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Continue to Attendance
            </Button>
          )}

          <Button 
            onClick={onSkip}
            variant="outline"
            className="w-full"
          >
            Continue Without Permissions
          </Button>

          <Button 
            onClick={checkPermissions}
            variant="ghost"
            className="w-full"
          >
            Check Permissions Again
          </Button>
        </div>

        {/* Warning for skipping */}
        {!allPermissionsGranted && (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Note:</strong> If you continue without permissions, you can still mark attendance but it will be flagged for manual verification. Photo and location capture may not work properly.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
}