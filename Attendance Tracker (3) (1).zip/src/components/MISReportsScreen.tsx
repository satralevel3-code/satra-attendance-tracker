import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { PhotoViewerDialog } from "./PhotoViewerDialog";
import { 
  FileText, 
  Download, 
  Calendar as CalendarIcon, 
  Filter,
  MapPin,
  Clock,
  User,
  Building2,
  ExternalLink,
  Search,
  ArrowLeft,
  Camera,
  Eye
} from "lucide-react";
// Removed attendanceAPI import - using local storage only

const DCCB_OPTIONS = [
  'AHMEDABAD', 'BANASKANTHA', 'BARODA', 'MAHESANA', 'SABARKANTHA',
  'BHARUCH', 'KHEDA', 'PANCHMAHAL', 'SURENDRANAGAR', 'JAMNAGAR',
  'JUNAGADH', 'KODINAR', 'KUTCH', 'VALSAD', 'AMRELI', 'BHAVNAGAR',
  'RAJKOT', 'SURAT'
];

interface MISReportsScreenProps {
  onBack: () => void;
}

export function MISReportsScreen({ onBack }: MISReportsScreenProps) {
  const [reportType, setReportType] = useState('daily');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedDCCB, setSelectedDCCB] = useState('all');
  const [searchEmployeeId, setSearchEmployeeId] = useState('');
  const [reportData, setReportData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<any>(null);
  const [isPhotoDialogOpen, setIsPhotoDialogOpen] = useState(false);

  const handleGenerateReport = async () => {
    setIsLoading(true);
    
    try {
      const dateStr = selectedDate.toISOString().split('T')[0];
      const dccb = selectedDCCB === 'all' ? undefined : selectedDCCB;
      
      // Load attendance records from local storage
      const allRecords = JSON.parse(localStorage.getItem('attendanceRecords') || '[]');
      let filteredData = allRecords.filter((record: any) => record.date === dateStr);
      
      // Filter by DCCB if specified
      if (dccb) {
        const employees = JSON.parse(localStorage.getItem('employees') || '[]');
        const dccbEmployees = employees.filter((emp: any) => emp.dccb === dccb);
        const dccbEmployeeIds = dccbEmployees.map((emp: any) => emp.employeeId);
        filteredData = filteredData.filter((record: any) => dccbEmployeeIds.includes(record.employeeId));
      }
      
      if (filteredData.length >= 0) {
        
        // Filter by Employee ID if provided
        if (searchEmployeeId) {
          filteredData = filteredData.filter(record => 
            record.employeeId.toLowerCase().includes(searchEmployeeId.toLowerCase())
          );
        }
        
        setReportData(filteredData);
      }
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportToCSV = () => {
    if (reportData.length === 0) return;
    
    const headers = [
      'Date', 'Employee ID', 'Full Name', 'DCCB', 'Status', 'Task', 
      'Workplace', 'Timestamp', 'Longitude', 'Latitude', 'Address', 'Location Accuracy (m)', 'Reporting To'
    ];
    
    const csvData = reportData.map(record => {
      // Extract location data properly
      let longitude = '';
      let latitude = '';
      let address = '';
      let accuracy = '';
      
      if (record.location) {
        longitude = record.location.longitude ? record.location.longitude.toString() : '';
        latitude = record.location.latitude ? record.location.latitude.toString() : '';
        address = record.location.address ? record.location.address : '';
        accuracy = record.location.accuracy ? Math.round(record.location.accuracy).toString() : '';
      }
      
      return [
        record.date,
        record.employeeId,
        record.name || record.fullName || '',
        record.dccb || '',
        record.status,
        record.task || record.notes?.split(':')[1]?.trim() || '',
        record.workLocation || record.workplace || '',
        record.timestamp || record.checkInTime 
          ? new Date(record.timestamp || record.checkInTime).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })
          : '',
        longitude,
        latitude,
        address,
        accuracy,
        record.reportingManager || record.reportingTo || ''
      ];
    });
    
    // Add BOM for proper UTF-8 encoding
    const BOM = '\uFEFF';
    const csvContent = BOM + [headers, ...csvData]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `attendance_records_${selectedDate.toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'present':
        return <Badge className="bg-green-100 text-green-800">Present</Badge>;
      case 'half day':
        return <Badge className="bg-orange-100 text-orange-800">Half Day</Badge>;
      case 'absent':
        return <Badge className="bg-red-100 text-red-800">Absent</Badge>;
      case 'leave':
        return <Badge className="bg-blue-100 text-blue-800">Leave</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  useEffect(() => {
    handleGenerateReport();
  }, []);

  const handleViewPhoto = (record: any) => {
    setSelectedRecord(record);
    setIsPhotoDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onBack} className="p-2">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-primary">MIS Reports</h1>
                <p className="text-sm text-muted-foreground">Daily Attendance Reports & Analytics</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Filters Section */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Report Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Report Type</label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger className="bg-input-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily Report</SelectItem>
                    <SelectItem value="weekly">Weekly Summary</SelectItem>
                    <SelectItem value="monthly">Monthly Report</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Date</label>
                <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="bg-input-background justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate.toLocaleDateString('en-IN')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => {
                        if (date) {
                          setSelectedDate(date);
                          setIsCalendarOpen(false);
                        }
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">DCCB</label>
                <Select value={selectedDCCB} onValueChange={setSelectedDCCB}>
                  <SelectTrigger className="bg-input-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All DCCBs</SelectItem>
                    {DCCB_OPTIONS.map((dccb) => (
                      <SelectItem key={dccb} value={dccb}>
                        {dccb}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Employee ID</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search Employee ID..."
                    value={searchEmployeeId}
                    onChange={(e) => setSearchEmployeeId(e.target.value.toUpperCase())}
                    className="pl-10 bg-input-background"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Actions</label>
                <div className="flex gap-2">
                  <Button
                    onClick={handleGenerateReport}
                    disabled={isLoading}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {isLoading ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <FileText className="w-4 h-4" />
                    )}
                  </Button>
                  <Button
                    onClick={handleExportToCSV}
                    disabled={reportData.length === 0}
                    variant="outline"
                    className="border-accent text-accent hover:bg-accent hover:text-white"
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Report Results */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                Attendance Report - {selectedDate.toLocaleDateString('en-IN')}
              </div>
              <Badge variant="outline">
                {reportData.length} Records
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                <span className="ml-3 text-muted-foreground">Generating report...</span>
              </div>
            ) : reportData.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Data Found</h3>
                <p className="text-muted-foreground">No attendance records found for the selected criteria.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="text-left p-3 font-medium">Employee ID</th>
                      <th className="text-left p-3 font-medium">Full Name</th>
                      <th className="text-left p-3 font-medium">DCCB</th>
                      <th className="text-left p-3 font-medium">Status</th>
                      <th className="text-left p-3 font-medium">Task</th>
                      <th className="text-left p-3 font-medium">Workplace</th>
                      <th className="text-left p-3 font-medium">Time</th>
                      <th className="text-left p-3 font-medium">Photo</th>
                      <th className="text-left p-3 font-medium">Location</th>
                      <th className="text-left p-3 font-medium">Reporting To</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.map((record, index) => (
                      <tr key={index} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-mono text-sm">{record.employeeId}</td>
                        <td className="p-3">{record.fullName || record.name || 'N/A'}</td>
                        <td className="p-3">
                          <Badge variant="outline" className="text-xs">
                            {record.dccb || 'N/A'}
                          </Badge>
                        </td>
                        <td className="p-3">{getStatusBadge(record.status)}</td>
                        <td className="p-3 text-sm">{record.task || '-'}</td>
                        <td className="p-3 text-sm">{record.workLocation || record.workplace || '-'}</td>
                        <td className="p-3 text-sm">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-muted-foreground" />
                            {record.timestamp || record.checkInTime ? new Date(record.timestamp || record.checkInTime).toLocaleTimeString('en-IN', { 
                              timeZone: 'Asia/Kolkata',
                              hour12: true, 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            }) : '-'}
                          </div>
                        </td>
                        <td className="p-3">
                          {record.photoUrl ? (
                            <div className="flex items-center gap-2">
                              <div className="relative group">
                                <img 
                                  src={record.photoUrl} 
                                  alt="Thumbnail" 
                                  className="w-10 h-10 rounded object-cover border cursor-pointer hover:scale-110 transition-transform"
                                  onClick={() => handleViewPhoto(record)}
                                  onError={(e) => {
                                    const target = e.target as HTMLImageElement;
                                    target.style.display = 'none';
                                  }}
                                />
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto p-1 text-primary hover:text-primary/80"
                                onClick={() => handleViewPhoto(record)}
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-sm flex items-center gap-1">
                              <Camera className="w-3 h-3" />
                              No Photo
                            </span>
                          )}
                        </td>
                        <td className="p-3">
                          {record.location ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-auto p-1 text-blue-600 hover:text-blue-800"
                              onClick={() => window.open(`https://www.google.com/maps?q=${record.location.latitude},${record.location.longitude}`, '_blank')}
                            >
                              <MapPin className="w-3 h-3 mr-1" />
                              <ExternalLink className="w-3 h-3" />
                            </Button>
                          ) : (
                            <span className="text-muted-foreground text-sm">-</span>
                          )}
                        </td>
                        <td className="p-3 text-sm">{record.reportingManager || record.reportingTo || 'N/A'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Summary Stats */}
        {reportData.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { label: 'Total Records', value: reportData.length, color: 'blue' },
              { 
                label: 'Present', 
                value: reportData.filter(r => r.status?.toLowerCase() === 'present').length, 
                color: 'green' 
              },
              { 
                label: 'Absent', 
                value: reportData.filter(r => r.status?.toLowerCase() === 'absent').length, 
                color: 'red' 
              },
              { 
                label: 'Half Day', 
                value: reportData.filter(r => r.status?.toLowerCase() === 'half day').length, 
                color: 'orange' 
              },
              { 
                label: 'Attendance %', 
                value: Math.round((reportData.filter(r => r.status?.toLowerCase() === 'present').length / reportData.length) * 100) + '%', 
                color: 'purple' 
              }
            ].map((stat, index) => (
              <Card key={index} className="shadow-md">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className={`text-2xl font-bold text-${stat.color}-600`}>
                      {stat.value}
                    </div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Photo Viewer Dialog */}
      <PhotoViewerDialog
        record={selectedRecord}
        isOpen={isPhotoDialogOpen}
        onClose={() => setIsPhotoDialogOpen(false)}
      />
    </div>
  );
}