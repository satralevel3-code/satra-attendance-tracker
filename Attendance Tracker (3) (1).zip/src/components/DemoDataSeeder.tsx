import { useEffect } from 'react';

export function useDemoDataSeeder() {
  useEffect(() => {
    const seedDemoData = () => {
      // Check if demo data already exists
      const existingEmployees = JSON.parse(localStorage.getItem('employees') || '[]');
      const existingRecords = JSON.parse(localStorage.getItem('attendanceRecords') || '[]');
      
      // Seed employees if none exist
      if (existingEmployees.length === 0) {
        const demoEmployees = [
          {
            employeeId: 'ADMIN01',
            name: 'Suresh Patel',
            fullName: 'Suresh Patel',
            designation: 'State Manager',
            department: 'Gujarat State',
            dccb: 'Ahmedabad DCCB',
            reportingManager: 'HEAD OFFICE',
            reportingTo: 'HEAD OFFICE',
            email: 'suresh.patel@satraservices.com',
            contactNumber: '9876543210',
            password: 'admin123',
            userType: 'admin'
          },
          {
            employeeId: 'SAT001',
            name: 'Rajesh Kumar',
            fullName: 'Rajesh Kumar',
            designation: 'Regional Manager',
            department: 'Gujarat North',
            dccb: 'Ahmedabad DCCB',
            reportingManager: 'SURESH PATEL',
            reportingTo: 'SURESH PATEL',
            email: 'rajesh.kumar@satraservices.com',
            contactNumber: '9876543211',
            password: 'test123',
            userType: 'executive'
          },
          {
            employeeId: 'SAT002',
            name: 'Priya Sharma',
            fullName: 'Priya Sharma',
            designation: 'Field Executive',
            department: 'Gujarat South',
            dccb: 'Surat DCCB',
            reportingManager: 'NITIN SINGH',
            reportingTo: 'NITIN SINGH',
            email: 'priya.sharma@satraservices.com',
            contactNumber: '9876543212',
            password: 'test123',
            userType: 'executive'
          },
          {
            employeeId: 'SAT003',
            name: 'Amit Patel',
            fullName: 'Amit Patel',
            designation: 'Data Entry Operator',
            department: 'Gujarat Central',
            dccb: 'Vadodara DCCB',
            reportingManager: 'PARAS PARAMAR',
            reportingTo: 'PARAS PARAMAR',
            email: 'amit.patel@satraservices.com',
            contactNumber: '9876543213',
            password: 'test123',
            userType: 'executive'
          },
          {
            employeeId: 'SAT004',
            name: 'Kavita Desai',
            fullName: 'Kavita Desai',
            designation: 'Field Coordinator',
            department: 'Gujarat East',
            dccb: 'Rajkot DCCB',
            reportingManager: 'AMBALAL',
            reportingTo: 'AMBALAL',
            email: 'kavita.desai@satraservices.com',
            contactNumber: '9876543214',
            password: 'test123',
            userType: 'executive'
          }
        ];
        
        localStorage.setItem('employees', JSON.stringify(demoEmployees));
        console.log('✅ Demo employees seeded');
      }
      
      // Seed attendance records if none exist for today
      const today = new Date().toISOString().split('T')[0];
      const todayRecords = existingRecords.filter((record: any) => record.date === today);
      
      if (todayRecords.length === 0) {
        const currentTime = new Date().toISOString();
        const demoAttendanceRecords = [
          {
            employeeId: 'SAT001',
            name: 'Rajesh Kumar',
            date: today,
            checkInTime: currentTime,
            status: 'present',
            location: {
              latitude: 23.0225,
              longitude: 72.5714,
              accuracy: 15,
              address: 'CG Road, Ahmedabad, Gujarat'
            },
            photoUrl: 'demo-photo-captured',
            notes: 'Task: Client meeting at Ahmedabad office',
            workLocation: 'Ahmedabad DCCB',
            reportingManager: 'SURESH PATEL'
          },
          {
            employeeId: 'SAT002',
            name: 'Priya Sharma',
            date: today,
            checkInTime: currentTime,
            status: 'present',
            location: {
              latitude: 21.1702,
              longitude: 72.8311,
              accuracy: 12,
              address: 'Udhna, Surat, Gujarat'
            },
            photoUrl: 'demo-photo-captured',
            notes: 'Task: Data collection at rural areas',
            workLocation: 'Surat DCCB',
            reportingManager: 'NITIN SINGH'
          },
          {
            employeeId: 'SAT003',
            name: 'Amit Patel',
            date: today,
            checkInTime: currentTime,
            status: 'absent',
            notes: 'Absent: Planned - Medical appointment',
            reportingManager: 'PARAS PARAMAR'
          }
        ];
        
        // Add demo records to existing records
        const updatedRecords = [...existingRecords, ...demoAttendanceRecords];
        localStorage.setItem('attendanceRecords', JSON.stringify(updatedRecords));
        console.log('✅ Demo attendance records seeded for today');
      }
    };
    
    // Seed data after a short delay to ensure localStorage is ready
    const timer = setTimeout(seedDemoData, 100);
    return () => clearTimeout(timer);
  }, []);
}

// Export a simple component that can be used to seed data
export function DemoDataSeeder() {
  useDemoDataSeeder();
  return null;
}