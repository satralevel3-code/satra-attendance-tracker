/**
 * Enhanced Offline Status Indicator
 * Shows connection status and offline queue information
 */

import { useState, useEffect } from 'react';
import { WifiOff, Wifi, Cloud, CloudOff, Loader2, CheckCircle } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { offlineQueue } from '../utils/offlineQueue';

export function EnhancedOfflineIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [queueStats, setQueueStats] = useState(offlineQueue.getStats());
  const [showDetails, setShowDetails] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      console.log('🌐 Connection restored');
    };

    const handleOffline = () => {
      setIsOnline(false);
      console.log('📴 Connection lost');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Update queue stats periodically
    const interval = setInterval(() => {
      setQueueStats(offlineQueue.getStats());
    }, 2000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, []);

  const handleSync = async () => {
    setIsSyncing(true);
    try {
      await offlineQueue.processQueue();
      setQueueStats(offlineQueue.getStats());
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleClearCompleted = () => {
    offlineQueue.clearCompleted();
    setQueueStats(offlineQueue.getStats());
  };

  // Don't show if online and no pending items
  if (isOnline && queueStats.pending === 0 && queueStats.failed === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm">
      <Card className={`shadow-lg ${isOnline ? 'bg-white' : 'bg-yellow-50 border-yellow-200'}`}>
        <div className="p-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              {isOnline ? (
                <Wifi className="w-4 h-4 text-green-600" />
              ) : (
                <WifiOff className="w-4 h-4 text-yellow-600" />
              )}
              <span className={`font-medium ${isOnline ? 'text-green-700' : 'text-yellow-700'}`}>
                {isOnline ? 'Online' : 'Offline'}
              </span>
            </div>
            
            {queueStats.total > 0 && (
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                {showDetails ? 'Hide' : 'Show'} Details
              </button>
            )}
          </div>

          {/* Connection Message */}
          {!isOnline && (
            <p className="text-xs text-yellow-700 mb-2">
              You're offline. Your attendance will be queued and synced when you're back online.
            </p>
          )}

          {/* Queue Stats */}
          {queueStats.total > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                {queueStats.pending > 0 && (
                  <Badge variant="outline" className="text-xs">
                    <Cloud className="w-3 h-3 mr-1" />
                    {queueStats.pending} pending
                  </Badge>
                )}
                {queueStats.processing > 0 && (
                  <Badge variant="outline" className="text-xs bg-blue-50">
                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                    {queueStats.processing} syncing
                  </Badge>
                )}
                {queueStats.completed > 0 && (
                  <Badge variant="outline" className="text-xs bg-green-50">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    {queueStats.completed} synced
                  </Badge>
                )}
                {queueStats.failed > 0 && (
                  <Badge variant="destructive" className="text-xs">
                    <CloudOff className="w-3 h-3 mr-1" />
                    {queueStats.failed} failed
                  </Badge>
                )}
              </div>

              {/* Detailed Queue View */}
              {showDetails && (
                <div className="mt-3 pt-3 border-t space-y-2">
                  <div className="text-xs text-muted-foreground space-y-1">
                    <div className="flex justify-between">
                      <span>Total items:</span>
                      <span className="font-medium">{queueStats.total}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Pending sync:</span>
                      <span className="font-medium text-yellow-600">{queueStats.pending}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Successfully synced:</span>
                      <span className="font-medium text-green-600">{queueStats.completed}</span>
                    </div>
                    {queueStats.failed > 0 && (
                      <div className="flex justify-between">
                        <span>Failed:</span>
                        <span className="font-medium text-red-600">{queueStats.failed}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2 mt-3">
                    {isOnline && queueStats.pending > 0 && (
                      <Button
                        onClick={handleSync}
                        size="sm"
                        className="flex-1"
                        disabled={isSyncing}
                      >
                        {isSyncing ? (
                          <>
                            <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                            Syncing...
                          </>
                        ) : (
                          <>
                            <Cloud className="w-3 h-3 mr-1" />
                            Sync Now
                          </>
                        )}
                      </Button>
                    )}
                    
                    {queueStats.completed > 0 && (
                      <Button
                        onClick={handleClearCompleted}
                        size="sm"
                        variant="outline"
                        className="flex-1"
                      >
                        Clear Completed
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* No Queue Items */}
          {queueStats.total === 0 && isOnline && (
            <p className="text-xs text-green-700">
              All data synced successfully
            </p>
          )}
        </div>
      </Card>
    </div>
  );
}