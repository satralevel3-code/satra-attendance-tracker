import { AlertTriangle, Settings, ExternalLink, XCircle } from "lucide-react";
import { Alert, AlertDescription } from "./ui/alert";
import { Button } from "./ui/button";
import { useEffect, useState } from "react";

interface FallbackModeNoticeProps {
  show: boolean;
}

export function FallbackModeNotice({ show }: FallbackModeNoticeProps) {
  const [has403Error, setHas403Error] = useState(false);

  useEffect(() => {
    // Check if we have a 403 or 401 error stored
    const error403 = localStorage.getItem('google_sheets_403_error');
    const error401 = localStorage.getItem('google_sheets_401_error');
    setHas403Error(error403 === 'true' || error401 === 'true');
  }, []);

  if (!show) return null;

  const handleEnableAPI = () => {
    window.open('https://console.cloud.google.com/apis/library/sheets.googleapis.com', '_blank');
  };

  const handleViewTroubleshooting = () => {
    // This will be handled by the parent component
    window.location.hash = '#troubleshooting';
  };

  if (has403Error) {
    return (
      <Alert className="border-red-200 bg-red-50 rounded-none shadow-none">
        <XCircle className="h-4 w-4 text-red-600" />
        <AlertDescription className="text-red-800">
          <div className="flex items-center justify-between">
            <div>
              <strong>403 Permission Error:</strong> Google Sheets API is not enabled for your project.
              <br />
              <span className="text-sm">
                Quick fix: Enable Google Sheets API for project "satra-attendance-tracker"
              </span>
            </div>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="outline"
                onClick={handleEnableAPI}
                className="text-red-600 border-red-300 hover:bg-red-100"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Enable API
              </Button>
            </div>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Alert className="border-amber-200 bg-amber-50 rounded-none shadow-none">
      <AlertTriangle className="h-4 w-4 text-amber-600" />
      <AlertDescription className="text-amber-800">
        <div className="flex items-center justify-between">
          <div>
            <strong>Authentication Issue:</strong> Google Sheets API configuration needed.
            <br />
            <span className="text-sm">Login with ADMIN01/admin123 and access the Setup Guide for configuration steps.</span>
          </div>
          <Settings className="h-4 w-4 text-amber-600" />
        </div>
      </AlertDescription>
    </Alert>
  );
}