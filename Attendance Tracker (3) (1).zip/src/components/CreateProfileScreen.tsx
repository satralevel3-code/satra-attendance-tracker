import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { ArrowLeft, Building2, MapPin, Phone, Mail, User, CheckCircle } from "lucide-react";
import { attendanceAPI } from "../utils/supabase/client";
import { toast } from "sonner@2.0.3";

// Local storage fallback for when the API is not available
const localStorageService = {
  async createEmployee(employeeData: any) {
    try {
      // Check if employee ID already exists
      const existingEmployees = JSON.parse(localStorage.getItem('employees') || '[]');
      const existingEmployee = existingEmployees.find((emp: any) => emp.employeeId === employeeData.employeeId);
      
      if (existingEmployee) {
        return { success: false, error: 'Employee ID already exists' };
      }

      // Add new employee
      const employee = {
        ...employeeData,
        name: employeeData.name || `${employeeData.firstName} ${employeeData.lastName}`,
        fullName: employeeData.name || `${employeeData.firstName} ${employeeData.lastName}`,
        department: employeeData.department || employeeData.dccb || 'Unknown',
        reportingManager: employeeData.reportingManager || employeeData.reportingTo || 'Unknown',
        phoneNumber: employeeData.phoneNumber || employeeData.contactNumber,
        workLocations: employeeData.workLocations || (employeeData.dccb ? [employeeData.dccb] : ['HEAD_OFFICE']),
        status: employeeData.status || 'active',
        isActive: true,
        createdOn: new Date().toISOString(),
        joinedOn: new Date().toISOString().split('T')[0]
      };

      existingEmployees.push(employee);
      localStorage.setItem('employees', JSON.stringify(existingEmployees));
      
      return { success: true, employeeId: employee.employeeId, employee };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
};

interface CreateProfileScreenProps {
  onBack: () => void;
  onProfileCreated: () => void;
}

const DCCB_OPTIONS = [
  'AHMEDABAD', 'BANASKANTHA', 'BARODA', 'MAHESANA', 'SABARKANTHA',
  'BHARUCH', 'KHEDA', 'PANCHMAHAL', 'SURENDRANAGAR', 'JAMNAGAR',
  'JUNAGADH', 'KODINAR', 'KUTCH', 'VALSAD', 'AMRELI', 'BHAVNAGAR',
  'RAJKOT', 'SURAT'
];

const DESIGNATIONS = ['MT', 'DC', 'HR', 'Manager', 'SPMU', 'Delivery Head'];

const REPORTING_MANAGERS = [
  'NITIN SINGH',
  'PARAS PARAMAR', 
  'AMBALAL',
  'SAURAV PANDEY',
  'JINDAL PATEL'
];

export function CreateProfileScreen({ onBack, onProfileCreated }: CreateProfileScreenProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [userType, setUserType] = useState<'executive' | 'admin'>('executive');
  const [isLoading, setIsLoading] = useState(false);
  
  // Form data
  const [formData, setFormData] = useState({
    employeeId: '',
    firstName: '',
    lastName: '',
    designation: '',
    dccb: '',
    reportingTo: '',
    contactNumber: '',
    alternateContact: '',
    email: '',
    address: '',
    pinNumber: '',
    password: ''
  });

  // Validation functions
  const validateEmployeeId = (id: string) => {
    const regex = /^[A-Z]{3}\d{5}$/;
    return regex.test(id);
  };

  const validateEmail = (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const validatePhone = (phone: string) => {
    const regex = /^\d{10}$/;
    return regex.test(phone);
  };

  const validatePinCode = (pin: string) => {
    const regex = /^\d{6}$/;
    return regex.test(pin);
  };

  const handleInputChange = (field: string, value: string) => {
    if (field === 'firstName' || field === 'lastName' || field === 'reportingTo') {
      value = value.toUpperCase();
    }
    if (field === 'employeeId') {
      value = value.toUpperCase();
    }
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleDesignationChange = (designation: string) => {
    setFormData(prev => ({ ...prev, designation }));
    setUserType(['MT', 'DC'].includes(designation) ? 'executive' : 'admin');
  };

  const isStep1Valid = () => {
    return (
      validateEmployeeId(formData.employeeId) &&
      formData.firstName.length >= 2 &&
      formData.lastName.length >= 2 &&
      formData.designation &&
      formData.contactNumber &&
      validatePhone(formData.contactNumber)
    );
  };

  const isStep2Valid = () => {
    const baseValid = validateEmail(formData.email) && formData.password.length >= 6;
    
    if (userType === 'executive') {
      return (
        baseValid &&
        formData.dccb &&
        formData.reportingTo.length >= 2 &&
        formData.address.length >= 10 &&
        validatePinCode(formData.pinNumber)
      );
    } else {
      return baseValid;
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    
    try {
      const employeeData = {
        employeeId: formData.employeeId,
        firstName: formData.firstName,
        lastName: formData.lastName,
        designation: formData.designation,
        dccb: formData.dccb || null,
        reportingTo: formData.reportingTo || null,
        contactNumber: formData.contactNumber,
        alternateContact: formData.alternateContact || null,
        email: formData.email,
        address: formData.address || null,
        pinNumber: formData.pinNumber || null,
        password: formData.password,
        createdBy: 'self_registration'
      };
      
      let result;
      
      // Check if employee ID already exists in local storage
      const existingEmployees = JSON.parse(localStorage.getItem('employees') || '[]');
      if (existingEmployees.some((emp: any) => emp.employeeId === formData.employeeId)) {
        toast.error('Employee ID already exists');
        setIsLoading(false);
        return;
      }

      // Create employee using local storage only
      result = await localStorageService.createEmployee(employeeData);
      
      if (result.success) {
        toast.success('Profile created successfully!');
        console.log('📝 Profile saved locally.');
      }
      
      if (result.success) {
        if (!result.fallback) {
          toast.success('Profile created successfully!');
        }
        onProfileCreated();
      } else {
        toast.error(result.error || 'Profile creation failed');
        setIsLoading(false);
      }
    } catch (error) {
      console.error('Error creating profile:', error);
      
      // Final fallback attempt
      try {
        const employeeData = {
          employeeId: formData.employeeId,
          firstName: formData.firstName,
          lastName: formData.lastName,
          designation: formData.designation,
          dccb: formData.dccb || null,
          reportingTo: formData.reportingTo || null,
          contactNumber: formData.contactNumber,
          alternateContact: formData.alternateContact || null,
          email: formData.email,
          address: formData.address || null,
          pinNumber: formData.pinNumber || null,
          password: formData.password,
          createdBy: 'self_registration'
        };

        const fallbackResult = await localStorageService.createEmployee(employeeData);
        
        if (fallbackResult.success) {
          toast.success('Profile created successfully! (Offline mode)');
          onProfileCreated();
        } else {
          toast.error(fallbackResult.error || 'Profile creation failed');
          setIsLoading(false);
        }
      } catch (fallbackError) {
        toast.error('Profile creation failed. Please check your connection and try again.');
        setIsLoading(false);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-sm mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="p-2"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Building2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-primary">Create Profile</h1>
                <p className="text-sm text-muted-foreground">Step {currentStep} of 2</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white border-b">
        <div className="max-w-sm mx-auto px-6 py-3">
          <div className="flex items-center gap-2">
            <div className={`flex-1 h-2 rounded-full ${currentStep >= 1 ? 'bg-primary' : 'bg-gray-200'}`} />
            <div className={`flex-1 h-2 rounded-full ${currentStep >= 2 ? 'bg-primary' : 'bg-gray-200'}`} />
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-xs text-muted-foreground">Basic Details</span>
            <span className="text-xs text-muted-foreground">Additional Info</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6">
        <div className="max-w-sm mx-auto">
          {currentStep === 1 && (
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Basic Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="employeeId">Employee ID *</Label>
                  <Input
                    id="employeeId"
                    placeholder="MGJ00272"
                    value={formData.employeeId}
                    onChange={(e) => handleInputChange('employeeId', e.target.value)}
                    className={`bg-input-background ${
                      formData.employeeId && !validateEmployeeId(formData.employeeId) 
                        ? 'border-red-300' : ''
                    }`}
                  />
                  {formData.employeeId && !validateEmployeeId(formData.employeeId) && (
                    <p className="text-xs text-red-600">Format: 3 letters + 5 digits</p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      placeholder="RAJESH"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange('firstName', e.target.value)}
                      className="bg-input-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      placeholder="KUMAR"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange('lastName', e.target.value)}
                      className="bg-input-background"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="designation">Designation *</Label>
                  <Select value={formData.designation} onValueChange={handleDesignationChange}>
                    <SelectTrigger className="bg-input-background">
                      <SelectValue placeholder="Select designation" />
                    </SelectTrigger>
                    <SelectContent>
                      {DESIGNATIONS.map((designation) => (
                        <SelectItem key={designation} value={designation}>
                          {designation}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {formData.designation && (
                    <Badge variant={['MT', 'DC'].includes(formData.designation) ? 'default' : 'secondary'}>
                      {['MT', 'DC'].includes(formData.designation) ? 'Executive' : 'Admin User'}
                    </Badge>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contactNumber">Contact Number *</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="contactNumber"
                      placeholder="9876543210"
                      value={formData.contactNumber}
                      onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                      className={`bg-input-background pl-10 ${
                        formData.contactNumber && !validatePhone(formData.contactNumber) 
                          ? 'border-red-300' : ''
                      }`}
                    />
                  </div>
                  {formData.contactNumber && !validatePhone(formData.contactNumber) && (
                    <p className="text-xs text-red-600">Enter 10-digit mobile number</p>
                  )}
                </div>

                <Button
                  onClick={() => setCurrentStep(2)}
                  disabled={!isStep1Valid()}
                  className="w-full h-12 bg-primary hover:bg-primary/90"
                >
                  Continue
                </Button>
              </CardContent>
            </Card>
          )}

          {currentStep === 2 && (
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  Additional Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {userType === 'executive' ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="dccb">DCCB *</Label>
                      <Select value={formData.dccb} onValueChange={(value) => handleInputChange('dccb', value)}>
                        <SelectTrigger className="bg-input-background">
                          <SelectValue placeholder="Select DCCB" />
                        </SelectTrigger>
                        <SelectContent>
                          {DCCB_OPTIONS.map((dccb) => (
                            <SelectItem key={dccb} value={dccb}>
                              {dccb}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="reportingTo">Reporting Manager *</Label>
                      <Select value={formData.reportingTo} onValueChange={(value) => handleInputChange('reportingTo', value)}>
                        <SelectTrigger className="bg-input-background">
                          <SelectValue placeholder="Select reporting manager" />
                        </SelectTrigger>
                        <SelectContent>
                          {REPORTING_MANAGERS.map((manager) => (
                            <SelectItem key={manager} value={manager}>
                              {manager}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="alternateContact">Alternate Contact</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="alternateContact"
                          placeholder="9876543210 (Optional)"
                          value={formData.alternateContact}
                          onChange={(e) => handleInputChange('alternateContact', e.target.value)}
                          className="bg-input-background pl-10"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address">Address *</Label>
                      <Textarea
                        id="address"
                        placeholder="Full address"
                        value={formData.address}
                        onChange={(e) => handleInputChange('address', e.target.value)}
                        className="bg-input-background min-h-20"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="pinNumber">Pin Code *</Label>
                      <Input
                        id="pinNumber"
                        placeholder="380001"
                        value={formData.pinNumber}
                        onChange={(e) => handleInputChange('pinNumber', e.target.value)}
                        className={`bg-input-background ${
                          formData.pinNumber && !validatePinCode(formData.pinNumber) 
                            ? 'border-red-300' : ''
                        }`}
                      />
                    </div>
                  </>
                ) : (
                  <div className="text-center py-4">
                    <Badge variant="secondary" className="mb-4">
                      Admin User - Simplified Registration
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      As an admin user, only email verification is required for additional details.
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email ID *</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="email"
                      placeholder={userType === 'admin' ? 'official@company.com' : 'email@domain.com'}
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className={`bg-input-background pl-10 ${
                        formData.email && !validateEmail(formData.email) 
                          ? 'border-red-300' : ''
                      }`}
                    />
                  </div>
                  {formData.email && !validateEmail(formData.email) && (
                    <p className="text-xs text-red-600">
                      Enter a valid email address
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Create a secure password"
                    value={formData.password || ''}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    className="bg-input-background"
                  />
                  <p className="text-xs text-muted-foreground">
                    Minimum 6 characters required
                  </p>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentStep(1)}
                    className="flex-1"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={!isStep2Valid() || isLoading}
                    className="flex-1 bg-accent hover:bg-accent/90"
                  >
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Creating...
                      </div>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Create Profile
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}