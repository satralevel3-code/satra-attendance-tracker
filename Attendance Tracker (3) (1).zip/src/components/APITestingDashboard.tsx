import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, AlertTriangle, RefreshCw, Copy, ExternalLink, Bug } from 'lucide-react';
import { GoogleSheetsErrorResolver } from './GoogleSheetsErrorResolver';

interface APITestingDashboardProps {
  onBack?: () => void;
}

export function APITestingDashboard({ onBack }: APITestingDashboardProps) {
  const [testing, setTesting] = useState(false);
  const [testResults, setTestResults] = useState<{
    [key: string]: {
      success: boolean;
      status?: number;
      error?: string;
      data?: any;
      url?: string;
    }
  }>({});

  const API_KEY = 'AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8';
  const SPREADSHEET_ID = '1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY';
  const BASE_URL = 'https://sheets.googleapis.com/v4/spreadsheets';

  const testCases = [
    {
      id: 'api-key-format',
      name: 'API Key Format',
      description: 'Verify API key format is correct',
      test: () => {
        const isValid = API_KEY.startsWith('AIza') && API_KEY.length === 39;
        return {
          success: isValid,
          error: isValid ? undefined : `Invalid format: ${API_KEY.length} chars, starts with "${API_KEY.substring(0, 4)}"`
        };
      }
    },
    {
      id: 'spreadsheet-metadata',
      name: 'Spreadsheet Metadata',
      description: 'Test basic spreadsheet access',
      test: async () => {
        const url = `${BASE_URL}/${SPREADSHEET_ID}?key=${API_KEY}`;
        try {
          const response = await fetch(url);
          const data = response.ok ? await response.json() : await response.text();
          return {
            success: response.ok,
            status: response.status,
            error: response.ok ? undefined : `HTTP ${response.status}: ${data}`,
            data: response.ok ? { title: data.properties?.title, sheets: data.sheets?.length } : undefined,
            url
          };
        } catch (error) {
          return {
            success: false,
            error: `Network error: ${error.message}`,
            url
          };
        }
      }
    },
    {
      id: 'sheets-list',
      name: 'Sheets List',
      description: 'Get list of all sheets in the spreadsheet',
      test: async () => {
        const url = `${BASE_URL}/${SPREADSHEET_ID}?fields=sheets.properties(title,sheetId)&key=${API_KEY}`;
        try {
          const response = await fetch(url);
          const data = response.ok ? await response.json() : await response.text();
          return {
            success: response.ok,
            status: response.status,
            error: response.ok ? undefined : `HTTP ${response.status}: ${data}`,
            data: response.ok ? data.sheets?.map(s => s.properties.title) : undefined,
            url
          };
        } catch (error) {
          return {
            success: false,
            error: `Network error: ${error.message}`,
            url
          };
        }
      }
    },
    {
      id: 'register-employee-sheet',
      name: 'Register Employee Sheet',
      description: 'Test access to the Register Employee sheet',
      test: async () => {
        const url = `${BASE_URL}/${SPREADSHEET_ID}/values/Register%20Employee%20Sheet?key=${API_KEY}`;
        try {
          const response = await fetch(url);
          const data = response.ok ? await response.json() : await response.text();
          return {
            success: response.ok,
            status: response.status,
            error: response.ok ? undefined : `HTTP ${response.status}: ${data}`,
            data: response.ok ? { rows: data.values?.length || 0 } : undefined,
            url
          };
        } catch (error) {
          return {
            success: false,
            error: `Network error: ${error.message}`,
            url
          };
        }
      }
    },
    {
      id: 'write-test',
      name: 'Write Permission Test',
      description: 'Test write permissions (append a test row)',
      test: async () => {
        const url = `${BASE_URL}/${SPREADSHEET_ID}/values/Register%20Employee%20Sheet:append?valueInputOption=RAW&key=${API_KEY}`;
        try {
          const response = await fetch(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              values: [['TEST', 'API Test Entry', new Date().toISOString()]]
            })
          });
          const data = response.ok ? await response.json() : await response.text();
          return {
            success: response.ok,
            status: response.status,
            error: response.ok ? undefined : `HTTP ${response.status}: ${data}`,
            data: response.ok ? { updatedRows: data.updates?.updatedRows } : undefined,
            url
          };
        } catch (error) {
          return {
            success: false,
            error: `Network error: ${error.message}`,
            url
          };
        }
      }
    }
  ];

  const runAllTests = async () => {
    setTesting(true);
    setTestResults({});
    
    for (const testCase of testCases) {
      try {
        const result = await testCase.test();
        setTestResults(prev => ({
          ...prev,
          [testCase.id]: result
        }));
        
        // Small delay between tests
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        setTestResults(prev => ({
          ...prev,
          [testCase.id]: {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error'
          }
        }));
      }
    }
    
    setTesting(false);
  };

  const runSingleTest = async (testCase: typeof testCases[0]) => {
    setTestResults(prev => ({
      ...prev,
      [testCase.id]: { success: false, error: 'Testing...' }
    }));

    try {
      const result = await testCase.test();
      setTestResults(prev => ({
        ...prev,
        [testCase.id]: result
      }));
    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        [testCase.id]: {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        }
      }));
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getStatusIcon = (result?: typeof testResults[string]) => {
    if (!result) return <AlertTriangle className="w-5 h-5 text-gray-400" />;
    if (result.success) return <CheckCircle className="w-5 h-5 text-green-500" />;
    return <XCircle className="w-5 h-5 text-red-500" />;
  };

  const getStatusBadge = (result?: typeof testResults[string]) => {
    if (!result) return <Badge variant="outline">Not Run</Badge>;
    if (result.success) return <Badge className="bg-green-100 text-green-800">Success</Badge>;
    if (result.status === 400) return <Badge variant="destructive">400 Bad Request</Badge>;
    if (result.status === 401) return <Badge variant="destructive">401 Unauthorized</Badge>;
    if (result.status === 403) return <Badge variant="destructive">403 Forbidden</Badge>;
    if (result.status === 404) return <Badge variant="destructive">404 Not Found</Badge>;
    return <Badge variant="destructive">Failed</Badge>;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Bug className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold text-primary">API Testing Dashboard</h1>
          </div>
          <p className="text-muted-foreground text-lg">
            Comprehensive testing to diagnose Google Sheets API issues
          </p>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <Button 
                onClick={runAllTests}
                disabled={testing}
                className="bg-primary hover:bg-primary/90"
              >
                {testing ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Running Tests...
                  </>
                ) : (
                  <>
                    <Bug className="w-4 h-4 mr-2" />
                    Run All Tests
                  </>
                )}
              </Button>
              
              {onBack && (
                <Button variant="outline" onClick={onBack}>
                  ← Back to Dashboard
                </Button>
              )}
              
              <Button 
                variant="outline"
                onClick={() => window.open('https://console.cloud.google.com/apis/credentials', '_blank')}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                API Credentials
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Configuration Info */}
        <Card>
          <CardHeader>
            <CardTitle>Current Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <strong>Project:</strong> satra-attendance-tracker
              </div>
              <div>
                <strong>API Key:</strong> {API_KEY.substring(0, 8)}...{API_KEY.slice(-4)}
              </div>
              <div>
                <strong>Spreadsheet ID:</strong> {SPREADSHEET_ID.substring(0, 12)}...{SPREADSHEET_ID.slice(-6)}
              </div>
              <div>
                <strong>Service Account:</strong> attendance-tracker-service@...
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Test Results */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-primary">Test Results</h2>
          
          {testCases.map((testCase) => {
            const result = testResults[testCase.id];
            
            return (
              <Card key={testCase.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(result)}
                      <div>
                        <CardTitle className="text-lg">{testCase.name}</CardTitle>
                        <CardDescription>{testCase.description}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(result)}
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => runSingleTest(testCase)}
                        disabled={testing}
                      >
                        {testing && result?.error === 'Testing...' ? (
                          <RefreshCw className="w-4 h-4 animate-spin" />
                        ) : (
                          'Test'
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                {result && (
                  <CardContent>
                    {result.success ? (
                      <Alert className="border-green-200 bg-green-50">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <AlertDescription className="text-green-800">
                          <strong>✅ Success!</strong>
                          {result.data && (
                            <pre className="mt-2 text-xs bg-green-100 p-2 rounded">
                              {JSON.stringify(result.data, null, 2)}
                            </pre>
                          )}
                        </AlertDescription>
                      </Alert>
                    ) : (
                      <Alert className="border-red-200 bg-red-50">
                        <XCircle className="h-4 w-4 text-red-600" />
                        <AlertDescription className="text-red-800">
                          <strong>❌ Failed:</strong> {result.error}
                          {result.status && (
                            <div className="mt-1 text-sm">
                              <strong>HTTP Status:</strong> {result.status}
                            </div>
                          )}
                        </AlertDescription>
                      </Alert>
                    )}
                    
                    {result.url && (
                      <div className="mt-3 p-2 bg-gray-50 rounded text-xs">
                        <div className="flex items-center justify-between">
                          <strong>Test URL:</strong>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => copyToClipboard(result.url!)}
                          >
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                        <code className="break-all">{result.url}</code>
                      </div>
                    )}
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>

        {/* Common Issues */}
        <Card>
          <CardHeader>
            <CardTitle>Common Issues & Solutions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border-l-4 border-red-500 pl-4">
                <h4 className="font-semibold text-red-800">400 Bad Request</h4>
                <p className="text-sm text-red-700">Invalid API key format or malformed request parameters</p>
                <ul className="text-sm text-red-600 mt-1 space-y-1">
                  <li>• Verify API key is exactly 39 characters and starts with "AIza"</li>
                  <li>• Check for extra spaces or characters in the API key</li>
                  <li>• Ensure spreadsheet ID is correct</li>
                </ul>
              </div>

              <div className="border-l-4 border-orange-500 pl-4">
                <h4 className="font-semibold text-orange-800">401 Unauthorized</h4>
                <p className="text-sm text-orange-700">API key lacks permissions or has restrictions</p>
                <ul className="text-sm text-orange-600 mt-1 space-y-1">
                  <li>• Remove API key restrictions (set to "None" and "Don't restrict key")</li>
                  <li>• Share spreadsheet with service account</li>
                  <li>• Check API key hasn't expired</li>
                </ul>
              </div>

              <div className="border-l-4 border-red-500 pl-4">
                <h4 className="font-semibold text-red-800">403 Forbidden</h4>
                <p className="text-sm text-red-700">Google Sheets API not enabled or insufficient permissions</p>
                <ul className="text-sm text-red-600 mt-1 space-y-1">
                  <li>• Enable Google Sheets API in Google Cloud Console</li>
                  <li>• Enable Google Drive API (required for some operations)</li>
                  <li>• Check project billing status</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}