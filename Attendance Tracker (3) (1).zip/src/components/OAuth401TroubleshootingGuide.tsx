import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, AlertTriangle, ExternalLink, Copy, RefreshCw, Shield, Key, Share } from 'lucide-react';
import { googleSheetsService } from '../services/GoogleSheetsService';

interface OAuth401TroubleshootingGuideProps {
  onRetry?: () => void;
  onBack?: () => void;
}

export function OAuth401TroubleshootingGuide({ onRetry, onBack }: OAuth401TroubleshootingGuideProps) {
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionResult, setConnectionResult] = useState<{
    success: boolean;
    error?: string;
  } | null>(null);

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setConnectionResult(null);
    
    try {
      const result = await googleSheetsService.testConnection();
      setConnectionResult(result);
    } catch (error) {
      setConnectionResult({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const troubleshootingSteps = [
    {
      title: "Step 1: Remove API Key Restrictions",
      status: "critical",
      description: "Your API key might have restrictions that prevent access to Google Sheets.",
      action: (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            1. Go to <a href="https://console.cloud.google.com/apis/credentials" target="_blank" className="text-primary hover:underline inline-flex items-center gap-1">
              Google Cloud Console Credentials <ExternalLink size={14} />
            </a>
          </p>
          <p className="text-sm text-muted-foreground">
            2. Find and click on your API key: AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8
          </p>
          <div className="flex items-center gap-2">
            <code className="bg-muted px-2 py-1 rounded text-sm">AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8</code>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => copyToClipboard('AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8')}
            >
              <Copy size={14} />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            3. Under "Application restrictions", select <strong>"None"</strong>
          </p>
          <p className="text-sm text-muted-foreground">
            4. Under "API restrictions", select <strong>"Don't restrict key"</strong>
          </p>
          <p className="text-sm text-muted-foreground">
            5. Click "Save"
          </p>
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> Removing restrictions makes your API key less secure but fixes access issues. 
              You can add restrictions back later once everything is working.
            </AlertDescription>
          </Alert>
        </div>
      )
    },
    {
      title: "Step 2: Share Spreadsheet with Service Account",
      status: "critical", 
      description: "Your spreadsheet must be shared with the service account email for API access.",
      action: (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            1. Open your spreadsheet: 
          </p>
          <div className="flex items-center gap-2">
            <a 
              href="https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY/edit" 
              target="_blank" 
              className="text-primary hover:underline inline-flex items-center gap-1 text-sm"
            >
              Satra Attendance Tracker <ExternalLink size={14} />
            </a>
          </div>
          <p className="text-sm text-muted-foreground">
            2. Click the "Share" button in the top right corner
          </p>
          <p className="text-sm text-muted-foreground">
            3. Add this service account email as an Editor:
          </p>
          <div className="flex items-center gap-2">
            <code className="bg-muted px-2 py-1 rounded text-sm break-all">attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com</code>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => copyToClipboard('attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com')}
            >
              <Copy size={14} />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            4. Set permission to "Editor" and click "Send"
          </p>
          <Alert>
            <Share className="h-4 w-4" />
            <AlertDescription>
              You can ignore the warning "This is a service account" - that's expected and normal.
            </AlertDescription>
          </Alert>
        </div>
      )
    },
    {
      title: "Step 3: Enable Required APIs",
      status: "warning",
      description: "Make sure both Google Sheets API and Google Drive API are enabled.",
      action: (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Make sure these APIs are enabled for your project "satra-attendance-tracker":
          </p>
          <div className="grid grid-cols-1 gap-2">
            <a 
              href="https://console.cloud.google.com/apis/library/sheets.googleapis.com" 
              target="_blank"
              className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <ExternalLink size={16} />
              <span>Google Sheets API</span>
            </a>
            <a 
              href="https://console.cloud.google.com/apis/library/drive.googleapis.com" 
              target="_blank"
              className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <ExternalLink size={16} />
              <span>Google Drive API</span>
            </a>
          </div>
        </div>
      )
    },
    {
      title: "Step 4: Test API Access Directly",
      status: "info",
      description: "Test if your API key can access the spreadsheet directly in your browser.",
      action: (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Click this link to test API access directly:
          </p>
          <div className="p-3 bg-gray-50 rounded-lg">
            <a 
              href="https://sheets.googleapis.com/v4/spreadsheets/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY?key=AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8"
              target="_blank"
              className="text-primary hover:underline text-sm break-all"
            >
              https://sheets.googleapis.com/v4/spreadsheets/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY?key=AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8
            </a>
          </div>
          <div className="text-sm text-muted-foreground">
            <strong>Expected results:</strong>
            <ul className="list-disc list-inside mt-1 space-y-1">
              <li><strong>Success:</strong> You should see JSON data about your spreadsheet</li>
              <li><strong>401 Error:</strong> Permission denied - follow steps above</li>
              <li><strong>403 Error:</strong> API not enabled - enable Google Sheets API</li>
              <li><strong>404 Error:</strong> Spreadsheet not found or not shared properly</li>
            </ul>
          </div>
        </div>
      )
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'critical':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'info':
        return <CheckCircle className="w-5 h-5 text-blue-500" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'critical':
        return <Badge variant="destructive">Critical</Badge>;
      case 'warning':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Important</Badge>;
      case 'info':
        return <Badge variant="secondary">Test</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Key className="w-8 h-8 text-red-500" />
            <h1 className="text-3xl font-bold text-primary">401 Authentication Error</h1>
          </div>
          <p className="text-muted-foreground text-lg">
            API key lacks required permissions. Follow these steps to grant proper access.
          </p>
        </div>

        {/* Current Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Current Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Alert>
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>HTTP 401:</strong> API key lacks required permissions for Google Sheets access
                </AlertDescription>
              </Alert>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <strong>Progress:</strong> ✅ API Key Valid, ✅ API Enabled
                </div>
                <div>
                  <strong>Issue:</strong> ❌ Access Permissions
                </div>
                <div>
                  <strong>API Key:</strong> AIzaSyDvM...sA8 ✓
                </div>
                <div>
                  <strong>Project:</strong> satra-attendance-tracker ✓
                </div>
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={handleTestConnection}
                  disabled={testingConnection}
                  variant="outline"
                >
                  {testingConnection ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Testing...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Test Connection
                    </>
                  )}
                </Button>
                
                {onBack && (
                  <Button variant="outline" onClick={onBack}>
                    ← Back to Dashboard
                  </Button>
                )}
              </div>

              {connectionResult && (
                <Alert className={connectionResult.success ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
                  {connectionResult.success ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600" />
                  )}
                  <AlertDescription className={connectionResult.success ? "text-green-800" : "text-red-800"}>
                    {connectionResult.success 
                      ? (
                        <div>
                          ✅ Connection successful! The issue has been resolved.
                          <Button 
                            className="ml-3" 
                            size="sm"
                            onClick={() => {
                              localStorage.removeItem('google_sheets_401_error');
                              localStorage.removeItem('401_banner_dismissed');
                              if (onBack) onBack();
                            }}
                          >
                            Return to Dashboard
                          </Button>
                        </div>
                      )
                      : `❌ Still failing: ${connectionResult.error}`
                    }
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Troubleshooting Steps */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-primary">401 Error Fix Steps</h2>
          
          {troubleshootingSteps.map((step, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(step.status)}
                    {step.title}
                  </div>
                  {getStatusBadge(step.status)}
                </CardTitle>
                <CardDescription>{step.description}</CardDescription>
              </CardHeader>
              <CardContent>
                {step.action}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Fix Summary */}
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800">Quick Fix Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-green-800">
              <p><strong>Most likely solution:</strong></p>
              <ol className="list-decimal list-inside space-y-1 text-sm">
                <li>Remove API key restrictions (set to "None" and "Don't restrict key")</li>
                <li>Share spreadsheet with: attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com</li>
                <li>Test the connection again</li>
              </ol>
            </div>
          </CardContent>
        </Card>

        {/* Note */}
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Note:</strong> Changes to API key restrictions and sharing permissions take effect immediately. 
            Test the connection after each change to see if the issue is resolved.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}