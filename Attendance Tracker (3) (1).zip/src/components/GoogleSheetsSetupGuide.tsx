import { ExternalLink, Key, FileSpreadsheet, Settings, CheckCircle, Shield, LogIn, AlertTriangle, Info } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Alert, AlertDescription } from "./ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { googleSheetsService } from "../services/GoogleSheetsService";

export function GoogleSheetsSetupGuide() {
  const authStatus = googleSheetsService.getAuthStatus();
  const isOAuthConfigured = googleSheetsService.isOAuthConfigured();

  const handleOAuthLogin = () => {
    try {
      const authUrl = googleSheetsService.getAuthorizationUrl();
      window.location.href = authUrl;
    } catch (error) {
      console.error('Failed to initiate OAuth:', error);
      alert('Failed to initiate OAuth authentication. Please try the API key method instead.');
    }
  };

  const handleDisconnect = () => {
    googleSheetsService.disconnect();
    window.location.reload();
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-semibold text-primary mb-2">
          Google Sheets API Setup Guide
        </h1>
        <p className="text-muted-foreground">
          Choose your preferred method to connect your Satra Attendance Tracker to Google Sheets
        </p>
      </div>

      <Alert className="border-blue-200 bg-blue-50">
        <FileSpreadsheet className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-800">
          <strong>Your Spreadsheet:</strong> Satra Attendance Tracker
          <br />
          <strong>Spreadsheet ID:</strong> 1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY
        </AlertDescription>
      </Alert>

      {/* Authentication Status */}
      {authStatus.authenticated && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            <div className="flex items-center justify-between">
              <div>
                <strong>Connected!</strong> Using {authStatus.method === 'oauth' ? 'OAuth' : 'API Key'} authentication
                {authStatus.tokenExpiry && (
                  <div className="text-sm mt-1">
                    Token expires: {authStatus.tokenExpiry.toLocaleString()}
                  </div>
                )}
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleDisconnect}
                className="text-red-600 border-red-300 hover:bg-red-50"
              >
                Disconnect
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Quick OAuth Option */}
      {isOAuthConfigured && !authStatus.authenticated && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <Shield className="w-5 h-5" />
              Quick Setup (Recommended)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-green-700 mb-4">
              OAuth credentials are already configured! You can connect immediately using secure OAuth authentication.
            </p>
            <Button 
              onClick={handleOAuthLogin} 
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <LogIn className="w-4 h-4 mr-2" />
              Connect with Google OAuth
            </Button>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="oauth" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="oauth">OAuth Setup (Recommended)</TabsTrigger>
          <TabsTrigger value="api-key">API Key Setup</TabsTrigger>
        </TabsList>

        <TabsContent value="oauth" className="space-y-6">
          <div className="text-center p-6 bg-blue-50 rounded-lg">
            <Shield className="w-12 h-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-blue-900 mb-2">OAuth Authentication</h3>
            <p className="text-blue-700">
              The safest and most secure method. You'll authorize the app through Google's official login.
            </p>
            {isOAuthConfigured ? (
              <div className="mt-4">
                <Button 
                  onClick={handleOAuthLogin} 
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  Connect with Google OAuth
                </Button>
              </div>
            ) : (
              <Alert className="mt-4 border-amber-200 bg-amber-50">
                <Settings className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-amber-800">
                  OAuth credentials need to be configured. Contact your administrator.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </TabsContent>

        <TabsContent value="api-key" className="space-y-6">
          <div className="grid gap-6">
        
        {/* Current Configuration Status */}
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <CheckCircle className="w-5 h-5" />
              Current Configuration Status ✅
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-amber-200 bg-amber-100">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800">
                <strong>Configuration Issue:</strong> Your Google Sheets integration needs a valid API key to work properly.
              </AlertDescription>
            </Alert>
            
            <div className="bg-white border border-green-200 rounded p-4">
              <h4 className="font-medium text-green-800 mb-3">Active Configuration:</h4>
              <div className="text-sm space-y-2">
                <div className="flex items-start gap-2">
                  <span className="font-medium min-w-[140px]">API Key:</span>
                  <code className="text-xs bg-red-100 px-2 py-1 rounded break-all flex-1 border border-red-200">
                    ❌ INVALID - Need Google Sheets API key (starts with "AIza")
                  </code>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-medium min-w-[140px]">Service Account:</span>
                  <code className="text-xs bg-green-100 px-2 py-1 rounded break-all flex-1">
                    attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com
                  </code>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-medium min-w-[140px]">OAuth Client ID:</span>
                  <code className="text-xs bg-green-100 px-2 py-1 rounded break-all flex-1">
                    43302794729-ng4b6gp6n5ga6lohvd9fptlblof3ta3r.apps.googleusercontent.com
                  </code>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-medium min-w-[140px]">Spreadsheet:</span>
                  <code className="text-xs bg-green-100 px-2 py-1 rounded break-all flex-1">
                    1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY
                  </code>
                </div>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" asChild>
                <a href="https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY/edit" target="_blank" rel="noopener noreferrer">
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  View Spreadsheet
                </a>
              </Button>
              <Button variant="outline" className="flex-1" asChild>
                <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Google Cloud Console
                </a>
              </Button>
            </div>
            
            <div className="space-y-3">
              <Alert className="border-blue-200 bg-blue-50">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800">
                  <strong>Next Steps:</strong> You need to create a valid Google Sheets API key to complete the setup.
                </AlertDescription>
              </Alert>
              
              <div className="bg-blue-50 border border-blue-200 rounded p-3">
                <h4 className="font-medium text-blue-800 mb-2">Required API Key Format:</h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Must start with "AIza"</li>
                  <li>• Must be exactly 39 characters long</li>
                  <li>• Must have Google Sheets API enabled</li>
                  <li>• Example: AIzaSyAbc123def456ghi789jkl012mno345pqr6</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">1</span>
              Create Google Cloud Project
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p>Go to the Google Cloud Console and create a new project or select an existing one.</p>
            <Button variant="outline" className="w-full" asChild>
              <a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer">
                <ExternalLink className="w-4 h-4 mr-2" />
                Open Google Cloud Console
              </a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">2</span>
              Enable Google Sheets API
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p>In your Google Cloud project, enable the Google Sheets API.</p>
            <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
              <li>Go to "APIs & Services" → "Library"</li>
              <li>Search for "Google Sheets API"</li>
              <li>Click on it and press "Enable"</li>
            </ol>
            <Button variant="outline" className="w-full" asChild>
              <a href="https://console.cloud.google.com/apis/library/sheets.googleapis.com" target="_blank" rel="noopener noreferrer">
                <ExternalLink className="w-4 h-4 mr-2" />
                Enable Google Sheets API
              </a>
            </Button>
          </CardContent>
        </Card>

        <Card className="border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-800">
              <span className="bg-amber-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">3</span>
              Create Valid API Key ⚠️
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-amber-200 bg-amber-100">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800">
                <strong>Current Issue:</strong> The API key in your configuration is not valid for Google Sheets.
              </AlertDescription>
            </Alert>
            
            <p className="text-amber-800">Follow these steps to create a proper Google Sheets API key:</p>
            <ol className="list-decimal list-inside space-y-2 text-sm">
              <li>Go to "APIs & Services" → "Credentials"</li>
              <li>Click "Create Credentials" → "API Key"</li>
              <li><strong>Important:</strong> Copy the generated API key (must start with "AIza")</li>
              <li>Click "Restrict Key" and select "Google Sheets API"</li>
              <li>Save the restrictions</li>
            </ol>
            
            <div className="bg-white border border-amber-200 rounded p-3">
              <h4 className="font-medium text-amber-800 mb-2">Valid API Key Requirements:</h4>
              <ul className="text-sm text-amber-700 space-y-1">
                <li>✅ Starts with "AIza"</li>
                <li>✅ Exactly 39 characters long</li>
                <li>✅ Google Sheets API enabled</li>
                <li>✅ Example: AIzaSyAbc123def456ghi789jkl012mno345pqr6</li>
              </ul>
            </div>
            
            <Button variant="outline" className="w-full border-amber-300 text-amber-800 hover:bg-amber-100" asChild>
              <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer">
                <Key className="w-4 h-4 mr-2" />
                Create Google Sheets API Key
              </a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">4</span>
              Make Spreadsheet Public
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p>Your Google Sheet must be accessible to anyone with the link.</p>
            <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
              <li>Open your "Satra Attendance Tracker" spreadsheet</li>
              <li>Click "Share" button in the top right</li>
              <li>Change access to "Anyone with the link" → "Viewer"</li>
              <li>Click "Done"</li>
            </ol>
            <Button variant="outline" className="w-full" asChild>
              <a href="https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY/edit" target="_blank" rel="noopener noreferrer">
                <FileSpreadsheet className="w-4 h-4 mr-2" />
                Open Your Spreadsheet
              </a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">5</span>
              Update App Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p>Replace the API key in the GoogleSheetsService.ts file.</p>
            <div className="bg-gray-100 p-3 rounded text-sm font-mono">
              <div className="text-gray-600">// In /services/GoogleSheetsService.ts</div>
              <div>private readonly API_KEY = '<span className="text-red-600">YOUR_API_KEY_HERE</span>';</div>
            </div>
            <Alert className="border-amber-200 bg-amber-50">
              <Settings className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800">
                <strong>Important:</strong> The API key should start with "AIza" and be 39 characters long.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <CheckCircle className="w-5 h-5" />
              You're All Set!
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-green-700">
              Once you've completed these steps, your attendance tracker will sync in real-time with Google Sheets. 
              All employee registrations, attendance records, and reports will be automatically saved and updated.
            </p>
          </CardContent>
        </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-medium text-gray-900 mb-2">Need Help?</h3>
        <p className="text-sm text-gray-600">
          For now, the app will continue to work with sample data. Once you complete the setup above, 
          restart the app to connect to your Google Sheets.
        </p>
      </div>
    </div>
  );
}