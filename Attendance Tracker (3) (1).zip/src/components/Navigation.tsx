import { useState } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  LayoutDashboard, 
  Users, 
  MapPin, 
  Camera, 
  BarChart3, 
  Settings,
  Menu,
  X
} from "lucide-react";

interface NavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
}

export function Navigation({ currentView, onViewChange }: NavigationProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigationItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'checkin',
      label: 'Check In/Out',
      icon: Camera,
      badge: null
    },
    {
      id: 'workers',
      label: 'Workers',
      icon: Users,
      badge: 200
    },
    {
      id: 'locations',
      label: 'Locations',
      icon: MapPin,
      badge: 8
    },
    {
      id: 'reports',
      label: 'Reports',
      icon: BarChart3,
      badge: null
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      badge: null
    }
  ];

  const NavItems = ({ mobile = false }: { mobile?: boolean }) => (
    <>
      {navigationItems.map((item) => {
        const IconComponent = item.icon;
        const isActive = currentView === item.id;
        
        return (
          <Button
            key={item.id}
            variant={isActive ? "default" : "ghost"}
            className={`
              ${mobile ? 'w-full justify-start' : 'flex-col h-auto py-3 px-2'}
              ${isActive ? 'bg-primary text-primary-foreground' : ''}
            `}
            onClick={() => {
              onViewChange(item.id);
              if (mobile) setIsMobileMenuOpen(false);
            }}
          >
            <IconComponent className={`${mobile ? 'mr-2' : 'mb-1'} w-5 h-5`} />
            <span className={mobile ? '' : 'text-xs'}>{item.label}</span>
            {item.badge && (
              <Badge 
                variant="secondary" 
                className={`${mobile ? 'ml-auto' : 'absolute -top-2 -right-2'} text-xs`}
              >
                {item.badge}
              </Badge>
            )}
          </Button>
        );
      })}
    </>
  );

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:flex flex-col w-20 bg-card border-r border-border p-2 space-y-2">
        <div className="flex flex-col items-center mb-4">
          <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mb-2">
            <Camera className="w-6 h-6 text-primary-foreground" />
          </div>
          <span className="text-xs font-medium text-center">Gujarat Attendance</span>
        </div>
        
        <NavItems />
      </nav>

      {/* Mobile Navigation */}
      <div className="md:hidden">
        {/* Mobile Header */}
        <div className="flex items-center justify-between p-4 bg-card border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Camera className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-medium">Gujarat Attendance</span>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </Button>
        </div>

        {/* Mobile Menu Overlay */}
        {isMobileMenuOpen && (
          <div className="fixed inset-0 bg-black/50 z-50" onClick={() => setIsMobileMenuOpen(false)}>
            <div 
              className="fixed top-0 right-0 h-full w-64 bg-card border-l border-border p-4 space-y-2"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <span className="font-medium">Navigation</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
              
              <NavItems mobile />
            </div>
          </div>
        )}

        {/* Mobile Bottom Navigation (Alternative) */}
        <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border md:hidden">
          <div className="flex items-center justify-around py-2">
            {navigationItems.slice(0, 4).map((item) => {
              const IconComponent = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  className={`
                    flex-col h-auto py-2 px-3 relative
                    ${isActive ? 'text-primary' : 'text-muted-foreground'}
                  `}
                  onClick={() => onViewChange(item.id)}
                >
                  <IconComponent className="w-5 h-5 mb-1" />
                  <span className="text-xs">{item.label}</span>
                  {item.badge && (
                    <Badge 
                      variant="secondary" 
                      className="absolute -top-1 -right-1 text-xs w-5 h-5 rounded-full p-0 flex items-center justify-center"
                    >
                      {item.badge > 99 ? '99+' : item.badge}
                    </Badge>
                  )}
                  {isActive && (
                    <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-primary rounded-full" />
                  )}
                </Button>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}