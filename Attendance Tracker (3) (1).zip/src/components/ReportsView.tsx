import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  LineChart, 
  Line,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer
} from "recharts";
import { 
  Download, 
  Calendar, 
  TrendingUp, 
  TrendingDown,
  Users,
  Clock,
  MapPin,
  AlertTriangle
} from "lucide-react";

const weeklyAttendanceData = [
  { day: 'Mon', present: 185, absent: 15, late: 8 },
  { day: 'Tue', present: 178, absent: 22, late: 12 },
  { day: 'Wed', present: 192, absent: 8, late: 5 },
  { day: 'Thu', present: 175, absent: 25, late: 15 },
  { day: 'Fri', present: 188, absent: 12, late: 7 },
  { day: 'Sat', present: 165, absent: 35, late: 10 },
  { day: 'Sun', present: 95, absent: 105, late: 3 }
];

const monthlyTrendData = [
  { month: 'Jan', attendance: 88, lateArrivals: 6 },
  { month: 'Feb', attendance: 91, lateArrivals: 5 },
  { month: 'Mar', attendance: 85, lateArrivals: 8 },
  { month: 'Apr', attendance: 89, lateArrivals: 7 },
  { month: 'May', attendance: 92, lateArrivals: 4 },
  { month: 'Jun', attendance: 87, lateArrivals: 9 },
  { month: 'Jul', attendance: 90, lateArrivals: 6 }
];

const locationWiseData = [
  { name: 'Ahmedabad', workers: 45, present: 42, attendance: 93 },
  { name: 'Surat', workers: 38, present: 35, attendance: 92 },
  { name: 'Vadodara', workers: 32, present: 28, attendance: 88 },
  { name: 'Rajkot', workers: 28, present: 26, attendance: 93 },
  { name: 'Bhavnagar', workers: 22, present: 18, attendance: 82 },
  { name: 'Others', workers: 35, present: 29, attendance: 83 }
];

const attendanceDistribution = [
  { name: 'Present', value: 178, color: '#10B981' },
  { name: 'Absent', value: 22, color: '#EF4444' },
  { name: 'Late', value: 12, color: '#F59E0B' }
];

export function ReportsView() {
  const [selectedPeriod, setSelectedPeriod] = useState('week');
  const [selectedLocation, setSelectedLocation] = useState('all');

  const totalPresent = weeklyAttendanceData.reduce((sum, day) => sum + day.present, 0);
  const totalAbsent = weeklyAttendanceData.reduce((sum, day) => sum + day.absent, 0);
  const totalLate = weeklyAttendanceData.reduce((sum, day) => sum + day.late, 0);
  const averageAttendance = Math.round((totalPresent / (totalPresent + totalAbsent)) * 100);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Attendance Reports</h1>
          <p className="text-muted-foreground">
            Analytics and insights for field worker attendance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-green-600" />
              <div>
                <div className="text-2xl font-bold text-green-600">{averageAttendance}%</div>
                <p className="text-sm text-muted-foreground">Average Attendance</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="w-3 h-3 text-green-600" />
                  <span className="text-xs text-green-600">+2.5% from last week</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-orange-600" />
              <div>
                <div className="text-2xl font-bold text-orange-600">{Math.round(totalLate / 7)}</div>
                <p className="text-sm text-muted-foreground">Avg Daily Late</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingDown className="w-3 h-3 text-red-600" />
                  <span className="text-xs text-red-600">+1.2% from last week</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-600" />
              <div>
                <div className="text-2xl font-bold text-blue-600">5</div>
                <p className="text-sm text-muted-foreground">Active Locations</p>
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-xs text-muted-foreground">Across Gujarat</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <div>
                <div className="text-2xl font-bold text-red-600">{Math.round(totalAbsent / 7)}</div>
                <p className="text-sm text-muted-foreground">Avg Daily Absent</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingDown className="w-3 h-3 text-green-600" />
                  <span className="text-xs text-green-600">-0.8% from last week</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <Tabs defaultValue="daily" className="space-y-4">
        <TabsList>
          <TabsTrigger value="daily">Daily Attendance</TabsTrigger>
          <TabsTrigger value="trends">Monthly Trends</TabsTrigger>
          <TabsTrigger value="locations">By Location</TabsTrigger>
          <TabsTrigger value="distribution">Distribution</TabsTrigger>
        </TabsList>

        <TabsContent value="daily">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Daily Attendance - This Week
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={weeklyAttendanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="present" name="Present" fill="#10B981" />
                  <Bar dataKey="late" name="Late" fill="#F59E0B" />
                  <Bar dataKey="absent" name="Absent" fill="#EF4444" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Monthly Attendance Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={monthlyTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" domain={[80, 95]} />
                  <YAxis yAxisId="right" orientation="right" domain={[0, 10]} />
                  <Tooltip />
                  <Legend />
                  <Line 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="attendance" 
                    stroke="#10B981" 
                    strokeWidth={3}
                    name="Attendance %" 
                  />
                  <Line 
                    yAxisId="right"
                    type="monotone" 
                    dataKey="lateArrivals" 
                    stroke="#F59E0B" 
                    strokeWidth={2}
                    name="Late Arrivals %" 
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="locations">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Attendance by Location
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {locationWiseData.map((location) => (
                  <div key={location.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">{location.name}</span>
                        <span className="text-sm text-muted-foreground ml-2">
                          {location.present}/{location.workers} present
                        </span>
                      </div>
                      <Badge 
                        variant={location.attendance >= 90 ? "default" : location.attendance >= 85 ? "secondary" : "destructive"}
                        className={
                          location.attendance >= 90 
                            ? "bg-green-100 text-green-800" 
                            : location.attendance >= 85 
                            ? "bg-orange-100 text-orange-800" 
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {location.attendance}%
                      </Badge>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          location.attendance >= 90 ? 'bg-green-500' : 
                          location.attendance >= 85 ? 'bg-orange-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${location.attendance}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="distribution">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Today's Attendance Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={attendanceDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={120}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {attendanceDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Attendance Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {attendanceDistribution.map((item) => (
                  <div key={item.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="font-medium">{item.name}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">{item.value}</div>
                      <div className="text-sm text-muted-foreground">
                        {Math.round((item.value / (178 + 22 + 12)) * 100)}%
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Insights and Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Insights & Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="font-medium text-green-700">Positive Trends</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span>Overall attendance improved by 2.5% this week</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span>Ahmedabad and Rajkot sites maintain 93% attendance</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span>Weekend attendance is consistently stable</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-medium text-red-700">Areas for Improvement</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span>Bhavnagar site shows lowest attendance (82%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span>Late arrivals increased by 1.2% this week</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span>Thursday shows consistently higher absence rates</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}