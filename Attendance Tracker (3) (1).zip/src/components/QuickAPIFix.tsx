import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { CheckCircle, XCircle, AlertTriangle, Copy, ExternalLink } from 'lucide-react';

export function QuickAPIFix() {
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<{
    step: string;
    success: boolean;
    message: string;
    action?: string;
  } | null>(null);

  const API_KEY = 'AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8';
  const SPREADSHEET_ID = '1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY';

  const runQuickDiagnostic = async () => {
    setTesting(true);
    setResult(null);

    try {
      // Step 1: Test API key format
      if (!API_KEY.startsWith('AIza') || API_KEY.length !== 39) {
        setResult({
          step: 'API Key Format Check',
          success: false,
          message: `Invalid API key format. Expected 39 characters starting with "AIza", got ${API_KEY.length} characters starting with "${API_KEY.substring(0, 4)}"`,
          action: 'Get a new API key from Google Cloud Console'
        });
        setTesting(false);
        return;
      }

      setResult({
        step: 'API Key Format Check',
        success: true,
        message: 'API key format is correct ✓'
      });

      // Step 2: Test spreadsheet access
      const testUrl = `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}?key=${API_KEY}`;
      
      try {
        const response = await fetch(testUrl);
        const responseText = await response.text();
        
        if (response.status === 400) {
          setResult({
            step: 'API Access Test',
            success: false,
            message: 'Bad Request (400): Your API key format might be invalid or there are request parameter issues.',
            action: 'Check API key in Google Cloud Console and ensure no extra characters or restrictions'
          });
        } else if (response.status === 401) {
          setResult({
            step: 'API Access Test', 
            success: false,
            message: 'Unauthorized (401): API key lacks permissions to access the spreadsheet.',
            action: 'Remove API key restrictions and share spreadsheet with service account'
          });
        } else if (response.status === 403) {
          let message = 'Forbidden (403): ';
          if (responseText.includes('Google Sheets API has not been used')) {
            message += 'Google Sheets API is not enabled for your project.';
            setResult({
              step: 'API Access Test',
              success: false,
              message,
              action: 'Enable Google Sheets API in Google Cloud Console'
            });
          } else {
            message += 'API key lacks necessary permissions.';
            setResult({
              step: 'API Access Test',
              success: false,
              message,
              action: 'Check API key permissions and spreadsheet sharing'
            });
          }
        } else if (response.status === 404) {
          setResult({
            step: 'API Access Test',
            success: false,
            message: 'Not Found (404): Spreadsheet not found or not accessible.',
            action: 'Verify spreadsheet ID and sharing permissions'
          });
        } else if (response.ok) {
          const data = JSON.parse(responseText);
          setResult({
            step: 'API Access Test',
            success: true,
            message: `✅ SUCCESS! Connected to spreadsheet: "${data.properties?.title || 'Unknown'}"`
          });
        } else {
          setResult({
            step: 'API Access Test',
            success: false,
            message: `HTTP ${response.status}: ${responseText}`,
            action: 'Check the error details above'
          });
        }
      } catch (networkError) {
        setResult({
          step: 'API Access Test',
          success: false,
          message: `Network error: ${networkError.message}`,
          action: 'Check your internet connection'
        });
      }
    } catch (error) {
      setResult({
        step: 'Diagnostic Error',
        success: false,
        message: `Unexpected error: ${error.message}`,
        action: 'Try refreshing the page'
      });
    } finally {
      setTesting(false);
    }
  };

  const getQuickSolution = () => {
    if (!result || result.success) return null;

    if (result.message.includes('400')) {
      return (
        <Card className="border-purple-200 bg-purple-50 mt-4">
          <CardHeader>
            <CardTitle className="text-purple-800">🔧 Quick Fix for 400 Error</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm text-purple-700">
              <strong>Most likely cause:</strong> API key restrictions or format issues
            </div>
            <div className="space-y-2">
              <Button
                onClick={() => window.open('https://console.cloud.google.com/apis/credentials', '_blank')}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                1. Fix API Key Restrictions
              </Button>
              <div className="text-xs text-purple-600 pl-6">
                → Set Application restrictions to <strong>"None"</strong><br />
                → Set API restrictions to <strong>"Don't restrict key"</strong>
              </div>
            </div>
          </CardContent>
        </Card>
      );
    }

    if (result.message.includes('401')) {
      return (
        <Card className="border-orange-200 bg-orange-50 mt-4">
          <CardHeader>
            <CardTitle className="text-orange-800">🔧 Quick Fix for 401 Error</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm text-orange-700">
              <strong>Most likely cause:</strong> Spreadsheet not shared with service account
            </div>
            <div className="space-y-2">
              <Button
                onClick={() => window.open(`https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/edit`, '_blank')}
                className="w-full bg-orange-600 hover:bg-orange-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                1. Share Spreadsheet
              </Button>
              <div className="text-xs text-orange-600 pl-6">
                → Click "Share" → Add this email as Editor:<br />
                <div className="flex items-center gap-2 mt-1">
                  <code className="bg-orange-100 px-1 rounded text-xs">
                    attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com
                  </code>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => navigator.clipboard.writeText('attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com')}
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      );
    }

    if (result.message.includes('403')) {
      return (
        <Card className="border-red-200 bg-red-50 mt-4">
          <CardHeader>
            <CardTitle className="text-red-800">🔧 Quick Fix for 403 Error</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm text-red-700">
              <strong>Most likely cause:</strong> Google Sheets API not enabled
            </div>
            <div className="space-y-2">
              <Button
                onClick={() => window.open('https://console.cloud.google.com/apis/library/sheets.googleapis.com', '_blank')}
                className="w-full bg-red-600 hover:bg-red-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                1. Enable Google Sheets API
              </Button>
              <div className="text-xs text-red-600 pl-6">
                → Select project "satra-attendance-tracker"<br />
                → Click the blue "ENABLE" button
              </div>
            </div>
          </CardContent>
        </Card>
      );
    }

    return null;
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-yellow-500" />
          Quick API Diagnostic
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-muted-foreground">
          This will test your API key and spreadsheet access to identify the exact issue.
        </div>

        <Button
          onClick={runQuickDiagnostic}
          disabled={testing}
          className="w-full"
        >
          {testing ? 'Testing...' : 'Run Quick Diagnostic'}
        </Button>

        {result && (
          <Alert className={result.success ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
            {result.success ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <XCircle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription className={result.success ? "text-green-800" : "text-red-800"}>
              <div className="font-medium">{result.step}</div>
              <div className="text-sm mt-1">{result.message}</div>
              {result.action && (
                <div className="text-sm mt-2 font-medium">
                  → {result.action}
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        {getQuickSolution()}

        {result?.success && (
          <Card className="border-green-200 bg-green-50">
            <CardContent className="pt-6">
              <div className="text-center text-green-800">
                <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
                <div className="font-medium">🎉 API is working correctly!</div>
                <div className="text-sm mt-1">
                  You can now use the attendance tracker with live Google Sheets data.
                </div>
                <Button
                  className="mt-3"
                  onClick={() => window.location.reload()}
                >
                  Refresh App
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
}