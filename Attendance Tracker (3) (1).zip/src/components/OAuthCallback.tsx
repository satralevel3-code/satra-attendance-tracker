import React, { useEffect, useState } from 'react';
import { googleSheetsService } from '../services/GoogleSheetsService';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { CheckCircle, XCircle, Loader2, AlertTriangle } from 'lucide-react';
import { OAuth403TroubleshootingGuide } from './OAuth403TroubleshootingGuide';

interface OAuthCallbackProps {
  onSuccess: () => void;
  onError: (error: string) => void;
}

export function OAuthCallback({ onSuccess, onError }: OAuthCallbackProps) {
  const [status, setStatus] = useState<'processing' | 'success' | 'error' | 'forbidden'>('processing');
  const [message, setMessage] = useState('Processing OAuth callback...');
  const [errorDetails, setErrorDetails] = useState<string>('');

  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Get the authorization code from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const code = urlParams.get('code');
        const error = urlParams.get('error');

        if (error) {
          throw new Error(`OAuth error: ${error}`);
        }

        if (!code) {
          throw new Error('No authorization code received. The OAuth flow may have been cancelled or failed.');
        }

        setMessage('Exchanging authorization code for access token...');

        // Exchange the code for tokens
        const result = await googleSheetsService.handleOAuthCallback(code);

        if (result.success) {
          setStatus('success');
          setMessage('Successfully connected to Google Sheets!');
          setTimeout(() => {
            onSuccess();
          }, 2000);
        } else {
          throw new Error(result.error || 'Failed to exchange authorization code for tokens');
        }
      } catch (error) {
        console.error('OAuth callback error:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        
        // Check if it's a 403/access forbidden error
        if (errorMessage.toLowerCase().includes('403') || 
            errorMessage.toLowerCase().includes('forbidden') ||
            errorMessage.toLowerCase().includes('access denied')) {
          setStatus('forbidden');
          setErrorDetails(errorMessage);
          setMessage('Access Forbidden - Authentication Failed');
        } else {
          setStatus('error');
          setMessage(errorMessage);
        }
        
        onError(errorMessage);
      }
    };

    handleCallback();
  }, [onSuccess, onError]);

  const handleRetry = () => {
    window.location.href = '/'; // Redirect back to main app
  };

  const handleRetryOAuth = () => {
    // Clear current URL params and redirect to main app for OAuth retry
    window.history.replaceState({}, document.title, window.location.pathname);
    window.location.href = '/';
  };

  // Show troubleshooting guide for 403 errors
  if (status === 'forbidden') {
    return (
      <OAuth403TroubleshootingGuide
        onClose={handleRetry}
        onRetry={handleRetryOAuth}
        errorMessage={errorDetails}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2">
            {status === 'processing' && (
              <>
                <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
                Processing...
              </>
            )}
            {status === 'success' && (
              <>
                <CheckCircle className="h-5 w-5 text-green-600" />
                Success!
              </>
            )}
            {status === 'error' && (
              <>
                <XCircle className="h-5 w-5 text-red-600" />
                Error
              </>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-gray-600">{message}</p>
          
          {status === 'success' && (
            <div className="text-sm text-green-600">
              Redirecting you back to the app...
            </div>
          )}
          
          {status === 'error' && (
            <div className="space-y-3">
              <p className="text-sm text-gray-500">
                An error occurred during authentication. Please try again or contact support.
              </p>
              <div className="flex gap-2">
                <Button onClick={handleRetryOAuth} variant="outline" className="flex-1">
                  Try Again
                </Button>
                <Button onClick={handleRetry} className="flex-1">
                  Return to App
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}