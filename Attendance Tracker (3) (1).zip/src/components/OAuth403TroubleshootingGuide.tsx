import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, AlertTriangle, ExternalLink, Copy, RefreshCw } from 'lucide-react';
import { googleSheetsService } from '../services/GoogleSheetsService';

interface OAuth403TroubleshootingGuideProps {
  onRetry?: () => void;
  onBack?: () => void;
}

export function OAuth403TroubleshootingGuide({ onRetry, onBack }: OAuth403TroubleshootingGuideProps) {
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionResult, setConnectionResult] = useState<{
    success: boolean;
    error?: string;
  } | null>(null);

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setConnectionResult(null);
    
    try {
      const result = await googleSheetsService.testConnection();
      setConnectionResult(result);
    } catch (error) {
      setConnectionResult({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const troubleshootingSteps = [
    {
      title: "Step 1: Enable Google Sheets API",
      status: "critical",
      description: "The most common cause of 403 errors is that Google Sheets API is not enabled for your project.",
      action: (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            1. Go to <a href="https://console.cloud.google.com/apis/library/sheets.googleapis.com" target="_blank" className="text-primary hover:underline inline-flex items-center gap-1">
              Google Cloud Console APIs <ExternalLink size={14} />
            </a>
          </p>
          <p className="text-sm text-muted-foreground">
            2. Make sure your project "satra-attendance-tracker" is selected
          </p>
          <p className="text-sm text-muted-foreground">
            3. Click "ENABLE" for Google Sheets API
          </p>
          <p className="text-sm text-muted-foreground">
            4. Also enable Google Drive API (required for spreadsheet access)
          </p>
        </div>
      )
    },
    {
      title: "Step 2: Check API Key Restrictions",
      status: "warning",
      description: "Your API key might have restrictions that prevent access to Google Sheets.",
      action: (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            1. Go to <a href="https://console.cloud.google.com/apis/credentials" target="_blank" className="text-primary hover:underline inline-flex items-center gap-1">
              Google Cloud Console Credentials <ExternalLink size={14} />
            </a>
          </p>
          <p className="text-sm text-muted-foreground">
            2. Find your API key: AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8
          </p>
          <div className="flex items-center gap-2">
            <code className="bg-muted px-2 py-1 rounded text-sm">AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8</code>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => copyToClipboard('AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8')}
            >
              <Copy size={14} />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            3. Click "Edit" on your API key
          </p>
          <p className="text-sm text-muted-foreground">
            4. Under "API restrictions", either select "Don't restrict key" or make sure these APIs are allowed:
          </p>
          <ul className="text-sm text-muted-foreground ml-4 space-y-1">
            <li>• Google Sheets API</li>
            <li>• Google Drive API</li>
          </ul>
        </div>
      )
    },
    {
      title: "Step 3: Verify Spreadsheet Access",
      status: "info",
      description: "Make sure your spreadsheet is accessible and the service account has the right permissions.",
      action: (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            1. Open your spreadsheet: 
          </p>
          <div className="flex items-center gap-2">
            <a 
              href="https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY/edit" 
              target="_blank" 
              className="text-primary hover:underline inline-flex items-center gap-1 text-sm"
            >
              Satra Attendance Tracker <ExternalLink size={14} />
            </a>
          </div>
          <p className="text-sm text-muted-foreground">
            2. Click "Share" in the top right corner
          </p>
          <p className="text-sm text-muted-foreground">
            3. Make sure this service account email has Editor access:
          </p>
          <div className="flex items-center gap-2">
            <code className="bg-muted px-2 py-1 rounded text-sm">attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com</code>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => copyToClipboard('attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com')}
            >
              <Copy size={14} />
            </Button>
          </div>
        </div>
      )
    },
    {
      title: "Step 4: Alternative - Make Spreadsheet Public",
      status: "info",
      description: "As a temporary solution, you can make the spreadsheet publicly viewable.",
      action: (
        <div className="space-y-3">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Only do this if you're comfortable with the spreadsheet being publicly accessible.
            </AlertDescription>
          </Alert>
          <p className="text-sm text-muted-foreground">
            1. In your spreadsheet, click "Share" → "Change to anyone with the link"
          </p>
          <p className="text-sm text-muted-foreground">
            2. Set permission to "Viewer" or "Editor"
          </p>
          <p className="text-sm text-muted-foreground">
            3. Copy the shareable link (it should look like: https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY/edit?usp=sharing)
          </p>
        </div>
      )
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'critical':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'info':
        return <CheckCircle className="w-5 h-5 text-blue-500" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'critical':
        return <Badge variant="destructive">Critical</Badge>;
      case 'warning':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Important</Badge>;
      case 'info':
        return <Badge variant="secondary">Optional</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <XCircle className="w-8 h-8 text-red-500" />
            <h1 className="text-3xl font-bold text-primary">403 Permission Error</h1>
          </div>
          <p className="text-muted-foreground text-lg">
            Google Sheets API access denied. Follow these steps to fix the issue.
          </p>
        </div>

        {/* Current Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              Current Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Alert>
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>HTTP 403:</strong> API key lacks necessary permissions for Google Sheets
                </AlertDescription>
              </Alert>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <strong>Project:</strong> satra-attendance-tracker
                </div>
                <div>
                  <strong>API Key:</strong> AIzaSyDvM...A8 ✓
                </div>
                <div>
                  <strong>Service Account:</strong> attendance-tracker-service@...
                </div>
                <div>
                  <strong>Spreadsheet ID:</strong> 1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY
                </div>
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={handleTestConnection}
                  disabled={testingConnection}
                  variant="outline"
                >
                  {testingConnection ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Testing...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Test Connection
                    </>
                  )}
                </Button>
                
                {onBack && (
                  <Button variant="outline" onClick={onBack}>
                    ← Back to Dashboard
                  </Button>
                )}
              </div>

              {connectionResult && (
                <Alert className={connectionResult.success ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
                  {connectionResult.success ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600" />
                  )}
                  <AlertDescription className={connectionResult.success ? "text-green-800" : "text-red-800"}>
                    {connectionResult.success 
                      ? (
                        <div>
                          ✅ Connection successful! The issue has been resolved.
                          <Button 
                            className="ml-3" 
                            size="sm"
                            onClick={() => {
                              localStorage.removeItem('google_sheets_403_error');
                              localStorage.removeItem('403_banner_dismissed');
                              if (onBack) onBack();
                            }}
                          >
                            Return to Dashboard
                          </Button>
                        </div>
                      )
                      : `❌ Still failing: ${connectionResult.error}`
                    }
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Troubleshooting Steps */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-primary">Troubleshooting Steps</h2>
          
          {troubleshootingSteps.map((step, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(step.status)}
                    {step.title}
                  </div>
                  {getStatusBadge(step.status)}
                </CardTitle>
                <CardDescription>{step.description}</CardDescription>
              </CardHeader>
              <CardContent>
                {step.action}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Links */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Access Links</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <a 
                href="https://console.cloud.google.com/apis/library/sheets.googleapis.com" 
                target="_blank"
                className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <ExternalLink size={16} />
                <span>Enable Google Sheets API</span>
              </a>
              
              <a 
                href="https://console.cloud.google.com/apis/credentials" 
                target="_blank"
                className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <ExternalLink size={16} />
                <span>Manage API Keys</span>
              </a>
              
              <a 
                href="https://docs.google.com/spreadsheets/d/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY/edit" 
                target="_blank"
                className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <ExternalLink size={16} />
                <span>Open Spreadsheet</span>
              </a>
              
              <a 
                href="https://console.cloud.google.com/iam-admin/serviceaccounts" 
                target="_blank"
                className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <ExternalLink size={16} />
                <span>Service Accounts</span>
              </a>
            </div>
          </CardContent>
        </Card>

        {/* Debug Information */}
        <Card>
          <CardHeader>
            <CardTitle>Debug Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <strong>Project ID:</strong> satra-attendance-tracker
              </div>
              <div>
                <strong>API Key (last 4):</strong> ...sA8
              </div>
              <div>
                <strong>Spreadsheet ID:</strong> 1e70hH9W...djmY
              </div>
              <div>
                <strong>Service Account:</strong> attendance-tracker-service@...
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <strong>Test URL:</strong>
              <br />
              <code className="text-xs break-all">
                https://sheets.googleapis.com/v4/spreadsheets/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY?key=AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8
              </code>
              <Button 
                size="sm" 
                variant="outline" 
                className="ml-2"
                onClick={() => window.open('https://sheets.googleapis.com/v4/spreadsheets/1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY?key=AIzaSyDvMYgl6RS9sCdnJhlhitOoOgoYegGPsA8', '_blank')}
              >
                Test in Browser
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Note */}
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Note:</strong> Changes to API settings may take a few minutes to take effect. 
            After making changes, wait 2-3 minutes before testing the connection again.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}