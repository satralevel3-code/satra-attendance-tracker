# Google Sheets API Key Setup Guide

## ❌ Current Issue
Your app is configured with an invalid API key: `AQ.Ab8RN6IpPxgdD-5Ak5pwe50-q4Rg0OMghtIHet22t23MtmRLkg`

This key format is **not valid** for Google Sheets API. Google Sheets API keys must:
- Start with "AIza"
- Be exactly 39 characters long
- Have Google Sheets API enabled

## ✅ How to Fix This

### Step 1: Go to Google Cloud Console
1. Visit: https://console.cloud.google.com/apis/credentials
2. Make sure you're in the correct project: `satra-attendance-tracker`

### Step 2: Create a New API Key
1. Click **"Create Credentials"** 
2. Select **"API Key"**
3. A new API key will be generated (should start with "AIza")
4. **Copy this key immediately** - you'll need it later

### Step 3: Restrict the API Key (Recommended)
1. Click **"Restrict Key"** on the newly created key
2. Under **"API restrictions"**, select **"Restrict key"**
3. Choose **"Google Sheets API"** from the dropdown
4. Click **"Save"**

### Step 4: Update Your App Configuration
1. Copy the new API key (starts with "AIza")
2. In your GoogleSheetsService.ts file, replace:
   ```typescript
   private readonly API_KEY = 'YOUR_GOOGLE_SHEETS_API_KEY_HERE';
   ```
   with:
   ```typescript
   private readonly API_KEY = 'AIzaSyYourActualApiKeyHere...';
   ```

## 🔑 Valid API Key Example
```
AIzaSyAbc123def456ghi789jkl012mno345pqr6789
^^^^^                                    ^^^^^
Starts with "AIza"                    39 chars total
```

## 🛡️ Alternative: Use Service Account Authentication

Since you already have a service account (`attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com`), you could also use service account authentication which is more secure:

### Service Account Setup (Advanced)
1. Go to: https://console.cloud.google.com/iam-admin/serviceaccounts
2. Find your service account: `attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com`
3. Click on it → "Keys" tab → "Add Key" → "Create new key"
4. Choose "JSON" format
5. Download the JSON key file
6. Use this file for server-side authentication (more complex setup)

## 🔄 Quick Test
Once you have a valid API key:
1. Update the GoogleSheetsService.ts file
2. Refresh your app
3. Check the browser console for connection test results
4. You should see: "✅ Google Sheets connection test successful!"

## 📞 Current Configuration
- **OAuth Client ID:** `43302794729-ng4b6gp6n5ga6lohvd9fptlblof3ta3r.apps.googleusercontent.com` ✅
- **Service Account:** `attendance-tracker-service@satra-attendance-tracker.iam.gserviceaccount.com` ✅  
- **Spreadsheet ID:** `1e70hH9WsP37EzzeLpC7dYFGMcylf1AKPCkeRotndjmY` ✅
- **API Key:** `AQ.Ab8RN6IpPxgdD...` ❌ **INVALID FORMAT**

## 🎯 Next Steps
1. **Create a valid Google Sheets API key** (highest priority)
2. Update your app configuration
3. Test the connection
4. Your attendance tracker will then connect to the real Google Sheet!

The key you provided (`AQ.Ab8RN6IpPxgdD...`) might be from a different Google service or an older format that's no longer supported. You need a fresh Google Sheets API key from the Google Cloud Console.