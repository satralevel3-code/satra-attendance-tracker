/**
 * Timezone Utility for Indian Standard Time (IST)
 * IST is UTC+5:30
 */

/**
 * Get current date in IST format (YYYY-MM-DD)
 */
export function getCurrentDateIST(): string {
  // Create a date in IST timezone
  const now = new Date();
  const istOffset = 5.5 * 60 * 60 * 1000; // IST is UTC+5:30
  const istTime = new Date(now.getTime() + istOffset);
  
  // Use toLocaleDateString with Asia/Kolkata timezone
  const options: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  };
  
  const parts = new Intl.DateTimeFormat('en-CA', options).format(now);
  return parts; // Returns YYYY-MM-DD format
}

/**
 * Get current timestamp in IST
 */
export function getCurrentTimestampIST(): string {
  const now = new Date();
  
  // Format in IST timezone
  return now.toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
}

/**
 * Get current Date object in IST
 */
export function getCurrentDateObjectIST(): Date {
  const now = new Date();
  
  // Convert to IST by formatting and parsing back
  const istString = now.toLocaleString('en-US', {
    timeZone: 'Asia/Kolkata'
  });
  
  return new Date(istString);
}

/**
 * Format date to IST string
 */
export function formatDateIST(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  
  return d.toLocaleDateString('en-IN', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

/**
 * Format time to IST string
 */
export function formatTimeIST(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  
  return d.toLocaleTimeString('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });
}

/**
 * Format date and time to IST string
 */
export function formatDateTimeIST(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  
  return d.toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });
}

/**
 * Get date string in YYYY-MM-DD format from any date
 */
export function getDateStringIST(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  
  // Format using IST timezone
  const year = d.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', year: 'numeric' });
  const month = d.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', month: '2-digit' });
  const day = d.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit' });
  
  // Ensure proper format
  const monthNum = month.padStart(2, '0');
  const dayNum = day.padStart(2, '0');
  
  return `${year}-${monthNum}-${dayNum}`;
}

/**
 * Check if a date is today in IST
 */
export function isTodayIST(date: Date | string): boolean {
  const dateStr = getDateStringIST(date);
  const todayStr = getCurrentDateIST();
  return dateStr === todayStr;
}