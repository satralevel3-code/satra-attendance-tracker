/**
 * Error Handling Utilities
 * Provides comprehensive error handling, logging, and recovery mechanisms
 */

export enum ErrorSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

export enum ErrorCategory {
  NETWORK = 'network',
  VALIDATION = 'validation',
  AUTHENTICATION = 'authentication',
  AUTHORIZATION = 'authorization',
  DATA = 'data',
  BUSINESS_LOGIC = 'business_logic',
  SYSTEM = 'system',
  UNKNOWN = 'unknown'
}

export interface AppError {
  id: string;
  message: string;
  category: ErrorCategory;
  severity: ErrorSeverity;
  timestamp: string;
  stack?: string;
  context?: Record<string, any>;
  userFriendlyMessage?: string;
  recoverySuggestions?: string[];
}

/**
 * Error Logger
 */
export class ErrorLogger {
  private static errors: AppError[] = [];
  private static readonly MAX_ERRORS = 100;
  private static readonly STORAGE_KEY = 'app_error_logs';

  static log(error: Error | AppError | string, context?: Record<string, any>): AppError {
    const appError = this.normalizeError(error, context);
    
    // Add to in-memory store
    this.errors.unshift(appError);
    if (this.errors.length > this.MAX_ERRORS) {
      this.errors.pop();
    }

    // Persist to localStorage
    this.persistErrors();

    // Log to console based on severity
    this.consoleLog(appError);

    // In production, send to monitoring service
    if (appError.severity === ErrorSeverity.CRITICAL || appError.severity === ErrorSeverity.HIGH) {
      this.reportToMonitoring(appError);
    }

    return appError;
  }

  private static normalizeError(error: Error | AppError | string, context?: Record<string, any>): AppError {
    if (typeof error === 'string') {
      return this.createAppError(error, ErrorCategory.UNKNOWN, ErrorSeverity.MEDIUM, context);
    }

    if ('category' in error && 'severity' in error) {
      return error as AppError;
    }

    // Standard Error object
    const standardError = error as Error;
    const category = this.categorizeError(standardError);
    const severity = this.assessSeverity(standardError, category);

    return this.createAppError(
      standardError.message,
      category,
      severity,
      { ...context, stack: standardError.stack }
    );
  }

  private static createAppError(
    message: string,
    category: ErrorCategory,
    severity: ErrorSeverity,
    context?: Record<string, any>
  ): AppError {
    const error: AppError = {
      id: this.generateId(),
      message,
      category,
      severity,
      timestamp: new Date().toISOString(),
      context,
      stack: context?.stack,
      userFriendlyMessage: this.getUserFriendlyMessage(category, message),
      recoverySuggestions: this.getRecoverySuggestions(category)
    };

    return error;
  }

  private static categorizeError(error: Error): ErrorCategory {
    const message = error.message.toLowerCase();

    if (message.includes('network') || message.includes('fetch') || message.includes('timeout')) {
      return ErrorCategory.NETWORK;
    }
    if (message.includes('unauthorized') || message.includes('401')) {
      return ErrorCategory.AUTHENTICATION;
    }
    if (message.includes('forbidden') || message.includes('403')) {
      return ErrorCategory.AUTHORIZATION;
    }
    if (message.includes('validation') || message.includes('invalid')) {
      return ErrorCategory.VALIDATION;
    }
    if (message.includes('not found') || message.includes('404')) {
      return ErrorCategory.DATA;
    }

    return ErrorCategory.UNKNOWN;
  }

  private static assessSeverity(error: Error, category: ErrorCategory): ErrorSeverity {
    if (category === ErrorCategory.AUTHENTICATION || category === ErrorCategory.AUTHORIZATION) {
      return ErrorSeverity.HIGH;
    }
    if (category === ErrorCategory.NETWORK) {
      return ErrorSeverity.MEDIUM;
    }
    if (category === ErrorCategory.VALIDATION) {
      return ErrorSeverity.LOW;
    }
    return ErrorSeverity.MEDIUM;
  }

  private static getUserFriendlyMessage(category: ErrorCategory, originalMessage: string): string {
    const messages: Record<ErrorCategory, string> = {
      [ErrorCategory.NETWORK]: 'Unable to connect to the server. Please check your internet connection.',
      [ErrorCategory.AUTHENTICATION]: 'Session expired. Please log in again.',
      [ErrorCategory.AUTHORIZATION]: 'You don\'t have permission to perform this action.',
      [ErrorCategory.VALIDATION]: 'Please check your input and try again.',
      [ErrorCategory.DATA]: 'The requested data could not be found.',
      [ErrorCategory.BUSINESS_LOGIC]: 'This action cannot be completed at the moment.',
      [ErrorCategory.SYSTEM]: 'A system error occurred. Please try again later.',
      [ErrorCategory.UNKNOWN]: 'An unexpected error occurred. Please try again.'
    };

    return messages[category] || originalMessage;
  }

  private static getRecoverySuggestions(category: ErrorCategory): string[] {
    const suggestions: Record<ErrorCategory, string[]> = {
      [ErrorCategory.NETWORK]: [
        'Check your internet connection',
        'Try refreshing the page',
        'Wait a moment and try again'
      ],
      [ErrorCategory.AUTHENTICATION]: [
        'Log out and log in again',
        'Clear your browser cache',
        'Contact support if the issue persists'
      ],
      [ErrorCategory.AUTHORIZATION]: [
        'Contact your administrator for access',
        'Verify you have the correct permissions'
      ],
      [ErrorCategory.VALIDATION]: [
        'Review the form for errors',
        'Ensure all required fields are filled',
        'Check that values are in the correct format'
      ],
      [ErrorCategory.DATA]: [
        'Try searching with different criteria',
        'Contact support if data should exist'
      ],
      [ErrorCategory.BUSINESS_LOGIC]: [
        'Review the action requirements',
        'Contact support for assistance'
      ],
      [ErrorCategory.SYSTEM]: [
        'Refresh the page',
        'Try again in a few minutes',
        'Contact support if the issue persists'
      ],
      [ErrorCategory.UNKNOWN]: [
        'Try refreshing the page',
        'Contact support with error details'
      ]
    };

    return suggestions[category] || suggestions[ErrorCategory.UNKNOWN];
  }

  private static consoleLog(error: AppError): void {
    const emoji = {
      [ErrorSeverity.LOW]: '⚠️',
      [ErrorSeverity.MEDIUM]: '🔶',
      [ErrorSeverity.HIGH]: '🔴',
      [ErrorSeverity.CRITICAL]: '💥'
    };

    console.group(`${emoji[error.severity]} [${error.severity.toUpperCase()}] ${error.category}`);
    console.error(error.message);
    if (error.context) {
      console.log('Context:', error.context);
    }
    if (error.stack) {
      console.log('Stack:', error.stack);
    }
    console.groupEnd();
  }

  private static reportToMonitoring(error: AppError): void {
    // In production, integrate with services like Sentry, LogRocket, etc.
    console.log('📊 Reporting to monitoring service:', error.id);
  }

  private static persistErrors(): void {
    try {
      const recentErrors = this.errors.slice(0, 50);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(recentErrors));
    } catch (error) {
      console.error('Failed to persist errors:', error);
    }
  }

  private static generateId(): string {
    return `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  static getErrors(filter?: {
    category?: ErrorCategory;
    severity?: ErrorSeverity;
    since?: Date;
  }): AppError[] {
    let filtered = [...this.errors];

    if (filter) {
      if (filter.category) {
        filtered = filtered.filter(e => e.category === filter.category);
      }
      if (filter.severity) {
        filtered = filtered.filter(e => e.severity === filter.severity);
      }
      if (filter.since) {
        filtered = filtered.filter(e => new Date(e.timestamp) >= filter.since!);
      }
    }

    return filtered;
  }

  static clearErrors(): void {
    this.errors = [];
    localStorage.removeItem(this.STORAGE_KEY);
  }

  static init(): void {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        this.errors = JSON.parse(stored);
      }
    } catch (error) {
      console.error('Failed to load stored errors:', error);
    }
  }
}

/**
 * Retry Handler with Exponential Backoff
 */
export interface RetryOptions {
  maxAttempts?: number;
  initialDelayMs?: number;
  maxDelayMs?: number;
  backoffMultiplier?: number;
  retryableErrors?: string[];
  onRetry?: (attempt: number, error: Error) => void;
}

export class RetryHandler {
  static async execute<T>(
    operation: () => Promise<T>,
    options: RetryOptions = {}
  ): Promise<T> {
    const {
      maxAttempts = 3,
      initialDelayMs = 1000,
      maxDelayMs = 10000,
      backoffMultiplier = 2,
      retryableErrors = ['network', 'timeout', 'fetch'],
      onRetry
    } = options;

    let lastError: Error = new Error('Unknown error');
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        const isRetryable = retryableErrors.some(pattern => 
          lastError.message.toLowerCase().includes(pattern)
        );

        if (!isRetryable || attempt === maxAttempts) {
          throw lastError;
        }

        const delay = Math.min(
          initialDelayMs * Math.pow(backoffMultiplier, attempt - 1),
          maxDelayMs
        );

        console.log(`Retry attempt ${attempt}/${maxAttempts} after ${delay}ms`);
        
        if (onRetry) {
          onRetry(attempt, lastError);
        }

        await this.delay(delay);
      }
    }

    throw lastError;
  }

  private static delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

/**
 * Circuit Breaker Pattern
 */
export enum CircuitState {
  CLOSED = 'closed',
  OPEN = 'open',
  HALF_OPEN = 'half_open'
}

export interface CircuitBreakerOptions {
  failureThreshold?: number;
  successThreshold?: number;
  timeout?: number;
  resetTimeoutMs?: number;
}

export class CircuitBreaker {
  private state: CircuitState = CircuitState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private nextAttemptTime = 0;

  constructor(
    private name: string,
    private options: CircuitBreakerOptions = {}
  ) {
    this.options = {
      failureThreshold: 5,
      successThreshold: 2,
      timeout: 30000,
      resetTimeoutMs: 60000,
      ...options
    };
  }

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === CircuitState.OPEN) {
      if (Date.now() < this.nextAttemptTime) {
        throw new Error(`Circuit breaker [${this.name}] is OPEN. Retrying at ${new Date(this.nextAttemptTime).toISOString()}`);
      }
      this.state = CircuitState.HALF_OPEN;
      this.successCount = 0;
    }

    try {
      const result = await this.executeWithTimeout(operation);
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private async executeWithTimeout<T>(operation: () => Promise<T>): Promise<T> {
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error('Operation timeout')), this.options.timeout);
    });

    return Promise.race([operation(), timeoutPromise]);
  }

  private onSuccess(): void {
    this.failureCount = 0;

    if (this.state === CircuitState.HALF_OPEN) {
      this.successCount++;
      if (this.successCount >= this.options.successThreshold!) {
        this.state = CircuitState.CLOSED;
        this.successCount = 0;
        console.log(`Circuit breaker [${this.name}] is now CLOSED`);
      }
    }
  }

  private onFailure(): void {
    this.failureCount++;
    this.successCount = 0;

    if (this.failureCount >= this.options.failureThreshold!) {
      this.state = CircuitState.OPEN;
      this.nextAttemptTime = Date.now() + this.options.resetTimeoutMs!;
      console.error(`Circuit breaker [${this.name}] is now OPEN until ${new Date(this.nextAttemptTime).toISOString()}`);
    }
  }

  getState(): CircuitState {
    return this.state;
  }

  reset(): void {
    this.state = CircuitState.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
    this.nextAttemptTime = 0;
  }
}

/**
 * Global Error Handler
 */
export const initializeGlobalErrorHandlers = (): void => {
  // Initialize error logger
  ErrorLogger.init();

  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    ErrorLogger.log(event.reason, {
      type: 'unhandled_rejection',
      promise: event.promise
    });
    event.preventDefault();
  });

  // Handle global errors
  window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    ErrorLogger.log(event.error || event.message, {
      type: 'global_error',
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno
    });
  });

  console.log('✅ Global error handlers initialized');
};

/**
 * Graceful Degradation Helper
 */
export class GracefulDegradation {
  private static fallbacks: Map<string, () => any> = new Map();

  static registerFallback(feature: string, fallbackFn: () => any): void {
    this.fallbacks.set(feature, fallbackFn);
  }

  static async tryWithFallback<T>(
    feature: string,
    primaryFn: () => Promise<T>
  ): Promise<T> {
    try {
      return await primaryFn();
    } catch (error) {
      console.warn(`Feature [${feature}] failed, attempting fallback`);
      ErrorLogger.log(error as Error, { feature, fallback: true });
      
      const fallback = this.fallbacks.get(feature);
      if (fallback) {
        return fallback();
      }
      
      throw error;
    }
  }
}

/**
 * Export commonly used error types
 */
export class NetworkError extends Error {
  constructor(message: string, public statusCode?: number) {
    super(message);
    this.name = 'NetworkError';
  }
}

export class ValidationError extends Error {
  constructor(message: string, public field?: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export class AuthenticationError extends Error {
  constructor(message: string = 'Authentication required') {
    super(message);
    this.name = 'AuthenticationError';
  }
}

export class AuthorizationError extends Error {
  constructor(message: string = 'Permission denied') {
    super(message);
    this.name = 'AuthorizationError';
  }
}