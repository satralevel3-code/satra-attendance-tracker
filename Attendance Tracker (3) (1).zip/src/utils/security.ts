/**
 * Security Utilities
 * Provides client-side security helpers for input validation, sanitization, and protection
 */

/**
 * Input Sanitization - XSS Protection
 */
export const sanitizeInput = (input: string): string => {
  const div = document.createElement('div');
  div.textContent = input;
  return div.innerHTML;
};

export const sanitizeHtml = (html: string): string => {
  const allowedTags = ['b', 'i', 'em', 'strong', 'p', 'br'];
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  const removeDisallowedTags = (node: Node) => {
    if (node.nodeType === Node.ELEMENT_NODE) {
      const element = node as Element;
      if (!allowedTags.includes(element.tagName.toLowerCase())) {
        element.replaceWith(...Array.from(element.childNodes));
      }
      // Remove all attributes to prevent XSS
      Array.from(element.attributes).forEach(attr => {
        element.removeAttribute(attr.name);
      });
    }
    Array.from(node.childNodes).forEach(removeDisallowedTags);
  };
  
  removeDisallowedTags(doc.body);
  return doc.body.innerHTML;
};

/**
 * Password Validation
 */
export interface PasswordStrength {
  score: number; // 0-4
  feedback: string[];
  isStrong: boolean;
}

export const validatePasswordStrength = (password: string): PasswordStrength => {
  const feedback: string[] = [];
  let score = 0;

  if (password.length === 0) {
    return { score: 0, feedback: ['Password is required'], isStrong: false };
  }

  // Length check
  if (password.length >= 8) {
    score++;
  } else {
    feedback.push('Password should be at least 8 characters');
  }

  // Uppercase check
  if (/[A-Z]/.test(password)) {
    score++;
  } else {
    feedback.push('Include at least one uppercase letter');
  }

  // Lowercase check
  if (/[a-z]/.test(password)) {
    score++;
  } else {
    feedback.push('Include at least one lowercase letter');
  }

  // Number check
  if (/\d/.test(password)) {
    score++;
  } else {
    feedback.push('Include at least one number');
  }

  // Special character check
  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    score++;
  } else {
    feedback.push('Include at least one special character');
  }

  // Common passwords check
  const commonPasswords = ['password', '123456', 'qwerty', 'abc123', 'password123'];
  if (commonPasswords.some(common => password.toLowerCase().includes(common))) {
    score = Math.max(0, score - 2);
    feedback.push('Avoid common password patterns');
  }

  return {
    score: Math.min(score, 4),
    feedback,
    isStrong: score >= 4
  };
};

/**
 * Employee ID Validation
 */
export const validateEmployeeId = (employeeId: string): { valid: boolean; error?: string } => {
  const sanitized = sanitizeInput(employeeId.trim());
  
  if (!sanitized) {
    return { valid: false, error: 'Employee ID is required' };
  }
  
  if (sanitized.length < 3) {
    return { valid: false, error: 'Employee ID must be at least 3 characters' };
  }
  
  if (sanitized.length > 20) {
    return { valid: false, error: 'Employee ID must be less than 20 characters' };
  }
  
  // Only allow alphanumeric and basic special characters
  if (!/^[a-zA-Z0-9_-]+$/.test(sanitized)) {
    return { valid: false, error: 'Employee ID can only contain letters, numbers, hyphens, and underscores' };
  }
  
  return { valid: true };
};

/**
 * Email Validation
 */
export const validateEmail = (email: string): { valid: boolean; error?: string } => {
  const sanitized = sanitizeInput(email.trim().toLowerCase());
  
  if (!sanitized) {
    return { valid: false, error: 'Email is required' };
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(sanitized)) {
    return { valid: false, error: 'Invalid email format' };
  }
  
  return { valid: true };
};

/**
 * Phone Number Validation (Indian format)
 */
export const validatePhoneNumber = (phone: string): { valid: boolean; error?: string } => {
  const sanitized = phone.replace(/\s+/g, '').replace(/[-()+]/g, '');
  
  if (!sanitized) {
    return { valid: false, error: 'Phone number is required' };
  }
  
  // Indian phone number format: +91XXXXXXXXXX or 10 digits
  const indianPhoneRegex = /^(?:\+91|91)?[6-9]\d{9}$/;
  if (!indianPhoneRegex.test(sanitized)) {
    return { valid: false, error: 'Invalid Indian phone number format' };
  }
  
  return { valid: true };
};

/**
 * Rate Limiting Helper (Client-side)
 */
interface RateLimitConfig {
  maxAttempts: number;
  windowMs: number;
  keyPrefix: string;
}

export class ClientRateLimiter {
  private attempts: Map<string, { count: number; resetTime: number }> = new Map();

  constructor(private config: RateLimitConfig) {}

  canProceed(identifier: string): boolean {
    const key = `${this.config.keyPrefix}:${identifier}`;
    const now = Date.now();
    const record = this.attempts.get(key);

    if (!record || now > record.resetTime) {
      this.attempts.set(key, {
        count: 1,
        resetTime: now + this.config.windowMs
      });
      return true;
    }

    if (record.count >= this.config.maxAttempts) {
      return false;
    }

    record.count++;
    return true;
  }

  getRemainingTime(identifier: string): number {
    const key = `${this.config.keyPrefix}:${identifier}`;
    const record = this.attempts.get(key);
    
    if (!record) return 0;
    
    const remaining = record.resetTime - Date.now();
    return remaining > 0 ? remaining : 0;
  }

  reset(identifier: string): void {
    const key = `${this.config.keyPrefix}:${identifier}`;
    this.attempts.delete(key);
  }
}

/**
 * Secure Storage Wrapper
 * Provides encrypted local storage with fallback
 */
export class SecureStorage {
  private static encode(value: string): string {
    try {
      return btoa(encodeURIComponent(value));
    } catch {
      return value;
    }
  }

  private static decode(value: string): string {
    try {
      return decodeURIComponent(atob(value));
    } catch {
      return value;
    }
  }

  static setItem(key: string, value: any, encrypt: boolean = true): void {
    try {
      const stringValue = typeof value === 'string' ? value : JSON.stringify(value);
      const storedValue = encrypt ? this.encode(stringValue) : stringValue;
      localStorage.setItem(key, storedValue);
    } catch (error) {
      console.error('SecureStorage.setItem error:', error);
    }
  }

  static getItem<T = string>(key: string, decrypt: boolean = true): T | null {
    try {
      const value = localStorage.getItem(key);
      if (!value) return null;
      
      const decodedValue = decrypt ? this.decode(value) : value;
      
      try {
        return JSON.parse(decodedValue) as T;
      } catch {
        return decodedValue as T;
      }
    } catch (error) {
      console.error('SecureStorage.getItem error:', error);
      return null;
    }
  }

  static removeItem(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('SecureStorage.removeItem error:', error);
    }
  }

  static clear(): void {
    try {
      localStorage.clear();
    } catch (error) {
      console.error('SecureStorage.clear error:', error);
    }
  }
}

/**
 * CSRF Token Helper
 */
export class CSRFTokenManager {
  private static TOKEN_KEY = 'csrf_token';
  private static TOKEN_HEADER = 'X-CSRF-Token';

  static generateToken(): string {
    const token = Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    
    SecureStorage.setItem(this.TOKEN_KEY, token);
    return token;
  }

  static getToken(): string | null {
    let token = SecureStorage.getItem(this.TOKEN_KEY);
    if (!token) {
      token = this.generateToken();
    }
    return token;
  }

  static getHeaders(): Record<string, string> {
    const token = this.getToken();
    return token ? { [this.TOKEN_HEADER]: token } : {};
  }

  static validateToken(token: string): boolean {
    const storedToken = this.getToken();
    return storedToken === token;
  }

  static refreshToken(): string {
    SecureStorage.removeItem(this.TOKEN_KEY);
    return this.generateToken();
  }
}

/**
 * Content Security Policy Helper
 */
export const CSPViolationReporter = {
  init() {
    if (typeof window !== 'undefined') {
      window.addEventListener('securitypolicyviolation', (e) => {
        console.error('CSP Violation:', {
          blockedURI: e.blockedURI,
          violatedDirective: e.violatedDirective,
          originalPolicy: e.originalPolicy,
          documentURI: e.documentURI,
          lineNumber: e.lineNumber,
          columnNumber: e.columnNumber
        });
        
        // Log to monitoring service in production
        this.reportViolation({
          type: 'csp_violation',
          blockedURI: e.blockedURI,
          directive: e.violatedDirective,
          timestamp: new Date().toISOString()
        });
      });
    }
  },

  reportViolation(violation: Record<string, any>) {
    // In production, send to monitoring service
    // For now, just log to console and localStorage
    try {
      const violations = JSON.parse(localStorage.getItem('csp_violations') || '[]');
      violations.push(violation);
      // Keep only last 50 violations
      const recentViolations = violations.slice(-50);
      localStorage.setItem('csp_violations', JSON.stringify(recentViolations));
    } catch (error) {
      console.error('Failed to log CSP violation:', error);
    }
  }
};

/**
 * Input Validation Helpers
 */
export const validators = {
  isNotEmpty: (value: string) => value.trim().length > 0,
  isLength: (value: string, min: number, max?: number) => {
    const len = value.length;
    return len >= min && (!max || len <= max);
  },
  isAlphanumeric: (value: string) => /^[a-zA-Z0-9]+$/.test(value),
  isNumeric: (value: string) => /^\d+$/.test(value),
  isLatitude: (value: number) => value >= -90 && value <= 90,
  isLongitude: (value: number) => value >= -180 && value <= 180,
};

/**
 * File Upload Validation
 */
export const validateFileUpload = (
  file: File,
  options: {
    maxSizeMB?: number;
    allowedTypes?: string[];
    allowedExtensions?: string[];
  } = {}
): { valid: boolean; error?: string } => {
  const {
    maxSizeMB = 5,
    allowedTypes = ['image/jpeg', 'image/png', 'image/webp'],
    allowedExtensions = ['.jpg', '.jpeg', '.png', '.webp']
  } = options;

  // Check file size
  const maxSizeBytes = maxSizeMB * 1024 * 1024;
  if (file.size > maxSizeBytes) {
    return {
      valid: false,
      error: `File size must be less than ${maxSizeMB}MB`
    };
  }

  // Check file type
  if (!allowedTypes.includes(file.type)) {
    return {
      valid: false,
      error: `File type must be one of: ${allowedTypes.join(', ')}`
    };
  }

  // Check file extension
  const extension = '.' + file.name.split('.').pop()?.toLowerCase();
  if (!allowedExtensions.includes(extension)) {
    return {
      valid: false,
      error: `File extension must be one of: ${allowedExtensions.join(', ')}`
    };
  }

  return { valid: true };
};