// Production data for the Attendance Tracker App
// This file contains organizational data and fallback records

export const sampleEmployees = [
  {
    employeeId: 'SAT001',
    name: 'Rajesh Kumar',
    designation: 'Regional Manager',
    department: 'Gujarat North',
    reportingManager: 'SURESH PATEL',
    phoneNumber: '+91 98765 43210',
    email: 'rajesh.kumar@satraservices.com',
    workLocations: ['Ahmedabad', 'Gandhinagar'],
    status: 'active',
    password: 'test123'
  },
  {
    employeeId: 'SAT002',
    name: 'Priya Patel',
    designation: 'Area Executive',
    department: 'Gujarat Central',
    reportingManager: 'RAJESH KUMAR',
    phoneNumber: '+91 98765 43211',
    email: 'priya.patel@satraservices.com',
    workLocations: ['Surat', 'Navsari'],
    status: 'active',
    password: 'test123'
  },
  {
    employeeId: 'SAT003',
    name: 'Amit Shah',
    designation: 'Field Executive',
    department: 'Gujarat West',
    reportingManager: 'PRIYA PATEL',
    phoneNumber: '+91 98765 43212',
    email: 'amit.shah@satraservices.com',
    workLocations: ['Vadodara', 'Anand'],
    status: 'active',
    password: 'test123'
  },
  {
    employeeId: 'ADMIN01',
    name: 'Suresh Patel',
    designation: 'State Manager',
    department: 'Gujarat State',
    reportingManager: 'HEAD OFFICE',
    phoneNumber: '+91 98765 43200',
    email: 'suresh.patel@satraservices.com',
    workLocations: ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot'],
    status: 'active',
    password: 'admin123'
  }
];

export const sampleAttendanceRecords = [
  {
    employeeId: 'SAT001',
    name: 'Rajesh Kumar',
    date: new Date().toISOString().split('T')[0], // Today
    checkInTime: new Date().toISOString(),
    status: 'present',
    location: {
      latitude: 23.0225,
      longitude: 72.5714,
      accuracy: 10,
      address: 'CG Road, Ahmedabad, Gujarat'
    },
    notes: 'Task: Client meeting at Ahmedabad office',
    workLocation: 'Ahmedabad',
    reportingManager: 'SURESH PATEL'
  },
  {
    employeeId: 'SAT002',
    name: 'Priya Patel',
    date: new Date().toISOString().split('T')[0],
    checkInTime: new Date().toISOString(),
    status: 'present',
    location: {
      latitude: 21.1702,
      longitude: 72.8311,
      accuracy: 15,
      address: 'Ring Road, Surat, Gujarat'
    },
    notes: 'Task: Market survey in Surat region',
    workLocation: 'Surat',
    reportingManager: 'RAJESH KUMAR'
  },
  {
    employeeId: 'SAT003',
    name: 'Amit Shah',
    date: new Date().toISOString().split('T')[0],
    checkInTime: new Date().toISOString(),
    status: 'half-day',
    location: {
      latitude: 22.3072,
      longitude: 73.1812,
      accuracy: 8,
      address: 'Sayajigunj, Vadodara, Gujarat'
    },
    notes: 'Task: Site inspection - Half day due to medical appointment',
    workLocation: 'Vadodara',
    reportingManager: 'PRIYA PATEL'
  }
];

export const sampleWorkLocations = [
  {
    id: 'AHM001',
    name: 'Ahmedabad Office',
    address: 'CG Road, Navrangpura, Ahmedabad, Gujarat 380009',
    latitude: 23.0225,
    longitude: 72.5714,
    radius: 100, // 100 meters
    city: 'Ahmedabad',
    state: 'Gujarat'
  },
  {
    id: 'SUR001',
    name: 'Surat Branch',
    address: 'Ring Road, Surat, Gujarat 395002',
    latitude: 21.1702,
    longitude: 72.8311,
    radius: 150,
    city: 'Surat',
    state: 'Gujarat'
  },
  {
    id: 'VAD001',
    name: 'Vadodara Center',
    address: 'Sayajigunj, Vadodara, Gujarat 390020',
    latitude: 22.3072,
    longitude: 73.1812,
    radius: 120,
    city: 'Vadodara',
    state: 'Gujarat'
  },
  {
    id: 'RAJ001',
    name: 'Rajkot Office',
    address: 'Kalawad Road, Rajkot, Gujarat 360005',
    latitude: 22.3039,
    longitude: 70.8022,
    radius: 100,
    city: 'Rajkot',
    state: 'Gujarat'
  }
];

