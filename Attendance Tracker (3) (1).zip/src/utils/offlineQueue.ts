/**
 * Offline Queue Management
 * Handles queueing of operations when offline and syncing when back online
 */

export enum QueueItemStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled'
}

export enum QueueItemPriority {
  LOW = 0,
  MEDIUM = 1,
  HIGH = 2,
  CRITICAL = 3
}

export interface QueueItem {
  id: string;
  type: string;
  data: any;
  status: QueueItemStatus;
  priority: QueueItemPriority;
  createdAt: string;
  updatedAt: string;
  attempts: number;
  maxAttempts: number;
  lastError?: string;
  metadata?: Record<string, any>;
}

export interface QueueOptions {
  maxRetries?: number;
  retryDelayMs?: number;
  autoSync?: boolean;
  syncIntervalMs?: number;
}

/**
 * Offline Queue Manager
 */
export class OfflineQueue {
  private queue: QueueItem[] = [];
  private isProcessing = false;
  private syncInterval: number | null = null;
  private readonly STORAGE_KEY = 'offline_queue';
  private options: Required<QueueOptions>;

  constructor(options: QueueOptions = {}) {
    this.options = {
      maxRetries: 3,
      retryDelayMs: 5000,
      autoSync: true,
      syncIntervalMs: 30000,
      ...options
    };

    this.loadQueue();
    
    if (this.options.autoSync) {
      this.startAutoSync();
    }

    // Listen for online/offline events
    window.addEventListener('online', () => this.handleOnline());
    window.addEventListener('offline', () => this.handleOffline());
  }

  /**
   * Add item to queue
   */
  async enqueue(
    type: string,
    data: any,
    priority: QueueItemPriority = QueueItemPriority.MEDIUM,
    metadata?: Record<string, any>
  ): Promise<string> {
    const item: QueueItem = {
      id: this.generateId(),
      type,
      data,
      status: QueueItemStatus.PENDING,
      priority,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      attempts: 0,
      maxAttempts: this.options.maxRetries,
      metadata
    };

    this.queue.push(item);
    this.sortQueue();
    this.saveQueue();

    console.log(`📥 Item queued: ${type} (${item.id})`);

    // Try to process if online
    if (navigator.onLine && this.options.autoSync) {
      this.processQueue();
    }

    return item.id;
  }

  /**
   * Process all pending items in queue
   */
  async processQueue(): Promise<void> {
    if (this.isProcessing) {
      console.log('⏳ Queue is already being processed');
      return;
    }

    if (!navigator.onLine) {
      console.log('📴 Offline - skipping queue processing');
      return;
    }

    this.isProcessing = true;
    console.log(`📤 Processing queue (${this.getPendingCount()} pending items)`);

    const pendingItems = this.queue.filter(
      item => item.status === QueueItemStatus.PENDING
    );

    for (const item of pendingItems) {
      await this.processItem(item);
    }

    this.isProcessing = false;
    this.saveQueue();

    const remaining = this.getPendingCount();
    if (remaining > 0) {
      console.log(`⏳ ${remaining} items still pending`);
    } else {
      console.log('✅ Queue processing complete');
    }
  }

  /**
   * Process individual queue item
   */
  private async processItem(item: QueueItem): Promise<void> {
    item.status = QueueItemStatus.PROCESSING;
    item.updatedAt = new Date().toISOString();
    this.saveQueue();

    try {
      // Execute the queued operation
      await this.executeItem(item);

      item.status = QueueItemStatus.COMPLETED;
      item.updatedAt = new Date().toISOString();
      
      console.log(`✅ Item processed: ${item.type} (${item.id})`);
    } catch (error) {
      item.attempts++;
      item.lastError = error instanceof Error ? error.message : 'Unknown error';
      item.updatedAt = new Date().toISOString();

      if (item.attempts >= item.maxAttempts) {
        item.status = QueueItemStatus.FAILED;
        console.error(`❌ Item failed after ${item.attempts} attempts: ${item.type} (${item.id})`);
      } else {
        item.status = QueueItemStatus.PENDING;
        console.warn(`⚠️ Item retry ${item.attempts}/${item.maxAttempts}: ${item.type} (${item.id})`);
        
        // Wait before allowing retry
        await this.delay(this.options.retryDelayMs);
      }
    }

    this.saveQueue();
  }

  /**
   * Execute queue item based on type
   */
  private async executeItem(item: QueueItem): Promise<void> {
    // Dispatch to appropriate handler based on item type
    switch (item.type) {
      case 'attendance':
        await this.syncAttendance(item.data);
        break;
      case 'profile_update':
        await this.syncProfileUpdate(item.data);
        break;
      case 'photo_upload':
        await this.syncPhotoUpload(item.data);
        break;
      default:
        console.warn(`Unknown queue item type: ${item.type}`);
    }
  }

  /**
   * Sync attendance record
   */
  private async syncAttendance(data: any): Promise<void> {
    // Implementation depends on your API
    const response = await fetch('/api/attendance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      throw new Error(`Failed to sync attendance: ${response.statusText}`);
    }
  }

  /**
   * Sync profile update
   */
  private async syncProfileUpdate(data: any): Promise<void> {
    // Implementation depends on your API
    const response = await fetch(`/api/profiles/${data.employeeId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      throw new Error(`Failed to sync profile: ${response.statusText}`);
    }
  }

  /**
   * Sync photo upload
   */
  private async syncPhotoUpload(data: any): Promise<void> {
    // Implementation depends on your API
    const formData = new FormData();
    formData.append('photo', data.photo);
    formData.append('employeeId', data.employeeId);

    const response = await fetch('/api/photos', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error(`Failed to sync photo: ${response.statusText}`);
    }
  }

  /**
   * Get queue statistics
   */
  getStats(): {
    total: number;
    pending: number;
    processing: number;
    completed: number;
    failed: number;
  } {
    return {
      total: this.queue.length,
      pending: this.queue.filter(i => i.status === QueueItemStatus.PENDING).length,
      processing: this.queue.filter(i => i.status === QueueItemStatus.PROCESSING).length,
      completed: this.queue.filter(i => i.status === QueueItemStatus.COMPLETED).length,
      failed: this.queue.filter(i => i.status === QueueItemStatus.FAILED).length
    };
  }

  /**
   * Get pending count
   */
  getPendingCount(): number {
    return this.queue.filter(
      item => item.status === QueueItemStatus.PENDING
    ).length;
  }

  /**
   * Get all queue items
   */
  getQueue(): QueueItem[] {
    return [...this.queue];
  }

  /**
   * Get item by ID
   */
  getItem(id: string): QueueItem | undefined {
    return this.queue.find(item => item.id === id);
  }

  /**
   * Remove completed items
   */
  clearCompleted(): void {
    this.queue = this.queue.filter(
      item => item.status !== QueueItemStatus.COMPLETED
    );
    this.saveQueue();
    console.log('🧹 Cleared completed items from queue');
  }

  /**
   * Remove all items
   */
  clearAll(): void {
    this.queue = [];
    this.saveQueue();
    console.log('🧹 Cleared all items from queue');
  }

  /**
   * Cancel specific item
   */
  cancelItem(id: string): boolean {
    const item = this.queue.find(item => item.id === id);
    if (item && item.status === QueueItemStatus.PENDING) {
      item.status = QueueItemStatus.CANCELLED;
      item.updatedAt = new Date().toISOString();
      this.saveQueue();
      console.log(`❌ Item cancelled: ${item.type} (${id})`);
      return true;
    }
    return false;
  }

  /**
   * Retry failed item
   */
  retryItem(id: string): void {
    const item = this.queue.find(item => item.id === id);
    if (item && item.status === QueueItemStatus.FAILED) {
      item.status = QueueItemStatus.PENDING;
      item.attempts = 0;
      item.lastError = undefined;
      item.updatedAt = new Date().toISOString();
      this.saveQueue();
      console.log(`🔄 Item reset for retry: ${item.type} (${id})`);
      
      if (navigator.onLine) {
        this.processQueue();
      }
    }
  }

  /**
   * Sort queue by priority
   */
  private sortQueue(): void {
    this.queue.sort((a, b) => {
      // First by priority (higher first)
      if (a.priority !== b.priority) {
        return b.priority - a.priority;
      }
      // Then by creation time (older first)
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    });
  }

  /**
   * Save queue to localStorage
   */
  private saveQueue(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.queue));
    } catch (error) {
      console.error('Failed to save queue:', error);
    }
  }

  /**
   * Load queue from localStorage
   */
  private loadQueue(): void {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        this.queue = JSON.parse(stored);
        console.log(`📂 Loaded ${this.queue.length} items from offline queue`);
      }
    } catch (error) {
      console.error('Failed to load queue:', error);
      this.queue = [];
    }
  }

  /**
   * Start automatic sync
   */
  private startAutoSync(): void {
    if (this.syncInterval) return;

    this.syncInterval = window.setInterval(() => {
      if (navigator.onLine && this.getPendingCount() > 0) {
        console.log('⏰ Auto-sync triggered');
        this.processQueue();
      }
    }, this.options.syncIntervalMs);

    console.log('✅ Auto-sync enabled');
  }

  /**
   * Stop automatic sync
   */
  stopAutoSync(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
      console.log('⏸️ Auto-sync disabled');
    }
  }

  /**
   * Handle online event
   */
  private handleOnline(): void {
    console.log('🌐 Connection restored');
    if (this.getPendingCount() > 0) {
      console.log('📤 Syncing queued items...');
      this.processQueue();
    }
  }

  /**
   * Handle offline event
   */
  private handleOffline(): void {
    console.log('📴 Connection lost - items will be queued');
  }

  /**
   * Cleanup
   */
  destroy(): void {
    this.stopAutoSync();
    window.removeEventListener('online', () => this.handleOnline());
    window.removeEventListener('offline', () => this.handleOffline());
  }

  /**
   * Generate unique ID
   */
  private generateId(): string {
    return `queue_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Delay helper
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

/**
 * Export singleton instance
 */
export const offlineQueue = new OfflineQueue();