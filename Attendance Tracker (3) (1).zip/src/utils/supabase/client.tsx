import { projectId, publicAnonKey } from './info';

// API Base URL
const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server`;

// API Client
export class AttendanceAPI {
  private async makeRequest(endpoint: string, options: RequestInit = {}, retries = 2) {
    const url = `${API_BASE_URL}${endpoint}`;
    
    // Add timeout to all requests
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
    
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
          ...options.headers,
        },
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Request failed: ${response.status}`);
      }

      return response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      
      // Retry logic for timeouts
      if (retries > 0 && (error.name === 'AbortError' || error.message.includes('timeout'))) {
        console.log(`Request timeout, retrying... (${retries} attempts left)`);
        await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second before retry
        return this.makeRequest(endpoint, options, retries - 1);
      }
      
      throw error;
    }
  }

  // Employee Management
  async createEmployee(employeeData: any) {
    return this.makeRequest('/employees', {
      method: 'POST',
      body: JSON.stringify(employeeData),
    });
  }

  async getEmployee(employeeId: string) {
    return this.makeRequest(`/employees/${employeeId}`);
  }

  async getAllEmployees() {
    return this.makeRequest('/employees');
  }

  // Authentication
  async login(employeeId: string, password: string) {
    return this.makeRequest('/login', {
      method: 'POST',
      body: JSON.stringify({ employeeId, password }),
    });
  }

  // Attendance Management
  async markAttendance(attendanceData: any) {
    return this.makeRequest('/attendance', {
      method: 'POST',
      body: JSON.stringify(attendanceData),
    });
  }

  async getTodayAttendance(employeeId: string) {
    return this.makeRequest(`/attendance/${employeeId}/today`);
  }

  async getAttendanceHistory(employeeId: string) {
    return this.makeRequest(`/attendance/${employeeId}/history`);
  }

  // Reports
  async getDailyReport(date?: string, dccb?: string) {
    const params = new URLSearchParams();
    if (date) params.append('date', date);
    if (dccb) params.append('dccb', dccb);
    
    const queryString = params.toString();
    return this.makeRequest(`/reports/daily${queryString ? `?${queryString}` : ''}`);
  }

  async getDashboardStats() {
    return this.makeRequest('/reports/dashboard-stats');
  }

  // Audit Logs
  async getAuditLogs() {
    return this.makeRequest('/audit-logs');
  }

  // Change Requests
  async createChangeRequest(requestData: any) {
    return this.makeRequest('/change-requests', {
      method: 'POST',
      body: JSON.stringify(requestData),
    });
  }

  // Health Check
  async healthCheck() {
    return this.makeRequest('/health');
  }
}

// Export singleton instance
export const attendanceAPI = new AttendanceAPI();