/**
 * Performance Monitoring and Optimization Utilities
 */

import { useEffect, useRef, useCallback, useState } from 'react';

/**
 * Performance Metrics Collector
 */
export class PerformanceMonitor {
  private static metrics: Map<string, number[]> = new Map();
  private static readonly MAX_SAMPLES = 100;

  /**
   * Mark performance point
   */
  static mark(name: string): void {
    if (typeof performance !== 'undefined') {
      performance.mark(name);
    }
  }

  /**
   * Measure between two marks
   */
  static measure(name: string, startMark: string, endMark: string): number | null {
    if (typeof performance === 'undefined') return null;

    try {
      performance.measure(name, startMark, endMark);
      const measure = performance.getEntriesByName(name, 'measure')[0] as PerformanceEntry;
      const duration = measure.duration;

      // Store metric
      this.recordMetric(name, duration);

      // Cleanup marks
      performance.clearMarks(startMark);
      performance.clearMarks(endMark);
      performance.clearMeasures(name);

      return duration;
    } catch (error) {
      console.error('Performance measure error:', error);
      return null;
    }
  }

  /**
   * Time a function execution
   */
  static async time<T>(name: string, fn: () => Promise<T> | T): Promise<T> {
    const startMark = `${name}-start`;
    const endMark = `${name}-end`;
    
    this.mark(startMark);
    
    try {
      const result = await fn();
      this.mark(endMark);
      const duration = this.measure(name, startMark, endMark);
      
      if (duration !== null) {
        console.log(`⏱️ ${name}: ${duration.toFixed(2)}ms`);
      }
      
      return result;
    } catch (error) {
      this.mark(endMark);
      this.measure(name, startMark, endMark);
      throw error;
    }
  }

  /**
   * Record metric value
   */
  private static recordMetric(name: string, value: number): void {
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }

    const samples = this.metrics.get(name)!;
    samples.push(value);

    // Keep only recent samples
    if (samples.length > this.MAX_SAMPLES) {
      samples.shift();
    }
  }

  /**
   * Get metric statistics
   */
  static getStats(name: string): {
    count: number;
    min: number;
    max: number;
    avg: number;
    median: number;
  } | null {
    const samples = this.metrics.get(name);
    if (!samples || samples.length === 0) return null;

    const sorted = [...samples].sort((a, b) => a - b);
    const count = samples.length;
    const sum = samples.reduce((a, b) => a + b, 0);

    return {
      count,
      min: sorted[0],
      max: sorted[count - 1],
      avg: sum / count,
      median: sorted[Math.floor(count / 2)]
    };
  }

  /**
   * Get all metrics
   */
  static getAllStats(): Record<string, ReturnType<typeof PerformanceMonitor.getStats>> {
    const result: Record<string, ReturnType<typeof PerformanceMonitor.getStats>> = {};
    
    this.metrics.forEach((_, name) => {
      result[name] = this.getStats(name);
    });

    return result;
  }

  /**
   * Clear all metrics
   */
  static clearMetrics(): void {
    this.metrics.clear();
    if (typeof performance !== 'undefined') {
      performance.clearMarks();
      performance.clearMeasures();
    }
  }

  /**
   * Get Web Vitals
   */
  static getWebVitals(): {
    FCP?: number;
    LCP?: number;
    FID?: number;
    CLS?: number;
    TTFB?: number;
  } {
    if (typeof performance === 'undefined') return {};

    const vitals: any = {};

    // First Contentful Paint
    const fcpEntry = performance.getEntriesByName('first-contentful-paint')[0] as PerformanceEntry;
    if (fcpEntry) {
      vitals.FCP = fcpEntry.startTime;
    }

    // Largest Contentful Paint
    const lcpEntries = performance.getEntriesByType('largest-contentful-paint');
    if (lcpEntries.length > 0) {
      vitals.LCP = lcpEntries[lcpEntries.length - 1].startTime;
    }

    // Time to First Byte
    const navigationEntry = performance.getEntriesByType('navigation')[0] as any;
    if (navigationEntry) {
      vitals.TTFB = navigationEntry.responseStart - navigationEntry.requestStart;
    }

    return vitals;
  }

  /**
   * Log performance summary
   */
  static logSummary(): void {
    console.group('📊 Performance Summary');
    
    const stats = this.getAllStats();
    Object.entries(stats).forEach(([name, stat]) => {
      if (stat) {
        console.log(`${name}:`, {
          avg: `${stat.avg.toFixed(2)}ms`,
          min: `${stat.min.toFixed(2)}ms`,
          max: `${stat.max.toFixed(2)}ms`,
          count: stat.count
        });
      }
    });

    const vitals = this.getWebVitals();
    if (Object.keys(vitals).length > 0) {
      console.log('Web Vitals:', vitals);
    }

    console.groupEnd();
  }
}

/**
 * Debounce Hook
 */
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}

/**
 * Debounced Callback Hook
 */
export function useDebouncedCallback<T extends (...args: any[]) => any>(
  callback: T,
  delay: number
): (...args: Parameters<T>) => void {
  const timeoutRef = useRef<number>();

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return useCallback(
    (...args: Parameters<T>) => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      timeoutRef.current = window.setTimeout(() => {
        callback(...args);
      }, delay);
    },
    [callback, delay]
  );
}

/**
 * Throttle Hook
 */
export function useThrottle<T extends (...args: any[]) => any>(
  callback: T,
  delay: number
): (...args: Parameters<T>) => void {
  const lastRun = useRef(Date.now());

  return useCallback(
    (...args: Parameters<T>) => {
      const now = Date.now();

      if (now - lastRun.current >= delay) {
        callback(...args);
        lastRun.current = now;
      }
    },
    [callback, delay]
  );
}

/**
 * Intersection Observer Hook for Lazy Loading
 */
export function useIntersectionObserver(
  elementRef: React.RefObject<Element>,
  options: IntersectionObserverInit = {}
): boolean {
  const [isIntersecting, setIsIntersecting] = useState(false);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(([entry]) => {
      setIsIntersecting(entry.isIntersecting);
    }, options);

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [elementRef, options]);

  return isIntersecting;
}

/**
 * Image Preloader
 */
export const preloadImages = async (urls: string[]): Promise<void> => {
  const promises = urls.map(
    url =>
      new Promise<void>((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve();
        img.onerror = () => reject(new Error(`Failed to load image: ${url}`));
        img.src = url;
      })
  );

  await Promise.all(promises);
};

/**
 * Cache Manager
 */
export class CacheManager {
  private cache: Map<string, { data: any; timestamp: number; ttl: number }> = new Map();

  /**
   * Set cache item with TTL
   */
  set(key: string, data: any, ttlMs: number = 300000): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlMs
    });
  }

  /**
   * Get cache item if not expired
   */
  get<T = any>(key: string): T | null {
    const item = this.cache.get(key);
    
    if (!item) return null;

    const age = Date.now() - item.timestamp;
    if (age > item.ttl) {
      this.cache.delete(key);
      return null;
    }

    return item.data as T;
  }

  /**
   * Check if key exists and is valid
   */
  has(key: string): boolean {
    return this.get(key) !== null;
  }

  /**
   * Delete cache item
   */
  delete(key: string): void {
    this.cache.delete(key);
  }

  /**
   * Clear all cache
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Get cache size
   */
  size(): number {
    return this.cache.size;
  }

  /**
   * Clean expired items
   */
  cleanExpired(): void {
    const now = Date.now();
    const toDelete: string[] = [];

    this.cache.forEach((item, key) => {
      if (now - item.timestamp > item.ttl) {
        toDelete.push(key);
      }
    });

    toDelete.forEach(key => this.cache.delete(key));
    
    if (toDelete.length > 0) {
      console.log(`🧹 Cleaned ${toDelete.length} expired cache items`);
    }
  }
}

/**
 * Request Deduplicator
 */
export class RequestDeduplicator {
  private pending: Map<string, Promise<any>> = new Map();

  /**
   * Execute request with deduplication
   */
  async execute<T>(key: string, requestFn: () => Promise<T>): Promise<T> {
    // If request is already pending, return the existing promise
    if (this.pending.has(key)) {
      console.log(`♻️ Reusing pending request: ${key}`);
      return this.pending.get(key) as Promise<T>;
    }

    // Create new request
    const promise = requestFn()
      .then(result => {
        this.pending.delete(key);
        return result;
      })
      .catch(error => {
        this.pending.delete(key);
        throw error;
      });

    this.pending.set(key, promise);
    return promise;
  }

  /**
   * Clear pending requests
   */
  clear(): void {
    this.pending.clear();
  }
}

/**
 * Batch Processor for API Calls
 */
export class BatchProcessor<T, R> {
  private queue: T[] = [];
  private timer: number | null = null;

  constructor(
    private processFn: (items: T[]) => Promise<R[]>,
    private delay: number = 100,
    private maxBatchSize: number = 10
  ) {}

  /**
   * Add item to batch
   */
  add(item: T): Promise<R> {
    return new Promise((resolve, reject) => {
      this.queue.push(item);

      // Store resolve/reject for this item
      const index = this.queue.length - 1;
      (item as any)._resolve = resolve;
      (item as any)._reject = reject;

      // Process immediately if batch is full
      if (this.queue.length >= this.maxBatchSize) {
        this.flush();
      } else {
        this.scheduleFlush();
      }
    });
  }

  /**
   * Schedule batch processing
   */
  private scheduleFlush(): void {
    if (this.timer) {
      clearTimeout(this.timer);
    }

    this.timer = window.setTimeout(() => {
      this.flush();
    }, this.delay);
  }

  /**
   * Process current batch
   */
  private async flush(): Promise<void> {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }

    if (this.queue.length === 0) return;

    const batch = this.queue.splice(0, this.maxBatchSize);
    
    try {
      const results = await this.processFn(batch);
      
      batch.forEach((item, index) => {
        const resolve = (item as any)._resolve;
        if (resolve) {
          resolve(results[index]);
        }
      });
    } catch (error) {
      batch.forEach(item => {
        const reject = (item as any)._reject;
        if (reject) {
          reject(error);
        }
      });
    }
  }
}

/**
 * Export singleton instances
 */
export const cacheManager = new CacheManager();
export const requestDeduplicator = new RequestDeduplicator();

// Clean expired cache every 5 minutes
setInterval(() => {
  cacheManager.cleanExpired();
}, 300000);