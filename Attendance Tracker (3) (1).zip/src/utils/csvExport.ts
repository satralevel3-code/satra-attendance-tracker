/**
 * CSV Export Utility
 * 
 * Properly handles special characters, UTF-8 encoding, and location data formatting
 */

interface AttendanceRecord {
  date: string;
  employeeId: string;
  name?: string;
  fullName?: string;
  dccb?: string;
  status: string;
  task?: string;
  notes?: string;
  workLocation?: string;
  workplace?: string;
  timestamp?: string;
  checkInTime?: string;
  location?: {
    latitude: number;
    longitude: number;
    accuracy: number;
    address: string;
  };
  reportingManager?: string;
  reportingTo?: string;
}

export function exportAttendanceToCSV(
  reportData: AttendanceRecord[],
  filename: string = 'attendance_records.csv'
): void {
  if (reportData.length === 0) {
    console.warn('No data to export');
    return;
  }

  // Define CSV headers
  const headers = [
    'Date',
    'Employee ID',
    'Full Name',
    'DCCB',
    'Status',
    'Task',
    'Workplace',
    'Timestamp',
    'Longitude',
    'Latitude',
    'Address',
    'Location Accuracy (m)',
    'Reporting To'
  ];

  // Transform data to CSV rows
  const csvRows = reportData.map((record) => {
    // Extract location data properly
    let longitude = '';
    let latitude = '';
    let address = '';
    let accuracy = '';

    if (record.location) {
      longitude = record.location.longitude ? record.location.longitude.toString() : '';
      latitude = record.location.latitude ? record.location.latitude.toString() : '';
      // Clean address - remove any problematic characters
      address = record.location.address ? record.location.address.replace(/[\r\n]+/g, ' ').trim() : '';
      accuracy = record.location.accuracy ? Math.round(record.location.accuracy).toString() : '';
    }

    return [
      record.date || '',
      record.employeeId || '',
      record.name || record.fullName || '',
      record.dccb || '',
      record.status || '',
      record.task || record.notes?.split(':')[1]?.trim() || '',
      record.workLocation || record.workplace || '',
      record.timestamp || record.checkInTime 
        ? new Date(record.timestamp || record.checkInTime!).toLocaleString('en-IN', {
            timeZone: 'Asia/Kolkata',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
          })
        : '',
      longitude,
      latitude,
      address,
      accuracy,
      record.reportingManager || record.reportingTo || ''
    ];
  });

  // Create CSV content with proper encoding
  // BOM (Byte Order Mark) ensures proper UTF-8 encoding in Excel and other programs
  const BOM = '\uFEFF';
  const csvContent =
    BOM +
    [headers, ...csvRows]
      .map((row) =>
        row
          .map((field) => {
            // Convert to string and handle null/undefined
            const str = field != null ? String(field) : '';
            // Escape double quotes by doubling them
            const escaped = str.replace(/"/g, '""');
            // Wrap in quotes to handle commas and special characters
            return `"${escaped}"`;
          })
          .join(',')
      )
      .join('\n');

  // Create and download the file
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  // Clean up the URL object
  URL.revokeObjectURL(url);

  console.log(`✅ Exported ${reportData.length} records to ${filename}`);
}

/**
 * Export with location details in separate format
 * Longitude, Latitude, Address as requested
 */
export function exportAttendanceWithLocationDetails(
  reportData: AttendanceRecord[],
  filename: string = 'attendance_with_locations.csv'
): void {
  if (reportData.length === 0) {
    console.warn('No data to export');
    return;
  }

  const headers = [
    'Date',
    'Employee ID',
    'Full Name',
    'DCCB',
    'Status',
    'Task',
    'Workplace',
    'Timestamp',
    'Longitude',
    'Latitude',
    'Address',
    'Accuracy (meters)',
    'Google Maps Link',
    'Reporting To'
  ];

  const csvRows = reportData.map((record) => {
    let longitude = '';
    let latitude = '';
    let address = '';
    let accuracy = '';
    let googleMapsLink = '';

    if (record.location) {
      longitude = record.location.longitude?.toFixed(8) || '';
      latitude = record.location.latitude?.toFixed(8) || '';
      address = record.location.address?.replace(/[\r\n]+/g, ' ').trim() || '';
      accuracy = record.location.accuracy ? Math.round(record.location.accuracy).toString() : '';
      
      if (longitude && latitude) {
        googleMapsLink = `https://www.google.com/maps?q=${latitude},${longitude}`;
      }
    }

    return [
      record.date || '',
      record.employeeId || '',
      record.name || record.fullName || '',
      record.dccb || '',
      record.status || '',
      record.task || record.notes?.split(':')[1]?.trim() || '',
      record.workLocation || record.workplace || '',
      record.timestamp || record.checkInTime
        ? new Date(record.timestamp || record.checkInTime!).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })
        : '',
      longitude,
      latitude,
      address,
      accuracy,
      googleMapsLink,
      record.reportingManager || record.reportingTo || ''
    ];
  });

  const BOM = '\uFEFF';
  const csvContent =
    BOM +
    [headers, ...csvRows]
      .map((row) =>
        row
          .map((field) => {
            const str = field != null ? String(field) : '';
            const escaped = str.replace(/"/g, '""');
            return `"${escaped}"`;
          })
          .join(',')
      )
      .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  console.log(`✅ Exported ${reportData.length} records with location details to ${filename}`);
}