/**
 * Client-Side Monitoring and Analytics
 * Provides telemetry, user analytics, and health checks
 */

export enum EventType {
  PAGE_VIEW = 'page_view',
  USER_ACTION = 'user_action',
  ERROR = 'error',
  PERFORMANCE = 'performance',
  ATTENDANCE_MARKED = 'attendance_marked',
  LOGIN = 'login',
  LOGOUT = 'logout',
  API_CALL = 'api_call',
  OFFLINE = 'offline',
  ONLINE = 'online'
}

export interface AnalyticsEvent {
  id: string;
  type: EventType;
  category: string;
  action: string;
  label?: string;
  value?: number;
  metadata?: Record<string, any>;
  timestamp: string;
  sessionId: string;
  userId?: string;
}

/**
 * Analytics Service
 */
export class Analytics {
  private static sessionId: string = this.generateSessionId();
  private static userId?: string;
  private static events: AnalyticsEvent[] = [];
  private static readonly MAX_EVENTS = 500;
  private static readonly STORAGE_KEY = 'analytics_events';
  private static readonly BATCH_SIZE = 20;
  private static flushTimer: number | null = null;

  /**
   * Initialize analytics
   */
  static init(userId?: string): void {
    this.userId = userId;
    this.loadEvents();
    this.trackPageView();
    this.setupEventListeners();
    
    console.log('📊 Analytics initialized', {
      sessionId: this.sessionId,
      userId: this.userId
    });
  }

  /**
   * Track event
   */
  static track(
    type: EventType,
    category: string,
    action: string,
    label?: string,
    value?: number,
    metadata?: Record<string, any>
  ): void {
    const event: AnalyticsEvent = {
      id: this.generateEventId(),
      type,
      category,
      action,
      label,
      value,
      metadata,
      timestamp: new Date().toISOString(),
      sessionId: this.sessionId,
      userId: this.userId
    };

    this.events.push(event);

    // Trim if exceeds max
    if (this.events.length > this.MAX_EVENTS) {
      this.events.shift();
    }

    this.saveEvents();
    this.scheduleFlush();

    // Log important events
    if (
      type === EventType.ERROR ||
      type === EventType.ATTENDANCE_MARKED ||
      type === EventType.LOGIN
    ) {
      console.log('📊 Event tracked:', event);
    }
  }

  /**
   * Track page view
   */
  static trackPageView(page?: string): void {
    this.track(
      EventType.PAGE_VIEW,
      'navigation',
      'page_view',
      page || window.location.pathname,
      undefined,
      {
        referrer: document.referrer,
        userAgent: navigator.userAgent,
        screenSize: `${window.screen.width}x${window.screen.height}`,
        viewportSize: `${window.innerWidth}x${window.innerHeight}`
      }
    );
  }

  /**
   * Track user action
   */
  static trackAction(action: string, label?: string, metadata?: Record<string, any>): void {
    this.track(EventType.USER_ACTION, 'interaction', action, label, undefined, metadata);
  }

  /**
   * Track API call
   */
  static trackAPICall(
    endpoint: string,
    method: string,
    statusCode: number,
    duration: number,
    success: boolean
  ): void {
    this.track(
      EventType.API_CALL,
      'api',
      method,
      endpoint,
      duration,
      {
        statusCode,
        success
      }
    );
  }

  /**
   * Track attendance marking
   */
  static trackAttendanceMarked(
    employeeId: string,
    status: string,
    location?: { latitude: number; longitude: number }
  ): void {
    this.track(
      EventType.ATTENDANCE_MARKED,
      'attendance',
      'mark',
      status,
      undefined,
      {
        employeeId,
        hasLocation: !!location,
        location
      }
    );
  }

  /**
   * Track error
   */
  static trackError(error: Error, context?: Record<string, any>): void {
    this.track(
      EventType.ERROR,
      'error',
      error.name,
      error.message,
      undefined,
      {
        stack: error.stack,
        ...context
      }
    );
  }

  /**
   * Set user ID
   */
  static setUserId(userId: string): void {
    this.userId = userId;
    console.log('📊 User ID set:', userId);
  }

  /**
   * Clear user ID (logout)
   */
  static clearUserId(): void {
    this.userId = undefined;
    console.log('📊 User ID cleared');
  }

  /**
   * Get all events
   */
  static getEvents(filter?: {
    type?: EventType;
    category?: string;
    since?: Date;
  }): AnalyticsEvent[] {
    let filtered = [...this.events];

    if (filter) {
      if (filter.type) {
        filtered = filtered.filter(e => e.type === filter.type);
      }
      if (filter.category) {
        filtered = filtered.filter(e => e.category === filter.category);
      }
      if (filter.since) {
        filtered = filtered.filter(e => new Date(e.timestamp) >= filter.since!);
      }
    }

    return filtered;
  }

  /**
   * Get event counts by type
   */
  static getEventCounts(): Record<EventType, number> {
    const counts: any = {};
    
    Object.values(EventType).forEach(type => {
      counts[type] = this.events.filter(e => e.type === type).length;
    });

    return counts;
  }

  /**
   * Get session duration
   */
  static getSessionDuration(): number {
    if (this.events.length === 0) return 0;

    const firstEvent = new Date(this.events[this.events.length - 1].timestamp);
    const lastEvent = new Date(this.events[0].timestamp);
    
    return lastEvent.getTime() - firstEvent.getTime();
  }

  /**
   * Clear events
   */
  static clearEvents(): void {
    this.events = [];
    this.saveEvents();
    console.log('📊 Analytics events cleared');
  }

  /**
   * Flush events to server
   */
  private static async flushEvents(): Promise<void> {
    if (this.events.length === 0) return;

    const batch = this.events.slice(0, this.BATCH_SIZE);

    try {
      // In production, send to analytics endpoint
      console.log('📤 Flushing analytics batch:', batch.length, 'events');
      
      // Simulate API call
      // await fetch('/api/analytics', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(batch)
      // });

      // Remove sent events
      this.events.splice(0, batch.length);
      this.saveEvents();
    } catch (error) {
      console.error('Failed to flush analytics:', error);
    }
  }

  /**
   * Schedule flush
   */
  private static scheduleFlush(): void {
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
    }

    // Flush after 30 seconds or when batch is full
    if (this.events.length >= this.BATCH_SIZE) {
      this.flushEvents();
    } else {
      this.flushTimer = window.setTimeout(() => {
        this.flushEvents();
      }, 30000);
    }
  }

  /**
   * Save events to storage
   */
  private static saveEvents(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.events));
    } catch (error) {
      console.error('Failed to save analytics events:', error);
    }
  }

  /**
   * Load events from storage
   */
  private static loadEvents(): void {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        this.events = JSON.parse(stored);
      }
    } catch (error) {
      console.error('Failed to load analytics events:', error);
    }
  }

  /**
   * Setup event listeners
   */
  private static setupEventListeners(): void {
    // Track online/offline
    window.addEventListener('online', () => {
      this.track(EventType.ONLINE, 'connectivity', 'online');
    });

    window.addEventListener('offline', () => {
      this.track(EventType.OFFLINE, 'connectivity', 'offline');
    });

    // Track page unload
    window.addEventListener('beforeunload', () => {
      this.flushEvents();
    });

    // Track visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.trackAction('page_hidden');
      } else {
        this.trackAction('page_visible');
      }
    });
  }

  /**
   * Generate session ID
   */
  private static generateSessionId(): string {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Generate event ID
   */
  private static generateEventId(): string {
    return `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Health Check Service
 */
export class HealthCheck {
  private static checks: Map<string, () => Promise<boolean>> = new Map();
  private static results: Map<string, { healthy: boolean; timestamp: number; error?: string }> = new Map();

  /**
   * Register health check
   */
  static register(name: string, checkFn: () => Promise<boolean>): void {
    this.checks.set(name, checkFn);
    console.log(`✅ Health check registered: ${name}`);
  }

  /**
   * Run all health checks
   */
  static async runAll(): Promise<Map<string, { healthy: boolean; error?: string }>> {
    const results = new Map<string, { healthy: boolean; error?: string }>();

    for (const [name, checkFn] of this.checks.entries()) {
      try {
        const healthy = await checkFn();
        results.set(name, { healthy });
        
        this.results.set(name, {
          healthy,
          timestamp: Date.now()
        });
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        results.set(name, { healthy: false, error: errorMessage });
        
        this.results.set(name, {
          healthy: false,
          timestamp: Date.now(),
          error: errorMessage
        });
      }
    }

    return results;
  }

  /**
   * Run specific health check
   */
  static async run(name: string): Promise<{ healthy: boolean; error?: string }> {
    const checkFn = this.checks.get(name);
    
    if (!checkFn) {
      return { healthy: false, error: 'Check not found' };
    }

    try {
      const healthy = await checkFn();
      const result = { healthy };
      
      this.results.set(name, {
        healthy,
        timestamp: Date.now()
      });
      
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      const result = { healthy: false, error: errorMessage };
      
      this.results.set(name, {
        healthy: false,
        timestamp: Date.now(),
        error: errorMessage
      });
      
      return result;
    }
  }

  /**
   * Get cached results
   */
  static getResults(): Map<string, { healthy: boolean; timestamp: number; error?: string }> {
    return new Map(this.results);
  }

  /**
   * Get overall health status
   */
  static isHealthy(): boolean {
    for (const [, result] of this.results.entries()) {
      if (!result.healthy) {
        return false;
      }
    }
    return this.results.size > 0;
  }

  /**
   * Clear all checks
   */
  static clear(): void {
    this.checks.clear();
    this.results.clear();
  }
}

/**
 * Register default health checks
 */
export const registerDefaultHealthChecks = (): void => {
  // Network connectivity
  HealthCheck.register('network', async () => {
    return navigator.onLine;
  });

  // Local storage availability
  HealthCheck.register('localStorage', async () => {
    try {
      const test = '__test__';
      localStorage.setItem(test, test);
      localStorage.removeItem(test);
      return true;
    } catch {
      return false;
    }
  });

  // IndexedDB availability
  HealthCheck.register('indexedDB', async () => {
    return !!window.indexedDB;
  });

  // Geolocation availability
  HealthCheck.register('geolocation', async () => {
    return !!navigator.geolocation;
  });

  // Camera availability
  HealthCheck.register('camera', async () => {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      return devices.some(device => device.kind === 'videoinput');
    } catch {
      return false;
    }
  });

  console.log('✅ Default health checks registered');
};

/**
 * Performance Observer for monitoring
 */
export class PerformanceObserverService {
  private static observers: PerformanceObserver[] = [];

  static init(): void {
    // Observe long tasks
    if ('PerformanceObserver' in window) {
      try {
        const longTaskObserver = new PerformanceObserver((list) => {
          for (const entry of list.getEntries()) {
            if (entry.duration > 50) {
              console.warn('⚠️ Long task detected:', {
                duration: entry.duration,
                startTime: entry.startTime
              });
              
              Analytics.track(
                EventType.PERFORMANCE,
                'long_task',
                'detected',
                undefined,
                entry.duration
              );
            }
          }
        });

        longTaskObserver.observe({ entryTypes: ['longtask'] });
        this.observers.push(longTaskObserver);
      } catch (error) {
        console.log('Long task observer not supported');
      }

      // Observe largest contentful paint
      try {
        const lcpObserver = new PerformanceObserver((list) => {
          const entries = list.getEntries();
          const lastEntry = entries[entries.length - 1];
          
          console.log('🎨 LCP:', lastEntry.startTime);
          
          Analytics.track(
            EventType.PERFORMANCE,
            'lcp',
            'measured',
            undefined,
            lastEntry.startTime
          );
        });

        lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
        this.observers.push(lcpObserver);
      } catch (error) {
        console.log('LCP observer not supported');
      }
    }

    console.log('✅ Performance observers initialized');
  }

  static disconnect(): void {
    this.observers.forEach(observer => observer.disconnect());
    this.observers = [];
  }
}

/**
 * Initialize all monitoring services
 */
export const initializeMonitoring = (userId?: string): void => {
  Analytics.init(userId);
  registerDefaultHealthChecks();
  PerformanceObserverService.init();
  
  console.log('📊 Monitoring services initialized');
};