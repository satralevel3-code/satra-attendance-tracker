// Location Service for accurate GPS capture and verification
// Ensures high-accuracy location capture for attendance marking

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude?: number;
  altitudeAccuracy?: number;
  heading?: number;
  speed?: number;
  timestamp: number;
}

interface LocationResult {
  location: LocationData;
  address: string;
  isAccurate: boolean;
  accuracy: 'high' | 'medium' | 'low';
  error?: string;
}

interface WorkLocationValidation {
  isWithinWorkLocation: boolean;
  nearestLocation?: {
    name: string;
    distance: number;
  };
  allowedLocations: Array<{
    name: string;
    distance: number;
  }>;
}

class LocationService {
  private readonly MIN_ACCURACY = 50; // meters
  private readonly PREFERRED_ACCURACY = 20; // meters
  private readonly MAX_AGE = 10000; // 10 seconds
  private readonly TIMEOUT = 30000; // 30 seconds
  private readonly MAX_RETRIES = 3;

  /**
   * Get high-accuracy current location with multiple attempts
   */
  async getCurrentLocation(): Promise<LocationResult> {
    if (!navigator.geolocation) {
      throw new Error('Geolocation is not supported by this browser');
    }

    for (let attempt = 1; attempt <= this.MAX_RETRIES; attempt++) {
      try {
        console.log(`Location attempt ${attempt}/${this.MAX_RETRIES}`);
        
        const locationData = await this.getLocationWithTimeout();
        const address = await this.reverseGeocode(locationData.latitude, locationData.longitude);
        
        const accuracy = this.evaluateAccuracy(locationData.accuracy);
        const isAccurate = locationData.accuracy <= this.MIN_ACCURACY;

        const result: LocationResult = {
          location: locationData,
          address,
          isAccurate,
          accuracy
        };

        // If we got good accuracy, return immediately
        if (accuracy === 'high') {
          console.log('High accuracy location obtained:', result);
          return result;
        }

        // If this is not the last attempt and accuracy is poor, try again
        if (attempt < this.MAX_RETRIES && accuracy === 'low') {
          console.log(`Poor accuracy (${locationData.accuracy}m), retrying...`);
          await this.delay(2000); // Wait 2 seconds before retry
          continue;
        }

        // Return the result even if accuracy is not ideal
        console.log('Location obtained with accuracy:', accuracy);
        return result;

      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        const isPermissionDenied = errorMessage.includes('denied') || errorMessage.includes('Permission');
        
        // Only log permission denials once, not as errors
        if (isPermissionDenied) {
          if (attempt === 1) {
            console.log('📍 Location access denied by user');
          }
        } else {
          console.log(`Location attempt ${attempt} failed:`, errorMessage);
        }
        
        if (attempt === this.MAX_RETRIES) {
          throw new Error(`Failed to get location after ${this.MAX_RETRIES} attempts: ${errorMessage}`);
        }
        
        // Don't retry if permission was explicitly denied
        if (isPermissionDenied) {
          throw new Error(errorMessage);
        }
        
        await this.delay(1000); // Wait 1 second before retry
      }
    }

    throw new Error('Failed to get location');
  }

  /**
   * Get location with high accuracy settings and timeout
   */
  private getLocationWithTimeout(): Promise<LocationData> {
    return new Promise((resolve, reject) => {
      const options: PositionOptions = {
        enableHighAccuracy: true,
        timeout: this.TIMEOUT,
        maximumAge: this.MAX_AGE
      };

      const timeoutId = setTimeout(() => {
        reject(new Error('Location request timed out'));
      }, this.TIMEOUT);

      navigator.geolocation.getCurrentPosition(
        (position) => {
          clearTimeout(timeoutId);
          
          const locationData: LocationData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            altitude: position.coords.altitude || undefined,
            altitudeAccuracy: position.coords.altitudeAccuracy || undefined,
            heading: position.coords.heading || undefined,
            speed: position.coords.speed || undefined,
            timestamp: position.timestamp
          };

          resolve(locationData);
        },
        (error) => {
          clearTimeout(timeoutId);
          
          let errorMessage = 'Unknown geolocation error';
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = 'Location access denied by user. Please enable location permissions in your browser settings.';
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = 'Location information is unavailable. Please check your device GPS settings.';
              break;
            case error.TIMEOUT:
              errorMessage = 'Location request timed out. Please try again or check your connection.';
              break;
          }
          
          reject(new Error(errorMessage));
        },
        options
      );
    });
  }

  /**
   * Get address from coordinates - public method
   */
  async getAddressFromCoordinates(latitude: number, longitude: number): Promise<string> {
    return this.reverseGeocode(latitude, longitude);
  }

  /**
   * Reverse geocode coordinates to address
   */
  private async reverseGeocode(latitude: number, longitude: number): Promise<string> {
    try {
      // Using a free geocoding service without API key for fallback
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&addressdetails=1`,
        {
          headers: {
            'User-Agent': 'SatraServicesAttendanceApp/1.0'
          }
        }
      );

      if (!response.ok) {
        throw new Error('Geocoding service unavailable');
      }

      const data = await response.json();
      
      if (data && data.display_name) {
        return data.display_name;
      }

      // Fallback to basic coordinates display
      return `Lat: ${latitude.toFixed(6)}, Lng: ${longitude.toFixed(6)}`;
    } catch (error) {
      console.log('Reverse geocoding failed, using coordinates:', error);
      return `Lat: ${latitude.toFixed(6)}, Lng: ${longitude.toFixed(6)}`;
    }
  }

  /**
   * Evaluate location accuracy level
   */
  private evaluateAccuracy(accuracy: number): 'high' | 'medium' | 'low' {
    if (accuracy <= this.PREFERRED_ACCURACY) {
      return 'high';
    } else if (accuracy <= this.MIN_ACCURACY) {
      return 'medium';
    } else {
      return 'low';
    }
  }

  /**
   * Calculate distance between two coordinates in meters
   */
  calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  }

  /**
   * Validate if current location is within allowed work locations
   */
  async validateWorkLocation(
    currentLocation: { latitude: number; longitude: number },
    workLocations: Array<{ name: string; latitude: number; longitude: number; radius: number }>
  ): Promise<WorkLocationValidation> {
    const allowedLocations = workLocations.map(location => {
      const distance = this.calculateDistance(
        currentLocation.latitude,
        currentLocation.longitude,
        location.latitude,
        location.longitude
      );

      return {
        name: location.name,
        distance: Math.round(distance),
        isWithin: distance <= location.radius
      };
    });

    // Sort by distance
    allowedLocations.sort((a, b) => a.distance - b.distance);

    const isWithinWorkLocation = allowedLocations.some(loc => loc.isWithin);
    const nearestLocation = allowedLocations[0];

    return {
      isWithinWorkLocation,
      nearestLocation: nearestLocation ? {
        name: nearestLocation.name,
        distance: nearestLocation.distance
      } : undefined,
      allowedLocations: allowedLocations.map(loc => ({
        name: loc.name,
        distance: loc.distance
      }))
    };
  }

  /**
   * Watch position for continuous location updates
   */
  watchPosition(
    callback: (location: LocationData) => void,
    errorCallback: (error: string) => void
  ): number {
    if (!navigator.geolocation) {
      errorCallback('Geolocation not supported');
      return -1;
    }

    const options: PositionOptions = {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 5000
    };

    return navigator.geolocation.watchPosition(
      (position) => {
        const locationData: LocationData = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          altitude: position.coords.altitude || undefined,
          altitudeAccuracy: position.coords.altitudeAccuracy || undefined,
          heading: position.coords.heading || undefined,
          speed: position.coords.speed || undefined,
          timestamp: position.timestamp
        };

        callback(locationData);
      },
      (error) => {
        let errorMessage = 'Unknown geolocation error';
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Location access denied';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location unavailable';
            break;
          case error.TIMEOUT:
            errorMessage = 'Location timeout';
            break;
        }
        errorCallback(errorMessage);
      },
      options
    );
  }

  /**
   * Clear position watch
   */
  clearWatch(watchId: number): void {
    navigator.geolocation.clearWatch(watchId);
  }

  /**
   * Check location permission status
   */
  async checkPermissions(): Promise<{
    supported: boolean;
    permission: 'granted' | 'denied' | 'prompt' | 'unknown';
    message: string;
  }> {
    const result = {
      supported: !!navigator.geolocation,
      permission: 'unknown' as 'granted' | 'denied' | 'prompt' | 'unknown',
      message: 'Location support unknown'
    };

    if (!navigator.geolocation) {
      result.message = 'Geolocation is not supported by this browser';
      return result;
    }

    try {
      if ('permissions' in navigator) {
        const permission = await navigator.permissions.query({ name: 'geolocation' });
        result.permission = permission.state;
        
        switch (permission.state) {
          case 'granted':
            result.message = 'Location permission granted';
            break;
          case 'denied':
            result.message = 'Location permission denied. Please enable in browser settings.';
            break;
          case 'prompt':
            result.message = 'Location permission will be requested';
            break;
        }
      } else {
        result.message = 'Permission status cannot be determined';
      }
    } catch (error) {
      result.message = 'Error checking location permissions';
    }

    return result;
  }

  /**
   * Check if high accuracy location is available
   */
  async checkLocationCapability(): Promise<{
    supported: boolean;
    permissions: 'granted' | 'denied' | 'prompt';
    accuracy: 'high' | 'low' | 'unknown';
  }> {
    const result = {
      supported: !!navigator.geolocation,
      permissions: 'unknown' as 'granted' | 'denied' | 'prompt',
      accuracy: 'unknown' as 'high' | 'low' | 'unknown'
    };

    if (!navigator.geolocation) {
      return result;
    }

    try {
      // Check permissions
      if ('permissions' in navigator) {
        const permission = await navigator.permissions.query({ name: 'geolocation' });
        result.permissions = permission.state;
      }

      // Test location accuracy with a quick check
      if (result.permissions === 'granted') {
        try {
          const location = await this.getLocationWithTimeout();
          result.accuracy = location.accuracy <= this.MIN_ACCURACY ? 'high' : 'low';
        } catch (error) {
          console.log('Location capability test failed:', error);
        }
      }
    } catch (error) {
      console.log('Error checking location capability:', error);
    }

    return result;
  }

  /**
   * Utility function to delay execution
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Export singleton instance
export const locationService = new LocationService();
export type { LocationData, LocationResult, WorkLocationValidation };