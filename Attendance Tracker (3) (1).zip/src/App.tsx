import { useState, useEffect } from "react";
import { LoginScreen } from "./components/LoginScreen";
import { CreateProfileScreen } from "./components/CreateProfileScreen";
import { ExecutiveDashboard } from "./components/ExecutiveDashboard";
import { AdminDashboard } from "./components/AdminDashboard";
import { AttendanceMarkingScreen } from "./components/AttendanceMarkingScreen";
import { ReportsView } from "./components/ReportsView";
import { AttendanceCalendar } from "./components/AttendanceCalendar";
import { LocationManager } from "./components/LocationManager";
import { MISReportsScreen } from "./components/MISReportsScreen";
import { AppStatusScreen } from "./components/AppStatusScreen";
import { DemoDataSeeder } from "./components/DemoDataSeeder";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { EnhancedOfflineIndicator } from "./components/EnhancedOfflineIndicator";
import { Toaster } from "./components/ui/sonner";
import { initializeGlobalErrorHandlers } from "./utils/errorHandling";
import { initializeMonitoring, Analytics } from "./utils/monitoring";
import { CSPViolationReporter } from "./utils/security";


type AppScreen = 
  | 'app-status'
  | 'login' 
  | 'create-profile' 
  | 'executive-dashboard' 
  | 'admin-dashboard' 
  | 'mark-attendance'
  | 'permission-guide'
  | 'reports'
  | 'mis-reports'
  | 'map'
  | 'profile';

interface UserData {
  employeeId: string;
  name: string;
  designation: string;
  userType: 'executive' | 'admin';
  dccb?: string;
  reportingTo?: string;
  reportingManager?: string;
  department?: string;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('app-status');
  const [userData, setUserData] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize app
  useEffect(() => {
    const initializeApp = async () => {
      try {
        setIsLoading(true);
        
        // Initialize global error handlers
        initializeGlobalErrorHandlers();
        
        // Initialize CSP violation reporter
        CSPViolationReporter.init();
        
        // Initialize monitoring and analytics
        initializeMonitoring();
        
        // Track app initialization
        Analytics.trackPageView('/');
        
        console.log('✅ Satra Services Attendance Tracker initialized');
        console.log('📊 Monitoring and error handling active');
        console.log('🔐 Security features enabled');
        console.log('🔄 Offline support ready');
        
      } catch (error) {
        console.error('App initialization error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    initializeApp();
  }, []);

  const handleLogin = (userType: 'executive' | 'admin', user: any) => {
    const userData = {
      employeeId: user.employeeId,
      name: user.name || `${user.firstName} ${user.lastName}`,
      designation: user.designation,
      userType,
      dccb: user.dccb,
      reportingTo: user.reportingTo || user.reportingManager,
      reportingManager: user.reportingManager || user.reportingTo,
      department: user.department || user.dccb
    };
    
    setUserData(userData);
    
    // Track login event
    Analytics.setUserId(user.employeeId);
    Analytics.trackAction('login', userType, {
      designation: user.designation,
      department: user.department
    });
    
    if (userType === 'executive') {
      setCurrentScreen('executive-dashboard');
    } else {
      setCurrentScreen('admin-dashboard');
    }
  };

  const handleCreateProfile = () => {
    setCurrentScreen('create-profile');
  };

  const handleProfileCreated = () => {
    setCurrentScreen('login');
  };

  const handleMarkAttendance = () => {
    setCurrentScreen('mark-attendance');
  };

  const handleAttendanceMarked = (status: 'present' | 'absent' | 'half-day') => {
    // Show success message and return to dashboard
    setCurrentScreen('executive-dashboard');
  };

  const handleBackToDashboard = () => {
    if (userData?.userType === 'executive') {
      setCurrentScreen('executive-dashboard');
    } else {
      setCurrentScreen('admin-dashboard');
    }
  };

  const handleViewReports = () => {
    setCurrentScreen('mis-reports');
  };

  const handleViewMap = () => {
    setCurrentScreen('map');
  };

  const handleProfile = () => {
    setCurrentScreen('profile');
  };



  const renderCurrentScreen = () => {
    switch (currentScreen) {
      case 'app-status':
        return (
          <AppStatusScreen 
            onContinue={() => setCurrentScreen('login')}
          />
        );
        
      case 'login':
        return (
          <LoginScreen 
            onLogin={handleLogin}
            onCreateProfile={handleCreateProfile}
          />
        );
        
      case 'create-profile':
        return (
          <CreateProfileScreen 
            onBack={() => setCurrentScreen('login')}
            onProfileCreated={handleProfileCreated}
          />
        );
        
      case 'executive-dashboard':
        return userData ? (
          <ExecutiveDashboard 
            onMarkAttendance={handleMarkAttendance}
            onViewHistory={() => setCurrentScreen('reports')}
            onProfile={handleProfile}
            userData={userData}
          />
        ) : null;
        
      case 'admin-dashboard':
        return userData ? (
          <AdminDashboard 
            onViewReports={handleViewReports}
            onViewMap={handleViewMap}
            onProfile={handleProfile}
            userData={userData}
          />
        ) : null;
        
      // Removed permission-guide step - permissions are now handled automatically in attendance marking
        
      case 'mark-attendance':
        return userData ? (
          <AttendanceMarkingScreen 
            onBack={handleBackToDashboard}
            onAttendanceMarked={handleAttendanceMarked}
            userData={{
              employeeId: userData.employeeId,
              name: userData.name,
              reportingManager: userData.reportingManager || userData.reportingTo || "SURESH PATEL"
            }}
          />
        ) : null;
        
      case 'reports':
        return userData ? (
          userData.userType === 'executive' ? (
            <AttendanceCalendar 
              onBack={handleBackToDashboard}
              userData={{
                employeeId: userData.employeeId,
                name: userData.name,
                designation: userData.designation
              }}
            />
          ) : (
            <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
              <div className="bg-white shadow-sm border-b mb-6">
                <div className="max-w-4xl mx-auto px-6 py-4">
                  <button 
                    onClick={handleBackToDashboard}
                    className="text-primary hover:text-primary/80 font-medium"
                  >
                    ← Back to Dashboard
                  </button>
                </div>
              </div>
              <ReportsView />
            </div>
          )
        ) : null;
        
      case 'mis-reports':
        return (
          <MISReportsScreen onBack={handleBackToDashboard} />
        );
        
      case 'map':
        return (
          <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5">
            <div className="bg-white shadow-sm border-b mb-6">
              <div className="max-w-4xl mx-auto px-6 py-4">
                <button 
                  onClick={handleBackToDashboard}
                  className="text-primary hover:text-primary/80 font-medium"
                >
                  ← Back to Dashboard
                </button>
              </div>
            </div>
            <LocationManager />
          </div>
        );
        
      case 'profile':
        return (
          <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 p-6">
            <div className="max-w-md mx-auto">
              <button 
                onClick={handleBackToDashboard}
                className="text-primary hover:text-primary/80 font-medium mb-6"
              >
                ← Back to Dashboard
              </button>
              <div className="bg-white rounded-lg p-6 shadow-lg">
                <h2 className="text-xl font-semibold mb-4">Profile Settings</h2>
                <p className="text-muted-foreground">Profile settings coming soon...</p>
                <button
                  onClick={() => {
                    setCurrentScreen('login');
                    setUserData(null);
                  }}
                  className="mt-4 text-red-600 hover:text-red-700 font-medium"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        );
        

        
      default:
        return (
          <LoginScreen 
            onLogin={handleLogin}
            onCreateProfile={handleCreateProfile}
          />
        );
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <h1 className="text-xl font-semibold text-primary mb-2">Satra Services</h1>
          <p className="text-muted-foreground">Loading attendance tracker...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <DemoDataSeeder />
      {renderCurrentScreen()}
      <EnhancedOfflineIndicator />
      <Toaster />
    </ErrorBoundary>
  );
}