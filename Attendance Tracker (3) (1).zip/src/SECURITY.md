# Security Guide

This document outlines the security measures implemented in the Satra Services Attendance Tracker application and provides guidelines for maintaining security.

## 🔐 Security Features

### Input Validation & Sanitization

#### XSS Protection
All user inputs are sanitized to prevent Cross-Site Scripting (XSS) attacks:

```typescript
import { sanitizeInput } from './utils/security';

const cleanInput = sanitizeInput(userInput);
```

**Protected Fields:**
- Employee IDs
- Names
- Email addresses
- Text descriptions
- Task notes
- Location addresses

#### Validation Rules

**Employee ID:**
- 3-20 characters
- Alphanumeric, hyphens, and underscores only
- Required field

**Email:**
- Valid email format (RFC 5322)
- Case-insensitive
- Required for profiles

**Phone Number:**
- Indian format: +91XXXXXXXXXX or 10 digits
- Starts with 6-9
- Required for profiles

**Password:**
- Minimum 8 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number
- At least one special character
- No common patterns

### Authentication & Authorization

#### Password Security
- **Hashing**: All passwords should be hashed using bcrypt/argon2 (backend)
- **Strength Validation**: Client-side password strength checking
- **Never Stored**: Passwords never stored in localStorage or sessionStorage
- **Secure Transmission**: Always transmitted over HTTPS

#### Session Management
- **Secure Tokens**: JWT tokens with expiration
- **Token Storage**: Encrypted in secure storage
- **Auto-Logout**: Session timeout after inactivity
- **Refresh Tokens**: Automatic token refresh before expiration

#### Rate Limiting
Login attempts are rate-limited to prevent brute force attacks:

```typescript
import { ClientRateLimiter } from './utils/security';

const loginLimiter = new ClientRateLimiter({
  maxAttempts: 5,
  windowMs: 900000, // 15 minutes
  keyPrefix: 'login'
});

if (!loginLimiter.canProceed(employeeId)) {
  const remainingMs = loginLimiter.getRemainingTime(employeeId);
  throw new Error(`Too many login attempts. Try again in ${Math.ceil(remainingMs / 60000)} minutes`);
}
```

### Data Protection

#### Secure Storage
Sensitive data is encrypted before storage:

```typescript
import { SecureStorage } from './utils/security';

// Store encrypted
SecureStorage.setItem('user_token', token, true);

// Retrieve and decrypt
const token = SecureStorage.getItem('user_token', true);
```

**Encrypted Data:**
- Authentication tokens
- User session data
- Temporary credentials

**Never Stored:**
- Plain text passwords
- Credit card information
- Social security numbers

#### CSRF Protection
CSRF tokens are automatically included in state-changing requests:

```typescript
import { CSRFTokenManager } from './utils/security';

// Generate token on app initialization
const token = CSRFTokenManager.generateToken();

// Include in API requests
const headers = {
  ...otherHeaders,
  ...CSRFTokenManager.getHeaders()
};
```

### File Upload Security

#### Validation
All file uploads are validated:

```typescript
import { validateFileUpload } from './utils/security';

const validation = validateFileUpload(file, {
  maxSizeMB: 5,
  allowedTypes: ['image/jpeg', 'image/png'],
  allowedExtensions: ['.jpg', '.jpeg', '.png']
});

if (!validation.valid) {
  throw new Error(validation.error);
}
```

**Image Upload Restrictions:**
- Maximum size: 5MB
- Allowed formats: JPEG, PNG, WebP
- Filename sanitization
- MIME type verification

### Content Security Policy (CSP)

#### Violation Reporting
CSP violations are automatically logged:

```typescript
import { CSPViolationReporter } from './utils/security';

// Initialize on app load
CSPViolationReporter.init();
```

Violations are:
- Logged to console
- Stored in localStorage
- Available for review by administrators

#### Recommended CSP Headers
For production deployment, configure these CSP headers:

```
Content-Security-Policy:
  default-src 'self';
  script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net;
  style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
  img-src 'self' data: https: blob:;
  font-src 'self' https://fonts.gstatic.com;
  connect-src 'self' https://*.supabase.co https://sheets.googleapis.com;
  frame-ancestors 'none';
  base-uri 'self';
  form-action 'self';
```

## 🛡️ Error Handling & Logging

### Secure Error Messages
Error messages never expose sensitive information:

```typescript
// ❌ BAD - Exposes database structure
throw new Error(`User ${userId} not found in table users`);

// ✅ GOOD - Generic user-friendly message
throw new Error('User not found');
```

### Error Logging
Errors are logged without sensitive data:

```typescript
import { ErrorLogger } from './utils/errorHandling';

try {
  // Operation
} catch (error) {
  // Log error without exposing sensitive context
  ErrorLogger.log(error, {
    action: 'user_action',
    // Don't include: passwords, tokens, personal data
  });
}
```

## 🔒 API Security

### Request Security

#### Authentication Headers
```typescript
const headers = {
  'Authorization': `Bearer ${token}`,
  'Content-Type': 'application/json',
  ...CSRFTokenManager.getHeaders()
};
```

#### Request Timeout
All requests have timeouts to prevent hanging:

```typescript
const controller = new AbortController();
const timeoutId = setTimeout(() => controller.abort(), 15000);

fetch(url, {
  signal: controller.signal,
  ...options
});
```

#### Retry Logic
Failed requests use exponential backoff:

```typescript
import { RetryHandler } from './utils/errorHandling';

await RetryHandler.execute(
  async () => await fetch(url),
  {
    maxAttempts: 3,
    initialDelayMs: 1000,
    backoffMultiplier: 2
  }
);
```

### Response Validation
Always validate API responses:

```typescript
if (!response.ok) {
  // Handle error appropriately
  throw new Error(`API error: ${response.status}`);
}

const data = await response.json();

// Validate data structure
if (!data || typeof data !== 'object') {
  throw new Error('Invalid response format');
}
```

## 🌐 Network Security

### HTTPS Enforcement
- **Production**: Always use HTTPS
- **Development**: HTTP acceptable for localhost only
- **Mixed Content**: Block all HTTP resources in HTTPS pages

### CORS Configuration
Configure CORS appropriately in backend:

```typescript
// Allow only your domain
const allowedOrigins = [
  'https://your-domain.com',
  'https://www.your-domain.com'
];

if (allowedOrigins.includes(origin)) {
  response.headers.set('Access-Control-Allow-Origin', origin);
}
```

## 📱 Mobile Security

### Camera & Location Permissions
Always request permissions explicitly:

```typescript
// Request camera permission
const stream = await navigator.mediaDevices.getUserMedia({
  video: true
});

// Request location permission
navigator.geolocation.getCurrentPosition(
  (position) => { /* success */ },
  (error) => { /* handle error */ },
  {
    enableHighAccuracy: true,
    timeout: 15000,
    maximumAge: 0
  }
);
```

### Secure Photo Storage
Photos are stored securely:
- Never stored as plain files
- Converted to blob URLs
- Cleaned up after use
- Transmitted over HTTPS

## 🔍 Security Monitoring

### Audit Logging
All security-relevant events are logged:

```typescript
import { Analytics } from './utils/monitoring';

// Track security events
Analytics.track(
  EventType.USER_ACTION,
  'security',
  'login_attempt',
  employeeId,
  undefined,
  { success: true }
);
```

**Logged Events:**
- Login attempts (success and failure)
- Password changes
- Profile updates
- Attendance modifications
- Permission changes
- File uploads
- API errors

### Health Checks
Regular security health checks:

```typescript
import { HealthCheck } from './utils/monitoring';

// Run security health check
const results = await HealthCheck.runAll();

// Check for security issues
if (!results.get('localStorage')?.healthy) {
  console.warn('LocalStorage unavailable - fallback to memory storage');
}
```

## 🚨 Incident Response

### Security Incident Checklist

1. **Immediate Actions**
   - [ ] Identify affected users
   - [ ] Assess data exposure
   - [ ] Stop data leak if ongoing
   - [ ] Preserve evidence

2. **Investigation**
   - [ ] Review error logs
   - [ ] Check analytics events
   - [ ] Identify root cause
   - [ ] Document findings

3. **Remediation**
   - [ ] Fix vulnerability
   - [ ] Deploy patch
   - [ ] Verify fix
   - [ ] Monitor for recurrence

4. **Communication**
   - [ ] Notify affected users
   - [ ] Update stakeholders
   - [ ] Document incident
   - [ ] Conduct post-mortem

## 📋 Security Best Practices

### For Developers

1. **Never commit secrets**
   - Use environment variables
   - Add `.env` to `.gitignore`
   - Use placeholder values in examples

2. **Validate all inputs**
   - Server-side validation is mandatory
   - Client-side validation for UX
   - Sanitize before processing

3. **Use secure dependencies**
   - Regular dependency updates
   - Audit with `npm audit`
   - Use known secure libraries

4. **Follow principle of least privilege**
   - Minimum required permissions
   - Role-based access control
   - Regular permission reviews

5. **Implement defense in depth**
   - Multiple security layers
   - No single point of failure
   - Graceful degradation

### For Administrators

1. **Regular security audits**
   - Monthly vulnerability scans
   - Quarterly penetration testing
   - Annual security reviews

2. **Monitor security logs**
   - Daily log reviews
   - Alert on suspicious activity
   - Incident response plan ready

3. **User training**
   - Security awareness training
   - Phishing simulation
   - Password hygiene education

4. **Access control**
   - Regular access reviews
   - Immediate revocation for ex-employees
   - Multi-factor authentication

## 🔐 Environment Variables

### Required Variables
```env
# Supabase (Required)
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# Google OAuth (Optional)
VITE_GOOGLE_OAUTH_CLIENT_ID=your-client-id
VITE_GOOGLE_OAUTH_CLIENT_SECRET=your-client-secret

# Google Sheets (Optional)
VITE_GOOGLE_SHEETS_API_KEY=your-api-key
VITE_GOOGLE_SPREADSHEET_ID=your-spreadsheet-id
```

### Security Notes
- Never commit `.env` file
- Rotate credentials periodically
- Use different credentials for dev/staging/prod
- Limit API key permissions to minimum required

## 📞 Reporting Security Issues

If you discover a security vulnerability:

1. **DO NOT** create a public GitHub issue
2. Email: security@satraservices.com
3. Include:
   - Description of vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

We will respond within 48 hours.

## 📚 Additional Resources

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Web Security Basics](https://developer.mozilla.org/en-US/docs/Web/Security)
- [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP)
- [Supabase Security](https://supabase.com/docs/guides/platform/going-into-prod#security)

---

**Last Updated:** 2025-09-30  
**Security Version:** 2.0