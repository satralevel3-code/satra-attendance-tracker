# Testing Guide

Comprehensive testing guide for the Satra Services Attendance Tracker application.

## 📋 Table of Contents

- [Testing Strategy](#testing-strategy)
- [Test Types](#test-types)
- [Manual Testing](#manual-testing)
- [Automated Testing](#automated-testing)
- [Test Data](#test-data)
- [Performance Testing](#performance-testing)
- [Security Testing](#security-testing)
- [Cross-Browser Testing](#cross-browser-testing)
- [Mobile Testing](#mobile-testing)
- [Accessibility Testing](#accessibility-testing)

## 🎯 Testing Strategy

### Testing Pyramid

```
                /\
               /  \
              / E2E \
             /______\
            /        \
           /Integration\
          /____________\
         /              \
        /  Unit Tests    \
       /________________\
```

**Unit Tests (70%)**: Individual functions and components  
**Integration Tests (20%)**: Component interactions and API calls  
**End-to-End Tests (10%)**: Full user workflows

## 🧪 Test Types

### 1. Functional Testing

Tests that verify the application functions correctly.

**Key Areas:**
- User authentication
- Attendance marking flow
- Report generation
- Profile management
- Location tracking
- Photo capture

### 2. Integration Testing

Tests that verify different parts work together.

**Key Areas:**
- API integration
- Database operations
- Google Sheets sync
- Offline queue processing

### 3. Performance Testing

Tests that verify application performance.

**Key Metrics:**
- Page load time < 3 seconds
- First Contentful Paint < 1.5 seconds
- Time to Interactive < 3.5 seconds
- Largest Contentful Paint < 2.5 seconds

### 4. Security Testing

Tests that verify security measures.

**Key Areas:**
- Input validation
- XSS prevention
- CSRF protection
- Authentication bypass attempts
- Authorization checks

## 📝 Manual Testing

### Executive User Flow

#### Test Case 1: Login
1. Navigate to application
2. Enter valid executive credentials
3. Click "Login"
4. **Expected**: Redirect to Executive Dashboard
5. **Verify**: User name and role displayed correctly

#### Test Case 2: Mark Attendance
1. Login as executive
2. Click "Mark Attendance"
3. Verify status is "Present"
4. Click "Continue"
5. Enter task description
6. Click "Continue"
7. Select workplace
8. Click "Start Camera"
9. **Expected**: Camera starts automatically
10. **Expected**: Location captured automatically
11. Position face and click "Capture Photo"
12. Review photo
13. Click "Confirm Attendance"
14. **Expected**: Success message
15. **Expected**: Return to dashboard

#### Test Case 3: View History
1. Login as executive
2. Click "View History"
3. **Expected**: Calendar view displayed
4. Click on a date with attendance
5. **Expected**: Attendance details shown
6. **Verify**: Photo, location, task visible

### Admin User Flow

#### Test Case 4: View Dashboard
1. Login as admin
2. **Expected**: Dashboard with statistics
3. **Verify**: Today's attendance count
4. **Verify**: Present/Absent counts
5. **Verify**: Attendance percentage

#### Test Case 5: Filter Attendance
1. Login as admin
2. Select date from date picker
3. **Expected**: Attendance filtered by date
4. Select DCCB from dropdown
5. **Expected**: Attendance filtered by DCCB
6. **Verify**: Results match filters

#### Test Case 6: Download Report
1. Login as admin
2. Apply desired filters
3. Click "Download CSV"
4. **Expected**: CSV file downloaded
5. Open CSV file
6. **Verify**: Data matches displayed results
7. **Verify**: All columns present

### Offline Testing

#### Test Case 7: Offline Attendance Marking
1. Login as executive
2. Disconnect from network (Airplane mode)
3. Mark attendance
4. **Expected**: Offline indicator shown
5. **Expected**: Attendance queued
6. Reconnect to network
7. **Expected**: Auto-sync triggered
8. **Expected**: Attendance appears on server

### Error Handling

#### Test Case 8: Network Error
1. Start marking attendance
2. Disconnect network during process
3. **Expected**: Error message displayed
4. **Expected**: User-friendly message
5. **Expected**: Retry option available

#### Test Case 9: Permission Denied
1. Start marking attendance
2. Deny camera permission
3. **Expected**: Permission error shown
4. **Expected**: Instructions to enable
5. Deny location permission
6. **Expected**: Location error shown

## 🤖 Automated Testing

### Unit Tests

Example unit test structure:

```typescript
import { describe, it, expect } from 'vitest';
import { validateEmployeeId } from '../utils/security';

describe('validateEmployeeId', () => {
  it('should accept valid employee ID', () => {
    const result = validateEmployeeId('EMP001');
    expect(result.valid).toBe(true);
  });

  it('should reject empty employee ID', () => {
    const result = validateEmployeeId('');
    expect(result.valid).toBe(false);
    expect(result.error).toBe('Employee ID is required');
  });

  it('should reject short employee ID', () => {
    const result = validateEmployeeId('AB');
    expect(result.valid).toBe(false);
    expect(result.error).toContain('at least 3 characters');
  });

  it('should reject special characters', () => {
    const result = validateEmployeeId('EMP@001');
    expect(result.valid).toBe(false);
  });
});
```

### Integration Tests

Example integration test:

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import { attendanceAPI } from '../utils/supabase/client';

describe('Attendance API', () => {
  beforeEach(() => {
    // Setup test data
  });

  it('should mark attendance successfully', async () => {
    const attendance = {
      employeeId: 'TEST001',
      status: 'present',
      date: new Date().toISOString().split('T')[0]
    };

    const result = await attendanceAPI.markAttendance(attendance);
    expect(result.success).toBe(true);
    expect(result.id).toBeDefined();
  });

  it('should retrieve attendance history', async () => {
    const history = await attendanceAPI.getAttendanceHistory('TEST001');
    expect(Array.isArray(history)).toBe(true);
  });
});
```

### E2E Tests

Example E2E test with Playwright:

```typescript
import { test, expect } from '@playwright/test';

test.describe('Executive Attendance Flow', () => {
  test('should complete full attendance marking flow', async ({ page, context }) => {
    // Grant permissions
    await context.grantPermissions(['camera', 'geolocation']);

    // Login
    await page.goto('/');
    await page.fill('[name="employeeId"]', 'DC001');
    await page.fill('[name="password"]', 'demo123');
    await page.click('button[type="submit"]');

    // Verify dashboard
    await expect(page.locator('h1')).toContainText('Dashboard');

    // Mark attendance
    await page.click('text=Mark Attendance');
    await page.click('text=Continue');
    
    // Enter task
    await page.fill('textarea', 'Testing attendance flow');
    await page.click('text=Continue');
    
    // Select workplace
    await page.click('[role="combobox"]');
    await page.click('text=Head Office');
    await page.click('text=Start Camera');

    // Wait for camera and location
    await page.waitForSelector('video');
    await page.waitForSelector('text=Location captured');

    // Capture photo
    await page.click('text=Capture Photo');

    // Confirm
    await page.click('text=Confirm Attendance');

    // Verify success
    await expect(page.locator('text=successfully')).toBeVisible();
  });
});
```

## 📊 Test Data

### Demo Credentials

#### Executive Users
```typescript
const executiveUsers = [
  { employeeId: 'DC001', password: 'demo123', designation: 'District Coordinator' },
  { employeeId: 'DC002', password: 'demo123', designation: 'District Coordinator' },
  { employeeId: 'MT001', password: 'demo123', designation: 'Medical Technician' },
  { employeeId: 'MT002', password: 'demo123', designation: 'Medical Technician' }
];
```

#### Admin Users
```typescript
const adminUsers = [
  { employeeId: 'ADMIN01', password: 'admin123', designation: 'State Manager' },
  { employeeId: 'HR001', password: 'admin123', designation: 'HR Manager' },
  { employeeId: 'MGR001', password: 'admin123', designation: 'Delivery Head' }
];
```

### Test Attendance Records

```typescript
const testAttendance = {
  employeeId: 'DC001',
  name: 'Test User',
  date: '2025-09-30',
  checkInTime: '09:15:00',
  status: 'present',
  location: {
    latitude: 23.0225,
    longitude: 72.5714,
    accuracy: 10,
    address: 'Ahmedabad, Gujarat'
  },
  notes: 'Test attendance entry',
  workLocation: 'Head Office'
};
```

## 🚀 Performance Testing

### Lighthouse Audit

Run Lighthouse audit:

```bash
npm install -g lighthouse
lighthouse http://localhost:5173 --view
```

**Target Scores:**
- Performance: > 90
- Accessibility: > 90
- Best Practices: > 90
- SEO: > 90
- PWA: > 90

### Web Vitals Monitoring

```typescript
import { PerformanceMonitor } from './utils/performance';

// Track page load
PerformanceMonitor.mark('page-load-start');
// ... page loads
PerformanceMonitor.mark('page-load-end');
PerformanceMonitor.measure('page-load', 'page-load-start', 'page-load-end');

// Get metrics
const stats = PerformanceMonitor.getStats('page-load');
console.log('Average page load:', stats.avg, 'ms');
```

### Load Testing

Simulate multiple users:

```bash
# Using artillery
npm install -g artillery
artillery quick --count 50 --num 100 http://localhost:5173
```

## 🔒 Security Testing

### XSS Testing

Test inputs with XSS payloads:

```typescript
const xssPayloads = [
  '<script>alert("XSS")</script>',
  '<img src=x onerror=alert("XSS")>',
  'javascript:alert("XSS")',
  '<svg/onload=alert("XSS")>'
];

xssPayloads.forEach(payload => {
  const result = sanitizeInput(payload);
  expect(result).not.toContain('<script>');
  expect(result).not.toContain('javascript:');
  expect(result).not.toContain('onerror');
});
```

### SQL Injection Testing

Test with SQL injection attempts:

```typescript
const sqlInjectionPayloads = [
  "' OR '1'='1",
  "'; DROP TABLE users--",
  "' UNION SELECT * FROM users--"
];

// These should be safely handled
sqlInjectionPayloads.forEach(payload => {
  const result = validateEmployeeId(payload);
  expect(result.valid).toBe(false);
});
```

### CSRF Testing

Verify CSRF token is required:

```typescript
// Request without CSRF token should fail
const response = await fetch('/api/attendance', {
  method: 'POST',
  body: JSON.stringify(data)
});

expect(response.status).toBe(403);

// Request with CSRF token should succeed
const responseWithToken = await fetch('/api/attendance', {
  method: 'POST',
  headers: CSRFTokenManager.getHeaders(),
  body: JSON.stringify(data)
});

expect(responseWithToken.ok).toBe(true);
```

## 🌐 Cross-Browser Testing

### Browsers to Test

- ✅ Chrome 90+ (Windows, Mac, Android)
- ✅ Firefox 88+ (Windows, Mac)
- ✅ Safari 14+ (Mac, iOS)
- ✅ Edge 90+ (Windows)
- ✅ Opera 76+ (Windows, Mac)

### BrowserStack Configuration

```javascript
// wdio.conf.js
exports.config = {
  user: process.env.BROWSERSTACK_USERNAME,
  key: process.env.BROWSERSTACK_ACCESS_KEY,
  services: ['browserstack'],
  capabilities: [
    {
      browserName: 'Chrome',
      browser_version: 'latest',
      os: 'Windows',
      os_version: '10'
    },
    {
      browserName: 'Safari',
      browser_version: '14',
      os: 'OS X',
      os_version: 'Big Sur'
    },
    // ... more browsers
  ]
};
```

## 📱 Mobile Testing

### Device Testing Matrix

| Device | OS | Browser | Screen Size |
|--------|----|---------|----|
| iPhone 12 | iOS 15 | Safari | 390x844 |
| iPhone SE | iOS 15 | Safari | 375x667 |
| Samsung Galaxy S21 | Android 11 | Chrome | 360x800 |
| iPad Pro | iOS 15 | Safari | 1024x1366 |
| Pixel 5 | Android 12 | Chrome | 393x851 |

### Mobile-Specific Tests

#### Test Case 10: Camera on Mobile
1. Open on mobile device
2. Login as executive
3. Mark attendance
4. **Expected**: Camera switches to front-facing
5. **Expected**: Camera preview full width
6. **Expected**: Capture button large and accessible

#### Test Case 11: Touch Gestures
1. Test swipe gestures
2. Test pinch-to-zoom (where applicable)
3. Test tap targets (minimum 44x44px)
4. Test scroll performance

#### Test Case 12: Orientation Changes
1. Start in portrait mode
2. Rotate to landscape
3. **Expected**: Layout adapts
4. **Expected**: No data loss
5. Rotate back to portrait
6. **Expected**: Layout adapts back

## ♿ Accessibility Testing

### WCAG 2.1 AA Compliance

#### Automated Testing

```bash
# Using axe-core
npm install -g @axe-core/cli
axe http://localhost:5173
```

#### Manual Testing Checklist

- [ ] All images have alt text
- [ ] Form inputs have associated labels
- [ ] Color contrast ratio ≥ 4.5:1
- [ ] Keyboard navigation works
- [ ] Focus indicators visible
- [ ] ARIA labels where needed
- [ ] Heading hierarchy logical
- [ ] Screen reader compatible

#### Keyboard Navigation Tests

1. **Tab Order**
   - Press Tab repeatedly
   - **Expected**: Logical focus order
   - **Expected**: All interactive elements reachable

2. **Skip Navigation**
   - Press Tab once
   - **Expected**: "Skip to main content" link
   - Press Enter
   - **Expected**: Focus moves to main content

3. **Form Interaction**
   - Navigate to login form
   - Use Tab to navigate between fields
   - Press Enter to submit
   - **Expected**: Form submits

#### Screen Reader Testing

**VoiceOver (Mac/iOS):**
```
Cmd + F5 to enable
Ctrl + Option + → to navigate
```

**NVDA (Windows):**
```
Ctrl + Alt + N to start
↓ to navigate
```

## 🔧 Test Utilities

### Mock Data Generator

```typescript
export const generateMockAttendance = (count: number) => {
  const records = [];
  for (let i = 0; i < count; i++) {
    records.push({
      employeeId: `TEST${String(i).padStart(3, '0')}`,
      name: `Test User ${i}`,
      date: new Date().toISOString().split('T')[0],
      status: ['present', 'absent', 'half-day'][Math.floor(Math.random() * 3)],
      location: {
        latitude: 23 + Math.random(),
        longitude: 72 + Math.random(),
        accuracy: 10
      }
    });
  }
  return records;
};
```

### API Mocking

```typescript
// Mock API responses
export const mockAPI = {
  login: jest.fn().mockResolvedValue({
    user: { employeeId: 'TEST001', name: 'Test User' },
    token: 'mock-token'
  }),
  
  markAttendance: jest.fn().mockResolvedValue({
    success: true,
    id: 'mock-id'
  }),
  
  getAttendanceHistory: jest.fn().mockResolvedValue([
    /* mock attendance records */
  ])
};
```

## 📈 Test Coverage

### Target Coverage
- Overall: > 80%
- Utilities: > 90%
- Components: > 70%
- Services: > 85%

### Generate Coverage Report

```bash
npm run test:coverage
```

### View Coverage

```bash
open coverage/index.html
```

## 🐛 Bug Reporting Template

```markdown
### Bug Description
[Clear description of the bug]

### Steps to Reproduce
1. [First step]
2. [Second step]
3. [...]

### Expected Behavior
[What should happen]

### Actual Behavior
[What actually happens]

### Environment
- Browser: [e.g., Chrome 96]
- OS: [e.g., Windows 10]
- Device: [e.g., iPhone 12]
- App Version: [e.g., 2.0.0]

### Screenshots
[If applicable]

### Additional Context
[Any other relevant information]

### Error Logs
```
[Paste relevant console errors]
```
```

## ✅ Test Checklist

Before each release:

- [ ] All unit tests pass
- [ ] All integration tests pass
- [ ] All E2E tests pass
- [ ] Manual smoke tests completed
- [ ] Performance benchmarks met
- [ ] Security tests passed
- [ ] Cross-browser testing completed
- [ ] Mobile testing completed
- [ ] Accessibility audit passed
- [ ] No console errors in production build
- [ ] Test coverage meets targets

---

**Last Updated:** 2025-09-30  
**Version:** 2.0