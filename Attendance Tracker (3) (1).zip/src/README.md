# Satra Services Attendance Tracker

A production-ready, mobile-first attendance tracking application for managing 200+ executives across Gujarat state.

## 🚀 Features

### Core Functionality
- **📍 Geo-Located Attendance**: Mark attendance with automatic GPS location capture
- **📸 Photo Verification**: Self-photo capture with each attendance entry
- **👥 Role-Based Access**: Separate dashboards for Executives and Admins
- **📊 Real-Time Dashboard**: Live attendance statistics and analytics
- **📱 Mobile-First Design**: Optimized for smartphones with responsive layout
- **🔄 Offline Support**: Queue attendance when offline, sync when connected
- **📈 Comprehensive Reports**: Daily, monthly, and custom date range reports
- **🗺️ Location Management**: Manage work locations across Gujarat

### Executive Features (DC/MT Designations)
- Mark daily attendance (Present/Absent/Half-day)
- Upload workplace photos with automatic location capture
- Update daily tasks and work descriptions
- View personal attendance history via calendar
- Track attendance statistics

### Admin Features (HR/Manager/SPMU/Delivery Head)
- View real-time attendance dashboard
- Monitor all executive attendance
- Download CSV reports
- Manage executive profiles
- Edit/delete attendance records
- Reset passwords
- Comprehensive MIS reports with filtering
- Location management across Gujarat

## 🏗️ Architecture

### Technology Stack
- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS v4.0
- **UI Components**: Shadcn/ui
- **State Management**: React Hooks
- **Backend**: Supabase (PostgreSQL + Edge Functions)
- **Offline Storage**: IndexedDB + LocalStorage
- **Maps/Location**: Google Maps API + Geolocation API
- **Sheets Integration**: Google Sheets API

### Project Structure

```
attendance-tracker/
├── App.tsx                      # Main application entry point
├── components/                  # React components
│   ├── ui/                     # Shadcn UI components
│   ├── AdminDashboard.tsx      # Admin role dashboard
│   ├── ExecutiveDashboard.tsx  # Executive role dashboard
│   ├── AttendanceMarkingScreen.tsx
│   ├── LoginScreen.tsx
│   ├── MISReportsScreen.tsx
│   └── ...
├── services/                    # Business logic services
│   ├── GoogleSheetsService.ts  # Google Sheets integration
│   └── LocationService.ts      # Geolocation services
├── utils/                       # Utility functions
│   ├── security.ts             # Security & validation
│   ├── errorHandling.ts        # Error handling & resilience
│   ├── offlineQueue.ts         # Offline sync queue
│   ├── performance.ts          # Performance monitoring
│   ├── monitoring.ts           # Analytics & health checks
│   └── supabase/               # Supabase client
├── styles/
│   └── globals.css             # Global styles & Tailwind config
└── supabase/functions/         # Backend edge functions
```

## 📋 Prerequisites

- Node.js 18+ and npm/yarn
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Camera access permission
- Location access permission
- Internet connection (with offline fallback)

## 🔧 Installation & Setup

### 1. Clone the Repository

```bash
git clone <repository-url>
cd attendance-tracker
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Environment Configuration

Create a `.env` file in the root directory:

```env
# Supabase Configuration
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# Google Sheets API (Optional)
VITE_GOOGLE_SHEETS_API_KEY=your-api-key
VITE_GOOGLE_SPREADSHEET_ID=your-spreadsheet-id

# Google OAuth (Optional)
VITE_GOOGLE_OAUTH_CLIENT_ID=your-oauth-client-id
VITE_GOOGLE_OAUTH_CLIENT_SECRET=your-oauth-client-secret

# Google Maps API (Optional)
VITE_GOOGLE_MAPS_API_KEY=your-maps-api-key
```

### 4. Supabase Setup

#### Option A: Connect Existing Supabase Project
1. Visit [Supabase Dashboard](https://app.supabase.com)
2. Copy your project URL and anon key
3. Update `.env` file with your credentials

#### Option B: Use Built-in Demo Mode
The application includes demo data for testing without Supabase:
- Demo credentials are available in `DemoDataSeeder` component
- Attendance data stored in localStorage
- Full offline functionality

### 5. Google Sheets Setup (Optional)

For Google Sheets integration:

1. **Create/Enable Google Sheets API**
   - Go to [Google Cloud Console](https://console.cloud.google.com)
   - Create new project or select existing
   - Enable Google Sheets API
   - Enable Google Drive API

2. **Create OAuth Credentials**
   - Navigate to APIs & Services > Credentials
   - Create OAuth 2.0 Client ID
   - Add authorized redirect URI: `http://localhost:5173/oauth/callback`
   - Copy client ID and secret to `.env`

3. **Prepare Spreadsheet**
   - Create spreadsheet with required sheets:
     - "Register Employee Sheet"
     - "EMPID and Password"
     - "Daily Attendance"
     - "Attendance Summary"
   - Share with service account email or make publicly accessible

For detailed Google Sheets setup, see [google-api-key-setup.md](./google-api-key-setup.md)

## 🚀 Running the Application

### Development Mode

```bash
npm run dev
```

Application will be available at `http://localhost:5173`

### Production Build

```bash
npm run build
npm run preview
```

### Testing with Demo Data

The app includes a `DemoDataSeeder` that automatically loads sample data:

**Demo Executive Login:**
- Employee ID: `DC001`, `DC002`, `MT001`, `MT002`
- Password: `demo123`

**Demo Admin Login:**
- Employee ID: `ADMIN01`, `HR001`, `MGR001`
- Password: `admin123`

## 🔐 Security Features

### Client-Side Security
- ✅ Input sanitization (XSS protection)
- ✅ Password strength validation
- ✅ Employee ID validation
- ✅ Email & phone number validation
- ✅ Rate limiting on login attempts
- ✅ Secure storage wrapper for sensitive data
- ✅ CSRF token management
- ✅ File upload validation

### Best Practices Implemented
- All user inputs sanitized
- Passwords never stored in plain text
- Secure localStorage encryption
- Content Security Policy monitoring
- Error logging without exposing sensitive data

## 📱 PWA & Offline Support

### Offline Capabilities
- ✅ Attendance marking when offline
- ✅ Automatic sync when connection restored
- ✅ Queue management for pending operations
- ✅ Local data persistence
- ✅ Offline status indicator

### Service Worker Features
- Asset caching for fast load times
- Background sync for queued operations
- Network-first strategy for API calls
- Cache-first strategy for static assets

## 📊 Monitoring & Analytics

### Performance Monitoring
- Web Vitals tracking (FCP, LCP, FID, CLS)
- API response time monitoring
- Long task detection
- Custom performance markers

### Analytics Events Tracked
- Page views
- User actions
- Attendance submissions
- Login/logout events
- API calls success/failure
- Error occurrences
- Offline/online transitions

### Health Checks
- Network connectivity
- LocalStorage availability
- IndexedDB availability
- Geolocation availability
- Camera availability

## 🐛 Error Handling

### Error Categories
- **Network Errors**: Retry with exponential backoff
- **Validation Errors**: User-friendly messages
- **Authentication Errors**: Auto-redirect to login
- **Authorization Errors**: Permission denied handling
- **System Errors**: Graceful degradation

### Resilience Patterns
- **Retry Handler**: Automatic retry with exponential backoff
- **Circuit Breaker**: Prevent cascading failures
- **Graceful Degradation**: Fallback to cached data
- **Error Boundary**: Component-level error isolation

## 📖 API Documentation

### Supabase Edge Functions

#### Authentication
```typescript
POST /api/login
Body: { employeeId: string, password: string }
Response: { user: UserData, token: string }
```

#### Attendance
```typescript
POST /api/attendance
Body: AttendanceRecord
Response: { success: boolean, id: string }

GET /api/attendance/:employeeId/history
Response: AttendanceRecord[]

GET /api/attendance/:employeeId/today
Response: AttendanceRecord | null
```

#### Reports
```typescript
GET /api/reports/daily?date=YYYY-MM-DD&dccb=string
Response: DailyReport

GET /api/reports/dashboard-stats
Response: DashboardStats
```

### Error Responses
All API errors follow this format:
```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "details": {}
}
```

## 🧪 Testing

### Manual Testing Checklist

#### Executive Flow
- [ ] Login with executive credentials
- [ ] Mark attendance (Present)
- [ ] Capture photo successfully
- [ ] Location captured automatically
- [ ] Task description saved
- [ ] Workplace selected
- [ ] View attendance calendar
- [ ] Check attendance history

#### Admin Flow
- [ ] Login with admin credentials
- [ ] View dashboard statistics
- [ ] Filter attendance by date
- [ ] Filter by DCCB/department
- [ ] Download CSV report
- [ ] View executive details
- [ ] Manage locations

#### Offline Testing
- [ ] Mark attendance while offline
- [ ] Verify queued in offline queue
- [ ] Go back online
- [ ] Verify automatic sync
- [ ] Check sync status

### Browser Compatibility
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

## 🚢 Deployment

### Deploying Frontend

#### Option 1: Vercel
```bash
npm install -g vercel
vercel
```

#### Option 2: Netlify
```bash
npm install -g netlify-cli
netlify deploy
```

#### Option 3: Static Hosting
```bash
npm run build
# Upload dist/ folder to your hosting provider
```

### Environment Variables in Production
Ensure all environment variables are set in your hosting provider:
- Supabase URL and keys
- Google API credentials (if using)
- Any other third-party API keys

### Supabase Edge Functions
Deploy edge functions to Supabase:

```bash
supabase functions deploy make-server
```

## 📚 Additional Documentation

- [Deployment Guide](./DEPLOYMENT_GUIDE.md) - Detailed deployment instructions
- [Google Sheets Setup](./google-api-key-setup.md) - Google Sheets API configuration
- [Guidelines](./guidelines/Guidelines.md) - Development guidelines and best practices
- [Attributions](./Attributions.md) - Third-party libraries and credits

## 🔍 Troubleshooting

### Common Issues

#### Camera Not Working
- **Cause**: Permission denied or no camera available
- **Solution**: Check browser permissions, ensure HTTPS in production

#### Location Not Captured
- **Cause**: Location permission denied or GPS unavailable
- **Solution**: Enable location services, check browser permissions

#### Offline Sync Not Working
- **Cause**: Service worker not registered or queue disabled
- **Solution**: Check console for errors, ensure service worker is active

#### Google Sheets 403 Error
- **Cause**: Sheet not shared or API not enabled
- **Solution**: Share sheet with service account, enable Google Sheets API

### Debug Mode
Enable debug logging:
```javascript
localStorage.setItem('debug', 'true');
```

View error logs:
```javascript
// In browser console
ErrorLogger.getErrors();
Analytics.getEvents();
```

## 👥 User Roles & Permissions

| Feature | Executive (DC/MT) | Admin (HR/Manager/SPMU) |
|---------|------------------|------------------------|
| Mark Attendance | ✅ | ❌ |
| View Own History | ✅ | ✅ |
| View Dashboard | Limited | Full Access |
| Download Reports | ❌ | ✅ |
| Manage Profiles | ❌ | ✅ |
| Edit Attendance | ❌ | ✅ |
| Reset Passwords | ❌ | ✅ |
| Manage Locations | ❌ | ✅ |

## 📄 License

Proprietary - Satra Services

## 🤝 Support

For technical support:
- Email: support@satraservices.com
- Phone: +91 XXXXX XXXXX

## 📝 Changelog

### Version 2.0.0 (Current)
- ✅ Production-ready enhancements
- ✅ Comprehensive error handling
- ✅ Offline queue management
- ✅ Performance monitoring
- ✅ Security hardening
- ✅ Analytics integration
- ✅ Enhanced documentation

### Version 1.0.0
- Initial release
- Basic attendance marking
- Admin and executive dashboards
- Google Sheets integration
- Supabase backend

---

**Built with ❤️ for Satra Services**