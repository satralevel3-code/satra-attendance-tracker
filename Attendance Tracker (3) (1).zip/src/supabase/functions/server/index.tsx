import { Hono } from "npm:hono@4.3.11";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2.39.3";
import * as kv from "./kv_store.tsx";
import { seedDatabase } from "./seed_data.tsx";

const app = new Hono();

// Enable CORS and logging
app.use(
  "*",
  cors({
    origin: "*",
    allowHeaders: ["*"],
    allowMethods: ["POST", "GET", "OPTIONS", "PUT", "DELETE"],
  }),
);
app.use("*", logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// Employee Management Routes
app.post("/make-server-112ca9a8/employees", async (c) => {
  try {
    const employeeData = await c.req.json();

    // Generate EmployeeID if not provided
    if (!employeeData.employeeId) {
      const count = await kv.getByPrefix("employee:");
      const nextId = String(count.length + 1).padStart(5, "0");
      employeeData.employeeId = `MGJ${nextId}`;
    }

    // Check if employee ID already exists
    const existingEmployee = await kv.get(`employee:${employeeData.employeeId}`);
    if (existingEmployee) {
      return c.json(
        { success: false, error: "Employee ID already exists" },
        409
      );
    }

    // Create employee record
    const employee = {
      employeeId: employeeData.employeeId,
      firstName: employeeData.firstName,
      lastName: employeeData.lastName,
      name: employeeData.name || `${employeeData.firstName} ${employeeData.lastName}`,
      fullName: employeeData.name || `${employeeData.firstName} ${employeeData.lastName}`,
      designation: employeeData.designation,
      department: employeeData.department || employeeData.dccb || null,
      dccb: employeeData.dccb || null,
      reportingManager: employeeData.reportingManager || employeeData.reportingTo || null,
      reportingTo: employeeData.reportingTo || null,
      contactNumber: employeeData.contactNumber,
      phoneNumber: employeeData.phoneNumber || employeeData.contactNumber,
      contactAlt: employeeData.alternateContact || null,
      email: employeeData.email,
      address: employeeData.address || null,
      pinCode: employeeData.pinNumber || null,
      workLocations: employeeData.workLocations || (employeeData.dccb ? [employeeData.dccb] : ['HEAD_OFFICE']),
      status: employeeData.status || 'active',
      joinedOn: new Date().toISOString().split("T")[0],
      isActive: true,
      createdOn: new Date().toISOString(),
      createdBy: employeeData.createdBy || "system",
      password: employeeData.password, // In production, this should be hashed
    };

    await kv.set(`employee:${employee.employeeId}`, employee);

    // Log the action
    await kv.set(`audit:${Date.now()}`, {
      logId: Date.now(),
      action: "Created Employee",
      employeeId: employee.employeeId,
      doneBy: employee.createdBy,
      timestamp: new Date().toISOString(),
      details: `Employee ${employee.fullName} created`,
    });

    return c.json({
      success: true,
      employeeId: employee.employeeId,
      employee,
    });
  } catch (error) {
    console.log("Error creating employee:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

app.get(
  "/make-server-112ca9a8/employees/:employeeId",
  async (c) => {
    try {
      const employeeId = c.req.param("employeeId");
      const employee = await kv.get(`employee:${employeeId}`);

      if (!employee) {
        return c.json(
          { success: false, error: "Employee not found" },
          404,
        );
      }

      return c.json({ success: true, employee });
    } catch (error) {
      console.log("Error fetching employee:", error);
      return c.json(
        { success: false, error: error.message },
        500,
      );
    }
  },
);

app.get("/make-server-112ca9a8/employees", async (c) => {
  try {
    // Add timeout protection
    const employeePromise = kv.getByPrefix("employee:");
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Employee fetch timeout')), 10000)
    );
    
    const employees = await Promise.race([employeePromise, timeoutPromise]);
    const activeEmployees = employees.filter(
      (emp) => emp && emp.isActive !== false,
    );

    return c.json({
      success: true,
      employees: activeEmployees.slice(0, 500), // Limit results
    });
  } catch (error) {
    console.log("Error fetching employees:", error);
    // Return fallback data instead of complete failure
    return c.json({
      success: true,
      employees: [], // Return empty array to prevent app crashes
      fallback: true,
      error: "Employee data temporarily unavailable"
    });
  }
});

// Authentication Routes
app.post("/make-server-112ca9a8/login", async (c) => {
  try {
    const { employeeId, password } = await c.req.json();

    const employee = await kv.get(`employee:${employeeId}`);

    if (!employee || employee.password !== password) {
      return c.json(
        { success: false, error: "Invalid credentials" },
        401,
      );
    }

    if (!employee.isActive) {
      return c.json(
        { success: false, error: "Account deactivated" },
        401,
      );
    }

    // Log the action
    await kv.set(`audit:${Date.now()}`, {
      logId: Date.now(),
      action: "User Login",
      employeeId: employee.employeeId,
      doneBy: employee.employeeId,
      timestamp: new Date().toISOString(),
      details: `${employee.fullName} logged in`,
    });

    // Return user data without password
    const { password: _, ...userData } = employee;
    return c.json({ success: true, user: userData });
  } catch (error) {
    console.log("Error during login:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

// Attendance Management Routes
app.post("/make-server-112ca9a8/attendance", async (c) => {
  try {
    const attendanceData = await c.req.json();

    const attendanceRecord = {
      attendanceId: `att_${Date.now()}_${attendanceData.employeeId}`,
      employeeId: attendanceData.employeeId,
      date: new Date().toISOString().split("T")[0],
      status: attendanceData.status,
      task: attendanceData.task || null,
      workplace: attendanceData.workplace || null,
      timestamp: new Date().toISOString(),
      photoUrl: attendanceData.photoUrl || null,
      locationLat: attendanceData.locationLat || null,
      locationLng: attendanceData.locationLng || null,
      locationLink:
        attendanceData.locationLat && attendanceData.locationLng
          ? `https://maps.google.com/?q=${attendanceData.locationLat},${attendanceData.locationLng}`
          : null,
      locationAddress: attendanceData.locationAddress || null,
      deviceId: attendanceData.deviceId || null,
      submittedFrom:
        attendanceData.submittedFrom || "MobileApp",
      remarks: attendanceData.remarks || null,
    };

    // Check if attendance already marked for today
    const todayKey = `attendance:${attendanceData.employeeId}:${attendanceRecord.date}`;
    const existingAttendance = await kv.get(todayKey);

    if (existingAttendance) {
      return c.json(
        {
          success: false,
          error: "Attendance already marked for today",
        },
        400,
      );
    }

    await kv.set(todayKey, attendanceRecord);
    await kv.set(
      `attendance_log:${attendanceRecord.attendanceId}`,
      attendanceRecord,
    );

    // Log the action
    await kv.set(`audit:${Date.now()}`, {
      logId: Date.now(),
      action: "Marked Attendance",
      employeeId: attendanceData.employeeId,
      doneBy: attendanceData.employeeId,
      timestamp: new Date().toISOString(),
      details: `Attendance marked as ${attendanceData.status}`,
    });

    return c.json({
      success: true,
      attendance: attendanceRecord,
    });
  } catch (error) {
    console.log("Error marking attendance:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

app.get(
  "/make-server-112ca9a8/attendance/:employeeId/today",
  async (c) => {
    try {
      const employeeId = c.req.param("employeeId");
      const today = new Date().toISOString().split("T")[0];
      const todayKey = `attendance:${employeeId}:${today}`;

      const attendance = await kv.get(todayKey);

      return c.json({ success: true, attendance });
    } catch (error) {
      console.log("Error fetching today attendance:", error);
      return c.json(
        { success: false, error: error.message },
        500,
      );
    }
  },
);

app.get(
  "/make-server-112ca9a8/attendance/:employeeId/history",
  async (c) => {
    try {
      const employeeId = c.req.param("employeeId");
      const attendanceRecords = await kv.getByPrefix(
        `attendance:${employeeId}:`,
      );

      // Sort by date descending
      attendanceRecords.sort(
        (a, b) => new Date(b.date) - new Date(a.date),
      );

      return c.json({
        success: true,
        attendance: attendanceRecords,
      });
    } catch (error) {
      console.log("Error fetching attendance history:", error);
      return c.json(
        { success: false, error: error.message },
        500,
      );
    }
  },
);

// Reports Routes
app.get("/make-server-112ca9a8/reports/daily", async (c) => {
  try {
    const date =
      c.req.query("date") ||
      new Date().toISOString().split("T")[0];
    const dccb = c.req.query("dccb");

    // More efficient: get attendance for specific date pattern
    const todayAttendancePattern = `attendance:*:${date}`;
    let attendanceRecords = [];
    
    try {
      // Get all attendance records for the specific date
      const allAttendance = await kv.getByPrefix("attendance:");
      attendanceRecords = allAttendance.filter(record => record.date === date);
    } catch (error) {
      console.log("Using fallback attendance data due to error:", error);
      attendanceRecords = [];
    }

    // Get employee data - with timeout protection
    let employees = [];
    try {
      const employeePromise = kv.getByPrefix("employee:");
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Employee fetch timeout')), 10000)
      );
      employees = await Promise.race([employeePromise, timeoutPromise]);
    } catch (error) {
      console.log("Using fallback employee data due to error:", error);
      employees = [];
    }

    // Join with employee data efficiently
    const employeeMap = new Map();
    employees.forEach(emp => {
      employeeMap.set(emp.employeeId, emp);
    });

    const reportData = attendanceRecords.map((attendance) => {
      const employee = employeeMap.get(attendance.employeeId);
      return {
        ...attendance,
        name: employee?.name || employee?.fullName || 'Unknown',
        fullName: employee?.fullName || employee?.name || 'Unknown',
        dccb: employee?.dccb || 'Unknown',
        department: employee?.department || employee?.dccb || 'Unknown',
        reportingManager: employee?.reportingManager || employee?.reportingTo || 'Unknown',
        reportingTo: employee?.reportingTo || employee?.reportingManager || 'Unknown',
        workLocation: attendance.workplace || employee?.dccb || 'Unknown',
        location: {
          latitude: attendance.locationLat,
          longitude: attendance.locationLng,
          address: attendance.locationAddress
        },
        checkInTime: attendance.timestamp,
        checkOutTime: null, // Not implemented yet
        notes: attendance.task || attendance.remarks
      };
    });

    // Filter by DCCB if specified
    const filteredData = dccb
      ? reportData.filter((record) => record.dccb === dccb)
      : reportData;

    return c.json({
      success: true,
      records: filteredData.slice(0, 1000), // Limit results to prevent timeouts
      report: filteredData.slice(0, 1000), // Keep both for backward compatibility
      date,
    });
  } catch (error) {
    console.log("Error generating daily report:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

app.get(
  "/make-server-112ca9a8/reports/dashboard-stats",
  async (c) => {
    try {
      const today = new Date().toISOString().split("T")[0];
      
      // Use Promise.race with timeout to prevent hanging
      const fetchWithTimeout = async (prefix, timeoutMs = 8000) => {
        const dataPromise = kv.getByPrefix(prefix);
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error(`${prefix} fetch timeout`)), timeoutMs)
        );
        return Promise.race([dataPromise, timeoutPromise]);
      };

      let attendanceRecords = [];
      let employees = [];

      try {
        // Fetch data with timeout protection
        [attendanceRecords, employees] = await Promise.allSettled([
          fetchWithTimeout("attendance:", 5000),
          fetchWithTimeout("employee:", 5000)
        ]).then(results => [
          results[0].status === 'fulfilled' ? results[0].value : [],
          results[1].status === 'fulfilled' ? results[1].value : []
        ]);
      } catch (error) {
        console.log("Using fallback data due to fetch error:", error);
        // Return minimal stats to prevent complete failure
        return c.json({
          success: true,
          stats: {
            totalWorkers: 0,
            present: 0,
            absent: 0,
            halfDay: 0,
            onLeave: 0,
            notMarked: 0
          },
          locationStats: {},
          date: today,
          fallback: true
        });
      }

      // Filter today's attendance efficiently
      const todayAttendance = attendanceRecords.filter(
        (record) => record && record.date === today,
      );

      const activeEmployees = employees.filter(
        (emp) => emp && emp.isActive !== false,
      );

      const stats = {
        totalWorkers: activeEmployees.length,
        present: todayAttendance.filter(
          (record) => record.status === "Present",
        ).length,
        absent: todayAttendance.filter(
          (record) => record.status === "Absent",
        ).length,
        halfDay: todayAttendance.filter(
          (record) => record.status === "Half Day",
        ).length,
        onLeave: todayAttendance.filter(
          (record) => record.status === "Leave",
        ).length,
        notMarked: 0,
      };

      stats.notMarked =
        stats.totalWorkers -
        (stats.present +
          stats.absent +
          stats.halfDay +
          stats.onLeave);

      // Location wise breakdown - optimized
      const locationStats = {};
      const attendanceMap = new Map();
      todayAttendance.forEach(att => {
        attendanceMap.set(att.employeeId, att);
      });

      activeEmployees.forEach((emp) => {
        if (emp.dccb) {
          if (!locationStats[emp.dccb]) {
            locationStats[emp.dccb] = { total: 0, present: 0 };
          }
          locationStats[emp.dccb].total++;

          const empAttendance = attendanceMap.get(emp.employeeId);
          if (empAttendance && empAttendance.status === "Present") {
            locationStats[emp.dccb].present++;
          }
        }
      });

      return c.json({
        success: true,
        stats,
        locationStats,
        date: today,
      });
    } catch (error) {
      console.log("Error generating dashboard stats:", error);
      return c.json(
        { 
          success: false, 
          error: "Dashboard stats temporarily unavailable",
          stats: {
            totalWorkers: 0,
            present: 0,
            absent: 0,
            halfDay: 0,
            onLeave: 0,
            notMarked: 0
          },
          locationStats: {},
          fallback: true
        },
        200 // Return 200 instead of 500 to prevent cascading failures
      );
    }
  },
);

// Audit Log Routes
app.get("/make-server-112ca9a8/audit-logs", async (c) => {
  try {
    const logs = await kv.getByPrefix("audit:");

    // Sort by timestamp descending
    logs.sort(
      (a, b) => new Date(b.timestamp) - new Date(a.timestamp),
    );

    return c.json({ success: true, logs });
  } catch (error) {
    console.log("Error fetching audit logs:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

// Change Request Routes
app.post("/make-server-112ca9a8/change-requests", async (c) => {
  try {
    const requestData = await c.req.json();

    const changeRequest = {
      requestId: `req_${Date.now()}`,
      actionType: requestData.actionType,
      targetEmployeeId: requestData.targetEmployeeId,
      requestedBy: requestData.requestedBy,
      requestedOn: new Date().toISOString(),
      approver: requestData.approver || null,
      status: "Pending",
      decisionOn: null,
      decisionBy: null,
      comments: requestData.comments || null,
    };

    await kv.set(
      `change_request:${changeRequest.requestId}`,
      changeRequest,
    );

    // Log the action
    await kv.set(`audit:${Date.now()}`, {
      logId: Date.now(),
      action: "Change Request Created",
      employeeId: requestData.targetEmployeeId,
      doneBy: requestData.requestedBy,
      timestamp: new Date().toISOString(),
      details: `Change request for ${requestData.actionType}`,
    });

    return c.json({ success: true, request: changeRequest });
  } catch (error) {
    console.log("Error creating change request:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

// Health check route with performance monitoring
app.get("/make-server-112ca9a8/health", async (c) => {
  try {
    const startTime = Date.now();
    
    // Quick KV test with timeout
    const testPromise = kv.get("health_check_test").catch(() => null);
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Health check timeout')), 3000)
    );
    
    await Promise.race([testPromise, timeoutPromise]);
    const responseTime = Date.now() - startTime;
    
    return c.json({
      status: "OK",
      timestamp: new Date().toISOString(),
      responseTime: `${responseTime}ms`,
      version: "1.0.0"
    });
  } catch (error) {
    return c.json({
      status: "DEGRADED",
      timestamp: new Date().toISOString(),
      error: "KV store responding slowly",
      version: "1.0.0"
    }, 200); // Still return 200 to indicate server is running
  }
});

Deno.serve(app.fetch);