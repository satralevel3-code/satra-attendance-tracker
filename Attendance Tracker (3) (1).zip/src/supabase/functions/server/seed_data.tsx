import * as kv from './kv_store.tsx';

// Sample employees data
const sampleEmployees = [
  // Field Workers (MT/DC)
  {
    employeeId: 'MGJ00001',
    firstName: 'RAJESH',
    lastName: 'KUMAR',
    fullName: 'RAJESH KUMAR',
    designation: 'MT',
    dccb: 'AHMEDABAD',
    reportingTo: 'SURESH PATEL',
    contactNumber: '9876543210',
    contactAlt: '9876543211',
    email: 'rajesh.kumar@satra.com',
    address: 'B-23, Satellite Road, Ahmedabad, Gujarat',
    pinCode: '380015',
    joinedOn: '2024-01-15',
    isActive: true,
    createdOn: new Date().toISOString(),
    createdBy: 'system',
    password: 'test123'
  },
  {
    employeeId: 'MGJ00002',
    firstName: 'PRIYA',
    lastName: 'PATEL',
    fullName: 'PRIYA PATEL',
    designation: 'DC',
    dccb: 'SURAT',
    reportingTo: 'AMIT SHAH',
    contactNumber: '9876543212',
    contactAlt: '9876543213',
    email: 'priya.patel@satra.com',
    address: 'C-45, Ring Road, Surat, Gujarat',
    pinCode: '395007',
    joinedOn: '2024-01-20',
    isActive: true,
    createdOn: new Date().toISOString(),
    createdBy: 'system',
    password: 'test123'
  },
  {
    employeeId: 'MGJ00003',
    firstName: 'KIRAN',
    lastName: 'DESAI',
    fullName: 'KIRAN DESAI',
    designation: 'MT',
    dccb: 'BARODA',
    reportingTo: 'RAVI MEHTA',
    contactNumber: '9876543214',
    email: 'kiran.desai@satra.com',
    address: 'A-12, Alkapuri, Vadodara, Gujarat',
    pinCode: '390007',
    joinedOn: '2024-02-01',
    isActive: true,
    createdOn: new Date().toISOString(),
    createdBy: 'system',
    password: 'test123'
  },
  // Admin Users
  {
    employeeId: 'MGJ00101',
    firstName: 'SURESH',
    lastName: 'PATEL',
    fullName: 'SURESH PATEL',
    designation: 'Manager',
    contactNumber: '9876543215',
    email: 'suresh.patel@satra.com',
    joinedOn: '2023-06-01',
    isActive: true,
    createdOn: new Date().toISOString(),
    createdBy: 'system',
    password: 'admin123'
  },
  {
    employeeId: 'MGJ00102',
    firstName: 'MEERA',
    lastName: 'SHAH',
    fullName: 'MEERA SHAH',
    designation: 'HR',
    contactNumber: '9876543216',
    email: 'meera.shah@satra.com',
    joinedOn: '2023-08-15',
    isActive: true,
    createdOn: new Date().toISOString(),
    createdBy: 'system',
    password: 'admin123'
  }
];

// Sample attendance data for today and yesterday
const generateSampleAttendance = () => {
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  
  const attendanceRecords = [];
  
  // Today's attendance
  const todayAttendance = [
    {
      employeeId: 'MGJ00001',
      date: today,
      status: 'Present',
      task: 'Data collection',
      workplace: 'PACS',
      timestamp: new Date().toISOString(),
      locationLat: 23.0225,
      locationLng: 72.5714,
      locationLink: 'https://maps.google.com/?q=23.0225,72.5714',
      locationAddress: 'GIDC, Vatva, Ahmedabad, Gujarat 382445',
      submittedFrom: 'MobileApp'
    },
    {
      employeeId: 'MGJ00002',
      date: today,
      status: 'Present',
      task: 'Training',
      workplace: 'DCCB',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      locationLat: 21.1702,
      locationLng: 72.8311,
      locationLink: 'https://maps.google.com/?q=21.1702,72.8311',
      locationAddress: 'Ring Road, Surat, Gujarat 395007',
      submittedFrom: 'MobileApp'
    },
    {
      employeeId: 'MGJ00003',
      date: today,
      status: 'Half Day',
      task: 'Meeting',
      workplace: 'DR Office',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
      locationLat: 22.3072,
      locationLng: 73.1812,
      locationLink: 'https://maps.google.com/?q=22.3072,73.1812',
      locationAddress: 'Alkapuri, Vadodara, Gujarat 390007',
      submittedFrom: 'MobileApp'
    }
  ];

  // Yesterday's attendance
  const yesterdayAttendance = [
    {
      employeeId: 'MGJ00001',
      date: yesterday,
      status: 'Present',
      task: 'Data verification',
      workplace: 'PACS',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      locationLat: 23.0225,
      locationLng: 72.5714,
      locationLink: 'https://maps.google.com/?q=23.0225,72.5714',
      locationAddress: 'GIDC, Vatva, Ahmedabad, Gujarat 382445',
      submittedFrom: 'MobileApp'
    },
    {
      employeeId: 'MGJ00002',
      date: yesterday,
      status: 'Absent',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      submittedFrom: 'MobileApp'
    },
    {
      employeeId: 'MGJ00003',
      date: yesterday,
      status: 'Present',
      task: 'MIS preparation',
      workplace: 'WFH',
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      submittedFrom: 'MobileApp'
    }
  ];

  return [...todayAttendance, ...yesterdayAttendance].map(record => ({
    ...record,
    attendanceId: `att_${Date.now()}_${record.employeeId}_${record.date}`
  }));
};

export async function seedDatabase() {
  try {
    console.log('Starting database seeding...');
    
    // Clear existing data (optional - for development)
    // await kv.del('seeded');
    
    // Check if already seeded
    const alreadySeeded = await kv.get('seeded');
    if (alreadySeeded) {
      console.log('Database already seeded');
      return;
    }
    
    // Seed employees
    for (const employee of sampleEmployees) {
      await kv.set(`employee:${employee.employeeId}`, employee);
      console.log(`Created employee: ${employee.employeeId} - ${employee.fullName}`);
    }
    
    // Seed attendance records
    const attendanceRecords = generateSampleAttendance();
    for (const record of attendanceRecords) {
      const todayKey = `attendance:${record.employeeId}:${record.date}`;
      const logKey = `attendance_log:${record.attendanceId}`;
      
      await kv.set(todayKey, record);
      await kv.set(logKey, record);
      console.log(`Created attendance: ${record.employeeId} - ${record.date} - ${record.status}`);
    }
    
    // Create audit logs
    const auditLogs = [
      {
        logId: Date.now() - 1000,
        action: 'Database Seeded',
        employeeId: null,
        doneBy: 'system',
        timestamp: new Date().toISOString(),
        details: 'Initial database seeding completed'
      }
    ];
    
    for (const log of auditLogs) {
      await kv.set(`audit:${log.logId}`, log);
    }
    
    // Mark as seeded
    await kv.set('seeded', { 
      timestamp: new Date().toISOString(), 
      version: '1.0',
      totalEmployees: sampleEmployees.length,
      totalAttendance: attendanceRecords.length
    });
    
    console.log('Database seeding completed successfully!');
    console.log(`- ${sampleEmployees.length} employees created`);
    console.log(`- ${attendanceRecords.length} attendance records created`);
    console.log('Demo login credentials:');
    console.log('Field Worker: MGJ00001 / test123');
    console.log('Admin: MGJ00101 / admin123');
    
  } catch (error) {
    console.error('Error seeding database:', error);
    throw error;
  }
}