import { Hono } from "hono";
import { cors } from "hono/cors";

const app = new Hono();

// Enable CORS and logging
app.use("*", cors({
  origin: "*",
  allowHeaders: ["*"],
  allowMethods: ["POST", "GET", "OPTIONS", "PUT", "DELETE"],
}));

// Simple in-memory storage for demo purposes
// In production, you'd use a proper database
const storage = new Map();

// Helper functions
const generateId = () => Math.random().toString(36).substr(2, 9);

// Employee Management Routes
app.post("/employees", async (c) => {
  try {
    const employeeData = await c.req.json();

    // Generate EmployeeID if not provided
    if (!employeeData.employeeId) {
      const existingEmployees = Array.from(storage.values())
        .filter(item => item.type === 'employee');
      const nextId = String(existingEmployees.length + 1).padStart(5, "0");
      employeeData.employeeId = `MGJ${nextId}`;
    }

    // Check if employee ID already exists
    const existingEmployee = storage.get(`employee:${employeeData.employeeId}`);
    if (existingEmployee) {
      return c.json(
        { success: false, error: "Employee ID already exists" },
        409
      );
    }

    // Create employee record
    const employee = {
      type: 'employee',
      employeeId: employeeData.employeeId,
      firstName: employeeData.firstName,
      lastName: employeeData.lastName,
      name: employeeData.name || `${employeeData.firstName} ${employeeData.lastName}`,
      fullName: employeeData.name || `${employeeData.firstName} ${employeeData.lastName}`,
      designation: employeeData.designation,
      department: employeeData.department || employeeData.dccb || null,
      dccb: employeeData.dccb || null,
      reportingManager: employeeData.reportingManager || employeeData.reportingTo || null,
      reportingTo: employeeData.reportingTo || null,
      contactNumber: employeeData.contactNumber,
      phoneNumber: employeeData.phoneNumber || employeeData.contactNumber,
      email: employeeData.email,
      address: employeeData.address || null,
      pinCode: employeeData.pinNumber || null,
      workLocations: employeeData.workLocations || (employeeData.dccb ? [employeeData.dccb] : ['HEAD_OFFICE']),
      status: employeeData.status || 'active',
      joinedOn: new Date().toISOString().split("T")[0],
      isActive: true,
      createdOn: new Date().toISOString(),
      createdBy: employeeData.createdBy || "system",
      password: employeeData.password,
    };

    storage.set(`employee:${employee.employeeId}`, employee);

    return c.json({
      success: true,
      employeeId: employee.employeeId,
      employee,
    });
  } catch (error) {
    console.log("Error creating employee:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

app.get("/employees/:employeeId", async (c) => {
  try {
    const employeeId = c.req.param("employeeId");
    const employee = storage.get(`employee:${employeeId}`);

    if (!employee) {
      return c.json(
        { success: false, error: "Employee not found" },
        404,
      );
    }

    return c.json({ success: true, employee });
  } catch (error) {
    console.log("Error fetching employee:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

app.get("/employees", async (c) => {
  try {
    const employees = Array.from(storage.values())
      .filter(item => item.type === 'employee' && item.isActive !== false)
      .slice(0, 500); // Limit results

    return c.json({
      success: true,
      employees,
    });
  } catch (error) {
    console.log("Error fetching employees:", error);
    return c.json({
      success: true,
      employees: [],
      fallback: true,
      error: "Employee data temporarily unavailable"
    });
  }
});

// Authentication Routes
app.post("/login", async (c) => {
  try {
    const { employeeId, password } = await c.req.json();

    const employee = storage.get(`employee:${employeeId}`);

    if (!employee || employee.password !== password) {
      return c.json(
        { success: false, error: "Invalid credentials" },
        401,
      );
    }

    if (!employee.isActive) {
      return c.json(
        { success: false, error: "Account deactivated" },
        401,
      );
    }

    // Return user data without password
    const { password: _, ...userData } = employee;
    return c.json({ success: true, user: userData });
  } catch (error) {
    console.log("Error during login:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

// Attendance Management Routes
app.post("/attendance", async (c) => {
  try {
    const attendanceData = await c.req.json();

    const attendanceRecord = {
      type: 'attendance',
      attendanceId: `att_${Date.now()}_${attendanceData.employeeId}`,
      employeeId: attendanceData.employeeId,
      date: new Date().toISOString().split("T")[0],
      status: attendanceData.status,
      task: attendanceData.task || null,
      workplace: attendanceData.workplace || null,
      timestamp: new Date().toISOString(),
      photoUrl: attendanceData.photoUrl || null,
      locationLat: attendanceData.locationLat || null,
      locationLng: attendanceData.locationLng || null,
      locationAddress: attendanceData.locationAddress || null,
      remarks: attendanceData.remarks || null,
    };

    // Check if attendance already marked for today
    const todayKey = `attendance:${attendanceData.employeeId}:${attendanceRecord.date}`;
    const existingAttendance = storage.get(todayKey);

    if (existingAttendance) {
      return c.json(
        {
          success: false,
          error: "Attendance already marked for today",
        },
        400,
      );
    }

    storage.set(todayKey, attendanceRecord);

    return c.json({
      success: true,
      attendance: attendanceRecord,
    });
  } catch (error) {
    console.log("Error marking attendance:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

app.get("/attendance/:employeeId/today", async (c) => {
  try {
    const employeeId = c.req.param("employeeId");
    const today = new Date().toISOString().split("T")[0];
    const todayKey = `attendance:${employeeId}:${today}`;

    const attendance = storage.get(todayKey);

    return c.json({ success: true, attendance });
  } catch (error) {
    console.log("Error fetching today attendance:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

// Reports Routes
app.get("/reports/daily", async (c) => {
  try {
    const date = c.req.query("date") || new Date().toISOString().split("T")[0];
    
    const attendanceRecords = Array.from(storage.values())
      .filter(item => item.type === 'attendance' && item.date === date)
      .slice(0, 1000);

    const employees = Array.from(storage.values())
      .filter(item => item.type === 'employee');

    const employeeMap = new Map();
    employees.forEach(emp => {
      employeeMap.set(emp.employeeId, emp);
    });

    const reportData = attendanceRecords.map((attendance) => {
      const employee = employeeMap.get(attendance.employeeId);
      return {
        ...attendance,
        name: employee?.name || employee?.fullName || 'Unknown',
        fullName: employee?.fullName || employee?.name || 'Unknown',
        dccb: employee?.dccb || 'Unknown',
        department: employee?.department || employee?.dccb || 'Unknown',
        reportingManager: employee?.reportingManager || employee?.reportingTo || 'Unknown',
        workLocation: attendance.workplace || employee?.dccb || 'Unknown',
        location: {
          latitude: attendance.locationLat,
          longitude: attendance.locationLng,
          address: attendance.locationAddress
        },
        checkInTime: attendance.timestamp,
        notes: attendance.task || attendance.remarks
      };
    });

    return c.json({
      success: true,
      records: reportData,
      report: reportData,
      date,
    });
  } catch (error) {
    console.log("Error generating daily report:", error);
    return c.json(
      { success: false, error: error.message },
      500,
    );
  }
});

app.get("/reports/dashboard-stats", async (c) => {
  try {
    const today = new Date().toISOString().split("T")[0];
    
    const attendanceRecords = Array.from(storage.values())
      .filter(item => item.type === 'attendance' && item.date === today);

    const employees = Array.from(storage.values())
      .filter(item => item.type === 'employee' && item.isActive !== false);

    const stats = {
      totalWorkers: employees.length,
      present: attendanceRecords.filter(record => record.status === "Present").length,
      absent: attendanceRecords.filter(record => record.status === "Absent").length,
      halfDay: attendanceRecords.filter(record => record.status === "Half Day").length,
      onLeave: attendanceRecords.filter(record => record.status === "Leave").length,
      notMarked: 0,
    };

    stats.notMarked = stats.totalWorkers - (stats.present + stats.absent + stats.halfDay + stats.onLeave);

    // Location wise breakdown
    const locationStats = {};
    const attendanceMap = new Map();
    attendanceRecords.forEach(att => {
      attendanceMap.set(att.employeeId, att);
    });

    employees.forEach((emp) => {
      if (emp.dccb) {
        if (!locationStats[emp.dccb]) {
          locationStats[emp.dccb] = { total: 0, present: 0 };
        }
        locationStats[emp.dccb].total++;

        const empAttendance = attendanceMap.get(emp.employeeId);
        if (empAttendance && empAttendance.status === "Present") {
          locationStats[emp.dccb].present++;
        }
      }
    });

    return c.json({
      success: true,
      stats,
      locationStats,
      date: today,
    });
  } catch (error) {
    console.log("Error generating dashboard stats:", error);
    return c.json({
      success: false,
      error: "Dashboard stats temporarily unavailable",
      stats: {
        totalWorkers: 0,
        present: 0,
        absent: 0,
        halfDay: 0,
        onLeave: 0,
        notMarked: 0
      },
      locationStats: {},
      fallback: true
    }, 200);
  }
});

// Health check route
app.get("/health", (c) => {
  return c.json({
    status: "OK",
    timestamp: new Date().toISOString(),
    version: "1.0.0"
  });
});

// Seed some initial data
const seedInitialData = () => {
  // Admin user
  storage.set('employee:ADMIN01', {
    type: 'employee',
    employeeId: 'ADMIN01',
    firstName: 'Suresh',
    lastName: 'Patel',
    name: 'Suresh Patel',
    fullName: 'Suresh Patel',
    designation: 'State Manager',
    department: 'Gujarat State',
    dccb: null,
    reportingManager: 'HEAD OFFICE',
    contactNumber: '+91 98765 43200',
    phoneNumber: '+91 98765 43200',
    email: 'suresh.patel@satraservices.com',
    workLocations: ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot'],
    status: 'active',
    joinedOn: '2024-01-01',
    isActive: true,
    createdOn: new Date().toISOString(),
    createdBy: 'system',
    password: 'admin123'
  });

  // Sample executive
  storage.set('employee:SAT001', {
    type: 'employee',
    employeeId: 'SAT001',
    firstName: 'Rajesh',
    lastName: 'Kumar',
    name: 'Rajesh Kumar',
    fullName: 'Rajesh Kumar',
    designation: 'Regional Manager',
    department: 'Gujarat North',
    dccb: 'AHMEDABAD',
    reportingManager: 'SURESH PATEL',
    contactNumber: '+91 98765 43210',
    phoneNumber: '+91 98765 43210',
    email: 'rajesh.kumar@satraservices.com',
    workLocations: ['Ahmedabad', 'Gandhinagar'],
    status: 'active',
    joinedOn: '2024-01-01',
    isActive: true,
    createdOn: new Date().toISOString(),
    createdBy: 'system',
    password: 'test123'
  });
};

// Initialize with seed data
seedInitialData();

Deno.serve(app.fetch);