# System Architecture

## 🏗️ Overview

The Satra Services Attendance Tracker is a **modern, progressive web application (PWA)** built with React and designed for mobile-first usage. It follows a **client-side-first architecture** with Supabase providing backend services.

## 📐 Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                     Client Application                       │
│                      (React + PWA)                           │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Login &    │  │  Executive   │  │    Admin     │      │
│  │     Auth     │  │  Dashboard   │  │  Dashboard   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  Attendance  │  │   Reports    │  │   Profile    │      │
│  │   Marking    │  │   & MIS      │  │  Management  │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│                     Utility Layer                            │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Security   │  │    Error     │  │   Offline    │      │
│  │  Validation  │  │   Handling   │  │    Queue     │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ Performance  │  │  Monitoring  │  │    Cache     │      │
│  │  Monitoring  │  │  & Analytics │  │   Manager    │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│                    Service Layer                             │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Supabase   │  │    Google    │  │   Location   │      │
│  │    Client    │  │    Sheets    │  │   Service    │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│                   Storage Layer                              │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ LocalStorage │  │  IndexedDB   │  │   Session    │      │
│  │   (Cache)    │  │  (Offline)   │  │   Storage    │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                               │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Backend Services                          │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              Supabase Platform                        │   │
│  ├──────────────────────────────────────────────────────┤   │
│  │                                                        │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌───────────┐  │   │
│  │  │  PostgreSQL  │  │  Auth JWT    │  │  Storage  │  │   │
│  │  │   Database   │  │   Service    │  │  Buckets  │  │   │
│  │  └──────────────┘  └──────────────┘  └───────────┘  │   │
│  │                                                        │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌───────────┐  │   │
│  │  │     Edge     │  │   Realtime   │  │    Row    │  │   │
│  │  │  Functions   │  │  Websockets  │  │   Level   │  │   │
│  │  │    (API)     │  │              │  │ Security  │  │   │
│  │  └──────────────┘  └──────────────┘  └───────────┘  │   │
│  │                                                        │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                  External Services                           │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │    Google    │  │    Google    │  │   Browser    │      │
│  │    Sheets    │  │     Maps     │  │     APIs     │      │
│  │     API      │  │  Geocoding   │  │   (Camera)   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## 🏢 Architectural Layers

### 1. Presentation Layer (React Components)

**Responsibility**: User interface and interaction

**Components**:
- **Screens**: Login, Dashboard, Attendance Marking, Reports
- **UI Components**: Shadcn/ui component library
- **Layouts**: Mobile-first responsive layouts
- **Forms**: Controlled components with validation

**Technologies**:
- React 18
- TypeScript
- Tailwind CSS v4.0
- Shadcn/ui

### 2. Utility Layer

**Responsibility**: Cross-cutting concerns and reusable logic

**Modules**:

#### Security (`/utils/security.ts`)
- Input sanitization and validation
- Password strength checking
- Rate limiting
- Secure storage
- CSRF token management

#### Error Handling (`/utils/errorHandling.ts`)
- Error logging and categorization
- Retry mechanisms with exponential backoff
- Circuit breaker pattern
- Graceful degradation

#### Offline Queue (`/utils/offlineQueue.ts`)
- Queue management for offline operations
- Auto-sync when online
- Priority-based processing
- Persistent storage

#### Performance (`/utils/performance.ts`)
- Performance monitoring
- Caching strategies
- Request deduplication
- Batch processing

#### Monitoring (`/utils/monitoring.ts`)
- Analytics event tracking
- Health check services
- Performance observation
- Error tracking

### 3. Service Layer

**Responsibility**: External API integration and business logic

**Services**:

#### Supabase Client (`/utils/supabase/client.tsx`)
- API communication
- Request/response handling
- Error handling
- Retry logic

#### Google Sheets Service (`/services/GoogleSheetsService.ts`)
- OAuth authentication
- Spreadsheet synchronization
- Data mapping
- Conflict resolution

#### Location Service (`/services/LocationService.ts`)
- Geolocation capture
- Address geocoding
- Location validation

### 4. Storage Layer

**Responsibility**: Data persistence and caching

**Storage Types**:

#### LocalStorage
- User preferences
- Cache data
- Offline queue
- Analytics events

#### SessionStorage
- Temporary session data
- Navigation state

#### IndexedDB (Future)
- Large offline datasets
- Photo blob storage
- Advanced querying

## 🔄 Data Flow

### Authentication Flow

```
User Input (Login)
    │
    ▼
Input Validation (Security Utils)
    │
    ▼
API Request (Supabase Client)
    │
    ▼
Supabase Auth Service
    │
    ▼
JWT Token Generated
    │
    ▼
Secure Storage (Encrypted)
    │
    ▼
User Session Established
    │
    ▼
Analytics Event Tracked
```

### Attendance Marking Flow

```
User Navigation (Mark Attendance)
    │
    ▼
Permission Requests (Camera + Location)
    │
    ├─── Camera Permission ───┐
    │                          ▼
    │                    Camera Stream
    │                          │
    │                          ▼
    │                    Photo Capture
    │
    ├─── Location Permission ─┐
    │                          ▼
    │                   GPS Coordinates
    │                          │
    │                          ▼
    │                   Address Lookup
    │
    ▼
Attendance Data Validation
    │
    ▼
Network Check
    │
    ├─── Online ──────────────┐
    │                          ▼
    │                    Direct API Call
    │                          │
    │                          ▼
    │                   Supabase Database
    │
    ├─── Offline ─────────────┐
    │                          ▼
    │                    Offline Queue
    │                          │
    │                          ▼
    │                    LocalStorage
    │                          │
    │                          ▼
    │                  Auto-Sync (When Online)
    │
    ▼
Success Response
    │
    ▼
Analytics Event Tracked
    │
    ▼
UI Updated
```

### Report Generation Flow

```
User Request (Download Report)
    │
    ▼
Date Range Selection
    │
    ▼
Filter Application
    │
    ▼
Cache Check
    │
    ├─── Cache Hit ──────────┐
    │                         ▼
    │                   Return Cached Data
    │
    ├─── Cache Miss ─────────┐
    │                         ▼
    │                   API Request
    │                         │
    │                         ▼
    │                  Supabase Database
    │                         │
    │                         ▼
    │                   Data Processing
    │                         │
    │                         ▼
    │                    Cache Storage
    │
    ▼
CSV Generation
    │
    ▼
File Download
    │
    ▼
Analytics Event Tracked
```

## 🔐 Security Architecture

### Defense in Depth

```
┌──────────────────────────────────────────┐
│     Layer 1: Network Security            │
│     • HTTPS Only                         │
│     • CORS Policy                        │
│     • CSP Headers                        │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│     Layer 2: Authentication              │
│     • JWT Tokens                         │
│     • Session Management                 │
│     • Rate Limiting                      │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│     Layer 3: Authorization               │
│     • Role-Based Access Control          │
│     • Resource Permissions               │
│     • Row Level Security (RLS)           │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│     Layer 4: Input Validation            │
│     • Client-Side Validation             │
│     • Sanitization                       │
│     • Type Checking                      │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│     Layer 5: Data Protection             │
│     • Encrypted Storage                  │
│     • Secure Transmission                │
│     • CSRF Protection                    │
└──────────────────────────────────────────┘
```

## 🚀 Performance Architecture

### Optimization Strategies

#### 1. Caching Strategy

```
Request
    │
    ▼
Cache Check
    │
    ├─── Hit ─────► Return Cached Data (Fast)
    │
    ├─── Miss ────► API Call
                        │
                        ▼
                    Cache Store
                        │
                        ▼
                    Return Data
```

#### 2. Request Optimization

- **Deduplication**: Prevent duplicate simultaneous requests
- **Batching**: Combine multiple requests into one
- **Throttling**: Limit request frequency
- **Debouncing**: Delay execution until user stops typing

#### 3. Code Splitting

```
Initial Bundle (Critical)
    │
    ├─── Login Screen
    ├─── Error Boundary
    └─── Core Utilities
    
Lazy Loaded (On Demand)
    │
    ├─── Executive Dashboard
    ├─── Admin Dashboard
    ├─── Reports
    └─── Location Manager
```

#### 4. Asset Optimization

- Images: WebP format, lazy loading
- Fonts: Subset, preload critical fonts
- CSS: Purged unused styles, minified
- JavaScript: Tree-shaking, minification

## 📱 Offline Architecture

### Offline-First Strategy

```
┌──────────────────────────────────────────┐
│          Application Layer               │
│    (Works regardless of connection)      │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│         Synchronization Layer            │
│                                           │
│  ┌────────────────────────────────────┐  │
│  │        Offline Queue               │  │
│  │  • Priority-based                  │  │
│  │  • Automatic retry                 │  │
│  │  • Conflict resolution             │  │
│  └────────────────────────────────────┘  │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│           Storage Layer                  │
│                                           │
│  ┌──────────┐  ┌──────────┐             │
│  │ Local    │  │ Session  │             │
│  │ Storage  │  │ Storage  │             │
│  └──────────┘  └──────────┘             │
└──────────────────────────────────────────┘
```

### Sync Strategy

1. **Optimistic UI**: Update UI immediately
2. **Queue Operation**: Add to offline queue if offline
3. **Background Sync**: Auto-sync when online
4. **Conflict Resolution**: Last-write-wins + audit log
5. **Error Handling**: Retry with exponential backoff

## 🔍 Monitoring Architecture

### Observability Stack

```
┌──────────────────────────────────────────┐
│         Application Events               │
│  • User Actions                          │
│  • Errors                                │
│  • Performance Metrics                   │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│        Analytics Service                 │
│  • Event Collection                      │
│  • Event Batching                        │
│  • Event Filtering                       │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│         Storage & Transport              │
│  • LocalStorage (Temporary)              │
│  • Batch Upload (Periodic)               │
└──────────────────────────────────────────┘
                │
                ▼
┌──────────────────────────────────────────┐
│        Analytics Backend                 │
│  • Aggregation                           │
│  • Dashboards                            │
│  • Alerts                                │
└──────────────────────────────────────────┘
```

## 🗄️ Database Schema

### Supabase Tables

#### employees
```sql
CREATE TABLE employees (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone_number TEXT,
  designation TEXT NOT NULL,
  department TEXT NOT NULL,
  reporting_manager TEXT,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

#### credentials
```sql
CREATE TABLE credentials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id TEXT UNIQUE NOT NULL REFERENCES employees(employee_id),
  password_hash TEXT NOT NULL,
  last_password_change TIMESTAMP DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW()
);
```

#### attendance
```sql
CREATE TABLE attendance (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id TEXT NOT NULL REFERENCES employees(employee_id),
  date DATE NOT NULL,
  check_in_time TIMESTAMP,
  check_out_time TIMESTAMP,
  status TEXT NOT NULL,
  location JSONB,
  photo_url TEXT,
  notes TEXT,
  work_location TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(employee_id, date)
);
```

#### audit_logs
```sql
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id TEXT REFERENCES employees(employee_id),
  action TEXT NOT NULL,
  target_id TEXT,
  changes JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

## 🔄 State Management

### Local State (Component)
- UI state
- Form inputs
- Temporary data

### Context (Global)
- User session
- App configuration
- Theme preferences

### URL State
- Current screen/route
- Filter parameters
- Sort options

### Server State (Cache)
- API response data
- User profile
- Attendance records

## 🌐 API Architecture

### RESTful Endpoints

```
/api
  /auth
    POST /login
    POST /logout
    POST /refresh
  /employees
    GET /employees
    GET /employees/:id
    POST /employees
    PUT /employees/:id
    DELETE /employees/:id
  /attendance
    POST /attendance
    GET /attendance/:employeeId/today
    GET /attendance/:employeeId/history
    PUT /attendance/:id
    DELETE /attendance/:id
  /reports
    GET /reports/daily
    GET /reports/dashboard-stats
    GET /reports/download
  /locations
    GET /locations
    POST /locations
  /audit-logs
    GET /audit-logs
  /health
    GET /health
```

## 📊 Scalability Considerations

### Horizontal Scaling
- Stateless architecture
- CDN for static assets
- Database connection pooling
- Edge function distribution

### Vertical Scaling
- Efficient queries
- Database indexing
- Caching strategies
- Code optimization

### Performance Targets
- Initial Load: < 3s
- Time to Interactive: < 3.5s
- API Response: < 500ms (p95)
- Error Rate: < 1%

## 🔧 Development Architecture

### Local Development

```
Developer Machine
    │
    ├─── React Dev Server (Vite)
    │    Port: 5173
    │
    ├─── Supabase Local (Optional)
    │    Port: 54321
    │
    └─── Environment Variables (.env)
```

### CI/CD Pipeline

```
Git Push
    │
    ▼
GitHub Actions
    │
    ├─── Lint & Type Check
    ├─── Run Tests
    ├─── Build Application
    └─── Security Scan
    │
    ▼
Deployment
    │
    ├─── Staging Environment
    │    (Auto-deploy from develop)
    │
    └─── Production Environment
         (Manual approve from main)
```

## 📚 Technology Stack Summary

### Frontend
- **Framework**: React 18
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4.0
- **UI Library**: Shadcn/ui
- **Build Tool**: Vite
- **State**: React Hooks + Context

### Backend
- **BaaS**: Supabase
- **Database**: PostgreSQL
- **Auth**: Supabase Auth (JWT)
- **Storage**: Supabase Storage
- **Functions**: Supabase Edge Functions

### DevOps
- **Version Control**: Git
- **CI/CD**: GitHub Actions
- **Hosting**: Vercel/Netlify
- **Monitoring**: Analytics Service

### External Services
- **Maps**: Google Maps API
- **Sheets**: Google Sheets API
- **OAuth**: Google OAuth 2.0

---

**Last Updated:** 2025-09-30  
**Architecture Version:** 2.0