# API Reference

Complete API documentation for the Satra Services Attendance Tracker application.

## 📋 Base URL

```
Development: http://localhost:5173
Production: https://your-domain.com
Supabase Functions: https://{project-id}.supabase.co/functions/v1
```

## 🔐 Authentication

All API requests (except login) require authentication via Bearer token.

### Headers

```http
Authorization: Bearer {token}
Content-Type: application/json
X-CSRF-Token: {csrf-token}
```

### Getting a Token

Tokens are obtained through the login endpoint and should be stored securely.

```typescript
import { SecureStorage } from './utils/security';

// Store token
SecureStorage.setItem('auth_token', token, true);

// Retrieve token
const token = SecureStorage.getItem('auth_token', true);
```

## 📚 API Endpoints

### Authentication

#### Login

Authenticate a user and obtain an access token.

**Endpoint:** `POST /api/login`

**Request Body:**
```json
{
  "employeeId": "string",
  "password": "string"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "user": {
    "employeeId": "DC001",
    "name": "John Doe",
    "designation": "District Coordinator",
    "department": "Gujarat North",
    "userType": "executive",
    "email": "john.doe@satraservices.com"
  },
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expiresIn": 3600
}
```

**Error Response (401 Unauthorized):**
```json
{
  "error": "Invalid credentials",
  "code": "AUTH_FAILED"
}
```

**Example:**
```typescript
const response = await fetch('/api/login', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    employeeId: 'DC001',
    password: 'secure_password'
  })
});

const data = await response.json();
```

---

### Employees

#### Get Employee Profile

Get detailed information about a specific employee.

**Endpoint:** `GET /api/employees/:employeeId`

**Parameters:**
- `employeeId` (path): Employee ID

**Response (200 OK):**
```json
{
  "employeeId": "DC001",
  "name": "John Doe",
  "designation": "District Coordinator",
  "department": "Gujarat North",
  "email": "john.doe@satraservices.com",
  "phoneNumber": "+91 98765 43210",
  "reportingManager": "SURESH PATEL",
  "workLocations": ["Ahmedabad", "Gandhinagar"],
  "status": "active",
  "joinDate": "2023-01-15",
  "lastLogin": "2025-09-30T10:30:00Z"
}
```

**Example:**
```typescript
const employee = await attendanceAPI.getEmployee('DC001');
```

#### Get All Employees

Get list of all employees (Admin only).

**Endpoint:** `GET /api/employees`

**Query Parameters:**
- `status` (optional): Filter by status (active/inactive)
- `department` (optional): Filter by department
- `designation` (optional): Filter by designation
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 50)

**Response (200 OK):**
```json
{
  "employees": [
    {
      "employeeId": "DC001",
      "name": "John Doe",
      "designation": "District Coordinator",
      "department": "Gujarat North",
      "status": "active"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 200,
    "pages": 4
  }
}
```

**Example:**
```typescript
const employees = await attendanceAPI.getAllEmployees();
```

#### Create Employee Profile

Create a new employee profile (Admin only).

**Endpoint:** `POST /api/employees`

**Request Body:**
```json
{
  "employeeId": "DC999",
  "name": "Jane Smith",
  "designation": "Medical Technician",
  "department": "Gujarat Central",
  "email": "jane.smith@satraservices.com",
  "phoneNumber": "+91 98765 43299",
  "password": "temporary_password",
  "reportingManager": "MGR001",
  "workLocations": ["Surat", "Navsari"],
  "status": "active"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "employeeId": "DC999",
  "message": "Employee profile created successfully"
}
```

**Example:**
```typescript
const result = await attendanceAPI.createEmployee(employeeData);
```

---

### Attendance

#### Mark Attendance

Record attendance for an employee.

**Endpoint:** `POST /api/attendance`

**Request Body:**
```json
{
  "employeeId": "DC001",
  "date": "2025-09-30",
  "checkInTime": "2025-09-30T09:15:00Z",
  "status": "present",
  "location": {
    "latitude": 23.0225,
    "longitude": 72.5714,
    "accuracy": 10,
    "address": "CG Road, Ahmedabad, Gujarat"
  },
  "photoUrl": "blob:http://localhost:5173/...",
  "notes": "Client meeting scheduled",
  "workLocation": "Head Office"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "id": "att_20250930_dc001_001",
  "message": "Attendance marked successfully",
  "timestamp": "2025-09-30T09:15:00Z"
}
```

**Example:**
```typescript
const result = await attendanceAPI.markAttendance({
  employeeId: 'DC001',
  date: new Date().toISOString().split('T')[0],
  status: 'present',
  location: locationData,
  photoUrl: photoBlob,
  notes: taskDescription,
  workLocation: selectedWorkplace
});
```

#### Get Today's Attendance

Get today's attendance record for an employee.

**Endpoint:** `GET /api/attendance/:employeeId/today`

**Response (200 OK):**
```json
{
  "id": "att_20250930_dc001_001",
  "employeeId": "DC001",
  "name": "John Doe",
  "date": "2025-09-30",
  "checkInTime": "09:15:00",
  "checkOutTime": null,
  "status": "present",
  "location": {
    "latitude": 23.0225,
    "longitude": 72.5714,
    "accuracy": 10,
    "address": "CG Road, Ahmedabad"
  },
  "photoUrl": "https://...",
  "notes": "Client meeting scheduled",
  "workLocation": "Head Office"
}
```

**Response (404 Not Found):**
```json
{
  "message": "No attendance record for today"
}
```

**Example:**
```typescript
const todayAttendance = await attendanceAPI.getTodayAttendance('DC001');
```

#### Get Attendance History

Get attendance history for an employee.

**Endpoint:** `GET /api/attendance/:employeeId/history`

**Query Parameters:**
- `startDate` (optional): Start date (YYYY-MM-DD)
- `endDate` (optional): End date (YYYY-MM-DD)
- `status` (optional): Filter by status
- `page` (optional): Page number
- `limit` (optional): Items per page

**Response (200 OK):**
```json
{
  "attendance": [
    {
      "id": "att_20250930_dc001_001",
      "date": "2025-09-30",
      "checkInTime": "09:15:00",
      "checkOutTime": "18:00:00",
      "status": "present",
      "location": {
        "latitude": 23.0225,
        "longitude": 72.5714,
        "address": "CG Road, Ahmedabad"
      },
      "workLocation": "Head Office",
      "notes": "Client meeting scheduled"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 30,
    "total": 45,
    "pages": 2
  }
}
```

**Example:**
```typescript
const history = await attendanceAPI.getAttendanceHistory('DC001');
```

#### Update Attendance

Update an existing attendance record (Admin only).

**Endpoint:** `PUT /api/attendance/:attendanceId`

**Request Body:**
```json
{
  "status": "half-day",
  "notes": "Left early due to emergency",
  "checkOutTime": "2025-09-30T14:00:00Z"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Attendance updated successfully",
  "id": "att_20250930_dc001_001"
}
```

#### Delete Attendance

Delete an attendance record (Admin only).

**Endpoint:** `DELETE /api/attendance/:attendanceId`

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Attendance record deleted successfully"
}
```

---

### Reports

#### Get Daily Report

Get attendance report for a specific date.

**Endpoint:** `GET /api/reports/daily`

**Query Parameters:**
- `date` (required): Date (YYYY-MM-DD)
- `dccb` (optional): Filter by DCCB/Department
- `status` (optional): Filter by status

**Response (200 OK):**
```json
{
  "date": "2025-09-30",
  "summary": {
    "total": 200,
    "present": 180,
    "absent": 15,
    "halfDay": 5,
    "percentage": 90
  },
  "records": [
    {
      "employeeId": "DC001",
      "name": "John Doe",
      "designation": "District Coordinator",
      "department": "Gujarat North",
      "status": "present",
      "checkInTime": "09:15:00",
      "workLocation": "Head Office"
    }
  ]
}
```

**Example:**
```typescript
const report = await attendanceAPI.getDailyReport('2025-09-30', 'Gujarat North');
```

#### Get Dashboard Stats

Get real-time dashboard statistics (Admin only).

**Endpoint:** `GET /api/reports/dashboard-stats`

**Response (200 OK):**
```json
{
  "today": {
    "date": "2025-09-30",
    "total": 200,
    "present": 180,
    "absent": 15,
    "halfDay": 5,
    "percentage": 90,
    "lastUpdated": "2025-09-30T10:30:00Z"
  },
  "thisWeek": {
    "averageAttendance": 88.5,
    "totalPresent": 900,
    "totalAbsent": 100
  },
  "thisMonth": {
    "averageAttendance": 89.2,
    "totalPresent": 5400,
    "totalAbsent": 600
  },
  "departments": [
    {
      "name": "Gujarat North",
      "present": 45,
      "absent": 3,
      "total": 50,
      "percentage": 90
    }
  ]
}
```

**Example:**
```typescript
const stats = await attendanceAPI.getDashboardStats();
```

#### Download CSV Report

Download attendance report as CSV.

**Endpoint:** `GET /api/reports/download`

**Query Parameters:**
- `startDate` (required): Start date
- `endDate` (required): End date
- `format` (optional): csv or xlsx (default: csv)
- `department` (optional): Filter by department

**Response:** CSV file download

**Example:**
```typescript
// Programmatic download
const url = `/api/reports/download?startDate=2025-09-01&endDate=2025-09-30&format=csv`;
window.open(url, '_blank');
```

---

### Locations

#### Get All Locations

Get list of all work locations.

**Endpoint:** `GET /api/locations`

**Response (200 OK):**
```json
{
  "locations": [
    {
      "id": "loc_001",
      "name": "Head Office",
      "address": "123 Main Street, Ahmedabad",
      "latitude": 23.0225,
      "longitude": 72.5714,
      "radius": 100,
      "city": "Ahmedabad",
      "state": "Gujarat",
      "active": true
    }
  ]
}
```

#### Add Location

Add a new work location (Admin only).

**Endpoint:** `POST /api/locations`

**Request Body:**
```json
{
  "name": "New Branch Office",
  "address": "456 Park Avenue, Surat",
  "latitude": 21.1702,
  "longitude": 72.8311,
  "radius": 100,
  "city": "Surat",
  "state": "Gujarat"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "id": "loc_999",
  "message": "Location added successfully"
}
```

---

### Audit Logs

#### Get Audit Logs

Get audit trail of actions (Admin only).

**Endpoint:** `GET /api/audit-logs`

**Query Parameters:**
- `startDate` (optional): Start date
- `endDate` (optional): End date
- `employeeId` (optional): Filter by employee
- `action` (optional): Filter by action type
- `page` (optional): Page number
- `limit` (optional): Items per page

**Response (200 OK):**
```json
{
  "logs": [
    {
      "id": "log_001",
      "timestamp": "2025-09-30T10:30:00Z",
      "employeeId": "ADMIN01",
      "action": "UPDATE_ATTENDANCE",
      "targetId": "att_20250930_dc001_001",
      "changes": {
        "status": {
          "from": "present",
          "to": "half-day"
        }
      },
      "ipAddress": "192.168.1.1",
      "userAgent": "Mozilla/5.0..."
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 150,
    "pages": 3
  }
}
```

---

### Health Check

#### System Health

Check system health status.

**Endpoint:** `GET /api/health`

**Response (200 OK):**
```json
{
  "status": "healthy",
  "timestamp": "2025-09-30T10:30:00Z",
  "checks": {
    "database": {
      "status": "up",
      "responseTime": 15
    },
    "googleSheets": {
      "status": "up",
      "lastSync": "2025-09-30T10:25:00Z"
    },
    "storage": {
      "status": "up",
      "available": true
    }
  },
  "version": "2.0.0"
}
```

---

## 🔄 Client-Side API Usage

### Using AttendanceAPI Client

The application provides a typed API client for easy integration:

```typescript
import { attendanceAPI } from './utils/supabase/client';

// Login
const loginResult = await attendanceAPI.login('DC001', 'password');

// Mark attendance
const attendanceResult = await attendanceAPI.markAttendance({
  employeeId: 'DC001',
  date: new Date().toISOString().split('T')[0],
  status: 'present',
  location: locationData
});

// Get history
const history = await attendanceAPI.getAttendanceHistory('DC001');

// Get reports
const report = await attendanceAPI.getDailyReport('2025-09-30');
```

### Error Handling

```typescript
import { ErrorLogger } from './utils/errorHandling';

try {
  const result = await attendanceAPI.markAttendance(data);
} catch (error) {
  ErrorLogger.log(error, {
    action: 'mark_attendance',
    employeeId: data.employeeId
  });
  
  // Show user-friendly message
  toast.error('Failed to mark attendance. Please try again.');
}
```

### Retry Logic

```typescript
import { RetryHandler } from './utils/errorHandling';

const result = await RetryHandler.execute(
  () => attendanceAPI.markAttendance(data),
  {
    maxAttempts: 3,
    initialDelayMs: 1000,
    backoffMultiplier: 2
  }
);
```

### Caching

```typescript
import { cacheManager } from './utils/performance';

// Check cache first
const cacheKey = `employee_${employeeId}`;
let employee = cacheManager.get(cacheKey);

if (!employee) {
  // Fetch from API
  employee = await attendanceAPI.getEmployee(employeeId);
  
  // Cache for 5 minutes
  cacheManager.set(cacheKey, employee, 300000);
}
```

---

## 📝 TypeScript Types

### Attendance Record

```typescript
interface AttendanceRecord {
  id?: string;
  employeeId: string;
  name: string;
  date: string; // YYYY-MM-DD
  checkInTime?: string; // ISO 8601
  checkOutTime?: string; // ISO 8601
  status: 'present' | 'absent' | 'half-day';
  location: {
    latitude: number;
    longitude: number;
    accuracy: number;
    address?: string;
  };
  photoUrl?: string;
  notes?: string;
  workLocation?: string;
  reportingManager?: string;
  timestamp?: string; // ISO 8601
}
```

### Employee

```typescript
interface Employee {
  employeeId: string;
  name: string;
  designation: string;
  department: string;
  email: string;
  phoneNumber: string;
  reportingManager: string;
  workLocations: string[];
  status: 'active' | 'inactive';
  joinDate?: string;
  lastLogin?: string;
}
```

### Location

```typescript
interface WorkLocation {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  radius: number; // in meters
  city: string;
  state: string;
  active: boolean;
}
```

---

## 🚨 Error Codes

| Code | Description | HTTP Status |
|------|-------------|-------------|
| `AUTH_FAILED` | Invalid credentials | 401 |
| `AUTH_REQUIRED` | No authentication token | 401 |
| `FORBIDDEN` | Insufficient permissions | 403 |
| `NOT_FOUND` | Resource not found | 404 |
| `VALIDATION_ERROR` | Invalid input data | 400 |
| `DUPLICATE` | Duplicate entry | 409 |
| `RATE_LIMIT` | Too many requests | 429 |
| `SERVER_ERROR` | Internal server error | 500 |
| `SERVICE_UNAVAILABLE` | Service temporarily unavailable | 503 |

---

## 📊 Rate Limiting

API requests are rate-limited to prevent abuse:

- **Login:** 5 attempts per 15 minutes per IP
- **Attendance:** 10 requests per minute per user
- **Reports:** 30 requests per minute per user
- **Admin APIs:** 100 requests per minute per admin

Rate limit headers:
```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1633017600
```

---

## 🔐 Security

### HTTPS Only
All API endpoints must be accessed via HTTPS in production.

### CORS Policy
Cross-Origin Resource Sharing (CORS) is restricted to allowed domains.

### Request Signing
Sensitive operations require CSRF token verification.

---

## 📚 Additional Resources

- [Main Documentation](./README.md)
- [Security Guide](./SECURITY.md)
- [Testing Guide](./TESTING_GUIDE.md)
- [Deployment Guide](./DEPLOYMENT_GUIDE.md)

---

**Last Updated:** 2025-09-30  
**API Version:** 2.0